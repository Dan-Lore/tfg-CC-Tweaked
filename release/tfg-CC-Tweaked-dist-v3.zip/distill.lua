-- Bundled from distill/main.lua — do not edit by hand; rebuild with tools/bundle_project.py
-- Also copy distill.cfg next to this file on the computer.
-- Generated package.preload modules + entrypoint.

-- module: util (shared/util.lua)
package.preload["util"] = function(...)
-- Shared string / path helpers for CC:Tweaked scripts.

local util = {}

function util.trim(s)
    return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

function util.split(s, sep)
    local out = {}
    s = tostring(s or "")
    for part in (s .. sep):gmatch("(.-)" .. sep) do
        out[#out + 1] = part
    end
    return out
end

--- Resolve a config path relative to the running program directory.
function util.resolvePath(path, defaultName)
    path = path or defaultName
    if not path then
        error("resolvePath: path required", 2)
    end
    if path:sub(1, 1) == "/" then
        return path
    end
    local base = ""
    if shell and shell.getRunningProgram then
        local prog = shell.getRunningProgram()
        if prog then
            base = fs.getDir(prog)
        end
    end
    return fs.combine(base, path)
end

--- Read entire file as string, or nil if missing.
function util.readAll(path)
    if not path or not fs.exists(path) then
        return nil
    end
    local file = fs.open(path, "r")
    if not file then
        return nil
    end
    local text = file.readAll()
    file.close()
    return text
end

--- Basename of the running program without .lua (e.g. pizza_maintain).
function util.programStem()
    if not (shell and shell.getRunningProgram) then
        return nil
    end
    local prog = shell.getRunningProgram()
    if not prog then
        return nil
    end
    local name = fs.getName(prog)
    return (name:gsub("%.lua$", ""))
end

--- Lines of `[section]` from a sectioned cfg. Nil if file/section missing.
function util.cfgSectionLines(path, section)
    local text = util.readAll(path)
    if not text or not section then
        return nil
    end
    local current = nil
    local buf = {}
    local found = false
    for line in (text .. "\n"):gmatch("(.-)\n") do
        local sec = line:match("^%s*%[([%w_]+)%]%s*$")
        if sec then
            if found then
                break
            end
            if sec == section then
                found = true
                current = sec
                buf = {}
            else
                current = nil
            end
        elseif found and current == section then
            buf[#buf + 1] = line
        end
    end
    if not found then
        return nil
    end
    return buf
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Try sectioned cfg at path; return lines, label or nil.
local function trySectioned(path, section)
    if not path or not fs.exists(path) then
        return nil
    end
    local sectionLines = util.cfgSectionLines(path, section)
    if not sectionLines then
        return nil
    end
    return sectionLines, path .. "[" .. section .. "]"
end

--- Config lines for a logical section.
-- Order: explicit path → <program>.cfg [section] → craft.cfg [section] → fallbackName.
-- Returns lines, label (for errors).
function util.openConfigLines(explicitPath, section, fallbackName)
    if explicitPath then
        local path = util.resolvePath(explicitPath)
        local text = util.readAll(path)
        if not text then
            error("Cannot open " .. path, 2)
        end
        return linesFromText(text), path
    end

    local stem = util.programStem()
    if stem then
        local lines, label = trySectioned(util.resolvePath(nil, stem .. ".cfg"), section)
        if lines then
            return lines, label
        end
    end

    local lines, label = trySectioned(util.resolvePath(nil, "craft.cfg"), section)
    if lines then
        return lines, label
    end

    local path = util.resolvePath(nil, fallbackName)
    local text = util.readAll(path)
    if not text then
        local hint = stem and (stem .. ".cfg") or "program.cfg"
        error(
            "Cannot open " .. path
                .. " (deploy "
                .. hint
                .. " next to the program, or "
                .. tostring(fallbackName)
                .. ")",
            2
        )
    end
    return linesFromText(text), path
end

--- Short display name: last path segment after `/`.
function util.short(id)
    id = tostring(id or "")
    return id:match("([^/]+)$") or id
end

function util.clamp(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

return util
end

-- module: cfg_pipe (shared/cfg_pipe.lua)
package.preload["cfg_pipe"] = function(...)
-- Shared pipe-delimited cfg helpers (key | value [| ...]).

local util = require("util")

local cfg_pipe = {}

cfg_pipe.trim = util.trim
cfg_pipe.split = util.split
cfg_pipe.resolvePath = util.resolvePath

function cfg_pipe.parseScale(raw)
    raw = util.trim(tostring(raw or "")):lower()
    if raw == "" or raw == "auto" then
        return "auto"
    end
    local n = tonumber(raw)
    if not n then
        return "auto"
    end
    n = math.floor(n * 2 + 0.5) / 2
    return util.clamp(n, 0.5, 5)
end

--- Split a cfg line into key, value, parts (or nil, errHint).
function cfg_pipe.splitLine(line)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return nil
    end
    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end
    local key = (parts[1] or ""):lower()
    if key == "" then
        return nil, "empty key"
    end
    if parts[2] == nil or parts[2] == "" then
        return nil, key .. " | value"
    end
    return key, parts[2], parts
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Load all lines from a cfg file.
-- @return lines, path, ok
function cfg_pipe.loadLines(path, defaultName)
    path = util.resolvePath(path, defaultName)
    if not fs.exists(path) then
        return nil, path, false
    end
    local text = util.readAll(path)
    if not text then
        error("Cannot open " .. path, 2)
    end
    return linesFromText(text), path, true
end

return cfg_pipe
end

-- module: config (distill/config.lua)
package.preload["config"] = function(...)
-- Load distill.cfg (defaults if file missing).
-- `config` is project-local (distill/); deploy one bundle per computer.

local util = require("util")
local cfg_pipe = require("cfg_pipe")

local config = {}

local function defaults()
    return {
        tower = "gtceu:distillation_tower_0",
        tower_substr = "distillation_tower",
        tank_substr = "super_tank",
        tank_also = "quantum_tank",
        monitor = "top",

        threshold_low = 0.12,
        threshold_high = 0.18,

        smart_maintain = true,
        cycles_low = 100,
        cycles_high = 160,
        min_ratio = 0.08,
        max_ratio = 0.30,
        hyst_min = 0.05,

        cooldown = 90,
        min_run = 110,
        emergency_frac = 0.40,

        recipe_output = {
            carbon_dioxide = 80000,
            nitrogen = 7000,
            argon = 5000,
            oxygen = 3000,
            krypton = 1000,
            neon = 1000,
            xenon = 1000,
        },
        fluid_ratio = {
            krypton = { low = 0.015, high = 0.02 },
            neon = { low = 0.015, high = 0.02 },
            xenon = { low = 0.015, high = 0.02 },
        },
        tank_index_ratio = {},

        poll = 2,
        boot_wait = 120,
        boot_poll = 2,

        -- GT Super/Quantum tank: 4000 * 1000 * 2^(tier-1) mB (GTCEu Modern)
        tier_base_mb = 4000 * 1000,
        tier_from_name = {
            ulv = 0, lv = 1, mv = 2, hv = 3, ev = 4, iv = 5,
            luv = 6, zpm = 7, uv = 8, uhv = 9, uev = 10, uiv = 11,
            uxv = 12, opv = 13, max = 14,
        },
    }
end

local function setNumber(cfg, key, raw, lineNo)
    local n = tonumber(raw)
    if not n then
        error(("distill.cfg line %s: %s needs a number"):format(tostring(lineNo), key))
    end
    cfg[key] = n
end

local function parseBool(raw, lineNo, key)
    raw = util.trim(tostring(raw or "")):lower()
    if raw == "true" or raw == "1" or raw == "yes" or raw == "on" then
        return true
    end
    if raw == "false" or raw == "0" or raw == "no" or raw == "off" then
        return false
    end
    error(("distill.cfg line %s: %s needs true/false"):format(tostring(lineNo), key))
end

local function parseLine(cfg, line, lineNo)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return
    end

    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end

    local key = (parts[1] or ""):lower()
    local val = parts[2]
    if key == "" then
        error(("distill.cfg line %s: empty key"):format(tostring(lineNo)))
    end

    if key == "recipe_output" or key == "recipe" then
        local fluid = util.trim(parts[2] or "")
        local mb = tonumber(parts[3])
        if fluid == "" or not mb then
            error(("distill.cfg line %s: recipe_output | <fluid> | <mB>"):format(tostring(lineNo)))
        end
        cfg.recipe_output[fluid] = mb
        return
    end

    if key == "fluid_ratio" or key == "fluid_ratio_override" then
        local fluid = util.trim(parts[2] or "")
        local low = tonumber(parts[3])
        local high = tonumber(parts[4])
        if fluid == "" or not low or not high then
            error(("distill.cfg line %s: fluid_ratio | <fluid> | <low> | <high>"):format(tostring(lineNo)))
        end
        cfg.fluid_ratio[fluid] = { low = low, high = high }
        return
    end

    if key == "tank_index_ratio" then
        local idx = tonumber(parts[2])
        local low = tonumber(parts[3])
        local high = tonumber(parts[4])
        if not idx or not low or not high then
            error(("distill.cfg line %s: tank_index_ratio | <index> | <low> | <high>"):format(tostring(lineNo)))
        end
        cfg.tank_index_ratio[idx] = { low = low, high = high }
        return
    end

    if val == nil or val == "" then
        error(("distill.cfg line %s: %s | value"):format(tostring(lineNo), key))
    end

    if key == "tower" or key == "tower_name" then
        cfg.tower = val
    elseif key == "tower_substr" then
        cfg.tower_substr = val
    elseif key == "tank_substr" then
        cfg.tank_substr = val
    elseif key == "tank_also" then
        cfg.tank_also = val
    elseif key == "monitor" then
        cfg.monitor = val
    elseif key == "threshold_low" then
        setNumber(cfg, "threshold_low", val, lineNo)
    elseif key == "threshold_high" then
        setNumber(cfg, "threshold_high", val, lineNo)
    elseif key == "smart_maintain" then
        cfg.smart_maintain = parseBool(val, lineNo, key)
    elseif key == "cycles_low" then
        setNumber(cfg, "cycles_low", val, lineNo)
    elseif key == "cycles_high" then
        setNumber(cfg, "cycles_high", val, lineNo)
    elseif key == "min_ratio" then
        setNumber(cfg, "min_ratio", val, lineNo)
    elseif key == "max_ratio" then
        setNumber(cfg, "max_ratio", val, lineNo)
    elseif key == "hyst_min" then
        setNumber(cfg, "hyst_min", val, lineNo)
    elseif key == "cooldown" or key == "cooldown_sec" then
        setNumber(cfg, "cooldown", val, lineNo)
    elseif key == "min_run" or key == "min_run_sec" then
        setNumber(cfg, "min_run", val, lineNo)
    elseif key == "emergency_frac" then
        setNumber(cfg, "emergency_frac", val, lineNo)
    elseif key == "poll" or key == "poll_sec" then
        setNumber(cfg, "poll", val, lineNo)
    elseif key == "boot_wait" or key == "boot_wait_sec" then
        setNumber(cfg, "boot_wait", val, lineNo)
    elseif key == "boot_poll" or key == "boot_poll_sec" then
        setNumber(cfg, "boot_poll", val, lineNo)
    elseif key == "tier_base_mb" then
        setNumber(cfg, "tier_base_mb", val, lineNo)
    else
        error(("distill.cfg line %s: unknown key %q"):format(tostring(lineNo), key))
    end
end

--- Load distill.cfg next to the program; missing file → defaults.
function config.load(path)
    local cfg = defaults()
    local lines, resolved, ok = cfg_pipe.loadLines(path, "distill.cfg")
    if not ok then
        return cfg, resolved, false
    end
    for n = 1, #lines do
        parseLine(cfg, lines[n], n)
    end
    return cfg, resolved, true
end

return config
end

-- module: net_watch (shared/net_watch.lua)
package.preload["net_watch"] = function(...)
-- Shared peripheral hotplug / sleep helpers for long-running controllers.

local net_watch = {}

function net_watch.flushEvents(tag)
    tag = tag or "net_watch_flush"
    os.queueEvent(tag)
    while true do
        local ev = os.pullEvent()
        if ev == tag then
            return
        end
    end
end

--- Sleep seconds; return true if a peripheral attach/detach arrived (wakes early).
function net_watch.sleepWatch(seconds)
    local timer = os.startTimer(seconds)
    while true do
        local ev, p1 = os.pullEvent()
        if ev == "timer" and p1 == timer then
            return false
        elseif ev == "peripheral" or ev == "peripheral_detach" then
            return true
        end
    end
end

--- Sleep full duration; call onHotplug() on attach/detach but do not wake early.
function net_watch.sleepDrain(seconds, onHotplug)
    local timer = os.startTimer(seconds)
    while true do
        local ev, p1 = os.pullEvent()
        if ev == "timer" and p1 == timer then
            return
        elseif ev == "peripheral" or ev == "peripheral_detach" then
            if type(onHotplug) == "function" then
                onHotplug()
            end
        end
    end
end

function net_watch.safeCall(name, method, ...)
    local ok, a, b, c = pcall(peripheral.call, name, method, ...)
    if not ok then
        return nil
    end
    return a, b, c
end

function net_watch.safeMethod(obj, method, ...)
    if not obj or type(obj[method]) ~= "function" then
        return nil
    end
    local ok, a, b, c = pcall(obj[method], obj, ...)
    if not ok then
        return nil
    end
    return a, b, c
end

return net_watch
end

-- module: tower (distill/tower.lua)
package.preload["tower"] = function(...)
-- Distillation tower discovery + enable/disable (CC: Tweaked / TFG).

local net_watch = require("net_watch")

local M = {}

local function safeCall(name, method, ...)
    return net_watch.safeCall(name, method, ...)
end

--- Find tower by pinned name or substr. Returns wrap, name.
function M.discover(cfg)
    local pinned = cfg.tower
    if pinned and peripheral.isPresent(pinned) then
        return peripheral.wrap(pinned), pinned
    end
    local substr = cfg.tower_substr or "distillation_tower"
    for _, name in ipairs(peripheral.getNames()) do
        if name:find(substr, 1, true) then
            return peripheral.wrap(name), name
        end
    end
    return nil, nil
end

--- state: { enabled, enabledAt, offAt, cooldownLeft }
function M.isWorking(towerName, state)
    local v = safeCall(towerName, "isWorkingEnabled")
    if v == nil then
        return state.enabled
    end
    state.enabled = v and true or false
    return state.enabled
end

function M.setWorking(towerName, state, on, cooldownSec)
    safeCall(towerName, "setWorkingEnabled", on and true or false)
    local was = state.enabled
    state.enabled = on and true or false
    if state.enabled and not was then
        state.enabledAt = os.clock()
        state.offAt = nil
    elseif not state.enabled and was then
        state.enabledAt = nil
        state.offAt = os.clock()
        state.cooldownLeft = cooldownSec or 0
    end
end

function M.runAge(state)
    if not state.enabledAt then
        return 0
    end
    return os.clock() - state.enabledAt
end

function M.newState()
    return {
        enabled = false,
        enabledAt = nil,
        offAt = nil,
        cooldownLeft = 0,
    }
end

return M
end

-- module: tanks (distill/tanks.lua)
package.preload["tanks"] = function(...)
-- Product tank discovery + capacity / readTank (CC: Tweaked / TFG).

local net_watch = require("net_watch")

local M = {}

local function safeCall(name, method, ...)
    return net_watch.safeCall(name, method, ...)
end

local function indexFromName(name)
    return tonumber(name:match("_(%d+)$"))
end

function M.isProductTank(name, cfg)
    if name:find(cfg.tank_substr, 1, true) then
        return true
    end
    if cfg.tank_also and cfg.tank_also ~= "" and name:find(cfg.tank_also, 1, true) then
        return true
    end
    return false
end

local function capacityFromTierName(name, cfg)
    local lower = name:lower()
    local tierName = lower:match("^gtceu:(%w+)_super_tank")
        or lower:match("^gtceu:(%w+)_quantum_tank")
        or lower:match(":(%w+)_super_tank")
        or lower:match(":(%w+)_quantum_tank")
    if not tierName then
        return nil
    end
    local tier = (cfg.tier_from_name or {})[tierName]
    if tier == nil then
        return nil
    end
    local base = cfg.tier_base_mb or (4000 * 1000)
    if tier < 1 then
        return base -- ULV edge: treat as base
    end
    return base * (2 ^ (tier - 1))
end

--- Probe capacity: tanks().capacity → getTankCapacity/getCapacity → GT tier from name → cache.
local function resolveCapacity(name, tanksTable, cached, cfg)
    if cached and cached > 0 then
        return cached, "cache"
    end

    if type(tanksTable) == "table" then
        for _, slot in pairs(tanksTable) do
            if type(slot) == "table" then
                local cap = tonumber(slot.capacity) or tonumber(slot.maxAmount) or tonumber(slot.max_amount)
                if cap and cap > 0 then
                    return cap, "tanks()"
                end
            end
        end
    end

    local methods = {
        { "getTankCapacity", 1 },
        { "getTankCapacity", 0 },
        { "getCapacity" },
        { "getFluidCapacity" },
        { "getMaxFluidAmount" },
    }
    for i = 1, #methods do
        local m = methods[i]
        local v
        if m[2] ~= nil then
            v = safeCall(name, m[1], m[2])
        else
            v = safeCall(name, m[1])
        end
        v = tonumber(v)
        if v and v > 0 then
            return v, m[1]
        end
    end

    local fromTier = capacityFromTierName(name, cfg)
    if fromTier and fromTier > 0 then
        return fromTier, "tier"
    end

    return nil, "unknown"
end

function M.readTank(name, prev, cfg)
    local amount, fluid = 0, nil
    local ok, list = pcall(function()
        return peripheral.call(name, "tanks")
    end)
    if ok and type(list) == "table" then
        for _, slot in pairs(list) do
            if type(slot) == "table" and slot.amount then
                amount = amount + (tonumber(slot.amount) or 0)
                if not fluid and slot.name then
                    fluid = slot.name
                end
            end
        end
    end

    local prevCap = prev and prev.capacity or nil
    local capacity, src = resolveCapacity(name, ok and list or nil, prevCap, cfg)
    if not capacity or capacity <= 0 then
        capacity = math.max(amount, 1)
        src = src or "fallback"
    end

    local ratio = amount / capacity
    if ratio > 1 then
        ratio = 1
    end
    if ratio < 0 then
        ratio = 0
    end

    return {
        name = name,
        index = indexFromName(name) or 0,
        amount = amount,
        capacity = capacity,
        capacitySrc = src,
        ratio = ratio,
        fluid = fluid or (prev and prev.fluid) or nil,
    }
end

--- Discover product tanks; preserve previous capacity cache by name.
function M.discover(cfg, prevList)
    local prev = {}
    if prevList then
        for _, t in ipairs(prevList) do
            prev[t.name] = t
        end
    end

    local list = {}
    for _, name in ipairs(peripheral.getNames()) do
        if M.isProductTank(name, cfg) then
            list[#list + 1] = M.readTank(name, prev[name], cfg)
        end
    end
    table.sort(list, function(a, b)
        if a.index == b.index then
            return a.name < b.name
        end
        return a.index < b.index
    end)
    return list
end

--- Re-read amounts for known tanks. Returns true if any tank missing (hotplug).
function M.refresh(list, cfg)
    local prev = {}
    for _, t in ipairs(list) do
        prev[t.name] = t
    end
    local dirty = false
    for i, t in ipairs(list) do
        if peripheral.isPresent(t.name) then
            list[i] = M.readTank(t.name, prev[t.name], cfg)
        else
            dirty = true
        end
    end
    return dirty
end

return M
end

-- module: ui (distill/ui.lua)
package.preload["ui"] = function(...)
-- Distillation tower monitor UI (CC: Tweaked / TFG).
-- One gas per full-width row (no 2-col clip). Required by main.lua.

local ui = {}

local function clip(text, maxLen)
    text = tostring(text or "")
    if maxLen <= 0 or #text <= maxLen then
        return text
    end
    if maxLen == 1 then
        return "…"
    end
    return text:sub(1, maxLen - 1) .. "…"
end

local function padRight(text, width)
    text = tostring(text or "")
    if #text >= width then
        return text:sub(1, width)
    end
    return text .. string.rep(" ", width - #text)
end

local function shortFluid(name, maxLen)
    maxLen = maxLen or 18
    if not name then
        return "-"
    end
    local short = name:match("([^:/]+)$") or name
    short = short:gsub("_", " ")
    if #short > maxLen then
        return short:sub(1, maxLen - 1) .. "…"
    end
    return short
end

local function formatMb(n)
    n = tonumber(n) or 0
    if n >= 1000000 then
        return string.format("%.2fM", n / 1000000)
    elseif n >= 1000 then
        return string.format("%.0fk", n / 1000)
    end
    return tostring(math.floor(n))
end

local function tankColor(t)
    if t.needOn then
        return colors.red
    elseif not t.okOff then
        return colors.yellow
    end
    return colors.lime
end

--- Plain fill bar only (# / -). Markers live in the text columns.
local function drawLevelBar(ratio, width)
    width = math.max(4, math.floor(width or 1))
    local filled = math.floor((tonumber(ratio) or 0) * width + 1e-9)
    if filled > width then
        filled = width
    end
    if filled < 0 then
        filled = 0
    end
    return string.rep("#", filled) .. string.rep("-", width - filled)
end

local function writeAt(mon, x, y, text, color, maxW)
    mon.setCursorPos(x, y)
    if color then
        mon.setTextColor(color)
    else
        mon.setTextColor(colors.white)
    end
    mon.write(clip(text, maxW))
end

local function writeLine(mon, y, text, color, maxW)
    writeAt(mon, 1, y, text, color, maxW)
end

--- One gas = two full-width lines:
---   # name………………  now% → until%   amount/cap
---   [##############--------]
local function drawTankRow(mon, y, w, t)
    local color = tankColor(t)
    local now = string.format("%5.1f%%", (t.ratio or 0) * 100)
    local untilPct = string.format("%4.0f%%", (t.highTh or 0) * 100)
    local vol = formatMb(t.amount) .. "/" .. formatMb(t.capacity)
    local arrow = " → "

    -- Right block fixed: " 21.0% →  30%  6.69M/32.00M"
    local right = now .. arrow .. untilPct .. "  " .. vol
    local rightW = #right
    local leftBudget = math.max(8, w - rightW - 1)
    local idx = string.format("%d ", t.index or 0)
    local nameW = math.max(4, leftBudget - #idx)
    local name = padRight(shortFluid(t.fluid, nameW), nameW)

    writeLine(mon, y, clip(idx .. name .. right, w), color, w)
    writeLine(mon, y + 1, drawLevelBar(t.ratio, w), color, w)
    return 2
end

function ui.boot(mon, text)
    if not mon then
        return
    end
    mon.clear()
    mon.setTextScale(0.5)
    mon.setCursorPos(1, 1)
    mon.setTextColor(colors.white)
    mon.write(tostring(text or "…"))
end

--- view: tanks, towerEnabled, cooldownLeft, lastBindLabel, lastMinRatio,
--- lastReason, cyclesLow, cyclesHigh, minRatio, maxRatio, networkSummary
function ui.draw(mon, view)
    if not mon or not view then
        return
    end

    mon.clear()
    mon.setTextScale(0.5)
    local w, h = mon.getSize()
    if not w or w < 1 then
        w = 26
    end
    if not h or h < 1 then
        h = 15
    end

    local tanks = view.tanks or {}
    local y = 1

    local status = view.towerEnabled and "ON" or "OFF"
    local statusColor = view.towerEnabled and colors.lime or colors.gray
    local cd = tonumber(view.cooldownLeft) or 0
    if cd > 0 and not view.towerEnabled then
        status = string.format("CD %ds", math.ceil(cd))
        statusColor = colors.orange
    end

    writeLine(
        mon,
        y,
        clip(string.format("DISTILL  %s    limiter: %s", status, tostring(view.lastBindLabel or "-")), w),
        statusColor,
        w
    )
    y = y + 1

    writeLine(
        mon,
        y,
        clip(string.format(
            "Fill until OFF%%   stock %d..%d cycles   floor %.0f%%  ceil %.0f%%",
            tonumber(view.cyclesLow) or 0,
            tonumber(view.cyclesHigh) or 0,
            (tonumber(view.minRatio) or 0) * 100,
            (tonumber(view.maxRatio) or 0) * 100
        ), w),
        colors.lightGray,
        w
    )
    y = y + 1

    -- Column legend
    writeLine(
        mon,
        y,
        clip("id fluid                  now% → until%   amount/cap", w),
        colors.gray,
        w
    )
    y = y + 1

    if #tanks == 0 then
        writeLine(mon, y, "no tanks on network", colors.yellow, w)
        writeLine(mon, y + 1, clip(view.networkSummary or "", w), colors.white, w)
        return
    end

    local blockH = 2
    local footerReserve = 1
    local maxRows = math.floor((h - y + 1 - footerReserve) / blockH)

    for idx, t in ipairs(tanks) do
        if idx > maxRows then
            writeLine(mon, y, clip(string.format("… +%d more tanks", #tanks - maxRows), w), colors.yellow, w)
            y = y + 1
            break
        end
        drawTankRow(mon, y, w, t)
        y = y + blockH
    end

    writeLine(mon, math.min(h, y), clip(view.lastReason or "", w), colors.lightGray, w)
    mon.setTextColor(colors.white)
end

return ui
end

-- entry: distill/main.lua
-- GTCEU Distillation Tower controller (CC: Tweaked / TFG).
-- Smart maintain: per-tank % from recipe cycles × output / capacity (+ floor/cap + CD).
-- Bundle:  python tools/bundle_project.py distill
-- Deploy:  dist/distill.lua + distill.cfg

local configMod = require("config")
local towerMod = require("tower")
local tanksMod = require("tanks")
local ui = require("ui")
local net_watch = require("net_watch")

local cfg, cfgPath, cfgLoaded = configMod.load()

-- ========================= STATE =========================
local tower = nil
local towerName = nil
local towerState = towerMod.newState()
local tanks = {} -- { name, index, amount, capacity, ratio, fluid, capacitySrc }
local monitor = nil
local netDirty = false
local lastMinRatio = 1
local lastReason = "init"
local lastBindLabel = "-"
local lastBindDeficit = 0

-- ========================= HELPERS =========================
local function networkSummary()
    return table.concat(peripheral.getNames(), ", ")
end

local function flushEvents()
    net_watch.flushEvents("distill_ctrl_flush")
end

local function sleepWatch(seconds)
    local dirty = net_watch.sleepWatch(seconds)
    if dirty then
        netDirty = true
    end
    return dirty
end

local function shortFluid(name, maxLen)
    maxLen = maxLen or 14
    if not name then
        return "-"
    end
    local short = name:match("([^:/]+)$") or name
    short = short:gsub("_", " ")
    if #short > maxLen then
        return short:sub(1, maxLen - 1) .. "…"
    end
    return short
end

local function formatMb(n)
    n = tonumber(n) or 0
    if n >= 1000000 then
        return string.format("%.2fM", n / 1000000)
    elseif n >= 1000 then
        return string.format("%.1fk", n / 1000)
    end
    return tostring(math.floor(n))
end

local function discoverMonitor()
    local want = cfg.monitor
    if want and peripheral.isPresent(want) then
        local m = peripheral.wrap(want)
        if m and m.clear then
            return m
        end
    end
    for _, name in ipairs(peripheral.getNames()) do
        if peripheral.getType(name) == "monitor" then
            return peripheral.wrap(name)
        end
    end
    return nil
end

-- ========================= SMART THRESHOLDS =========================
local function clamp(v, lo, hi)
    if v < lo then
        return lo
    end
    if v > hi then
        return hi
    end
    return v
end

local function fluidKey(fluid)
    if not fluid then
        return nil
    end
    return (fluid:match("([^:/]+)$") or fluid):gsub(" ", "_")
end

--- low/high fill ratios from recipe output + tank capacity.
local function tankThresholds(t)
    local fk = fluidKey(t.fluid)
    if t.index ~= nil and cfg.tank_index_ratio[t.index] then
        local o = cfg.tank_index_ratio[t.index]
        return o.low or cfg.threshold_low, o.high or cfg.threshold_high, "idx"
    end
    if fk and cfg.fluid_ratio[fk] then
        local o = cfg.fluid_ratio[fk]
        return o.low or cfg.threshold_low, o.high or cfg.threshold_high, "ovr"
    end

    local out = fk and cfg.recipe_output[fk]
    if cfg.smart_maintain and out and out > 0 and t.capacity and t.capacity > 0 then
        local low = (cfg.cycles_low * out) / t.capacity
        local high = (cfg.cycles_high * out) / t.capacity
        low = clamp(low, cfg.min_ratio, cfg.max_ratio)
        high = clamp(high, cfg.min_ratio, cfg.max_ratio)
        if high < low + cfg.hyst_min then
            high = math.min(1, low + cfg.hyst_min)
        end
        return low, high, "cyc"
    end

    local low = cfg.threshold_low
    local high = cfg.threshold_high
    if high < low + cfg.hyst_min then
        high = math.min(1, low + cfg.hyst_min)
    end
    return low, high, "flat"
end

local function enrichTank(t)
    local low, high, src = tankThresholds(t)
    t.lowTh = low
    t.highTh = high
    t.thSrc = src
    local out = fluidKey(t.fluid)
    out = out and cfg.recipe_output[out]
    t.outMb = out
    if out and out > 0 then
        t.cycles = t.amount / out
        t.coeff = out / 1000 -- display: relative to 1 bucket/cycle
    else
        t.cycles = nil
        t.coeff = 1
    end
    t.needOn = t.ratio < t.lowTh
    t.okOff = t.ratio >= t.highTh
    t.emergency = t.ratio < (t.lowTh * cfg.emergency_frac)
    if t.lowTh > 0 then
        t.relFill = t.ratio / t.lowTh
    else
        t.relFill = 1
    end
    return t
end

local function analyzeTanks()
    local needOn = false
    local allOkOff = true
    local anyEmergency = false
    local bindTank = nil
    local bindDeficit = -1
    local worstRel = 2

    for _, t in ipairs(tanks) do
        enrichTank(t)
        if t.needOn then
            needOn = true
        end
        if t.emergency then
            anyEmergency = true
        end
        if not t.okOff then
            allOkOff = false
        end
        if t.relFill < worstRel then
            worstRel = t.relFill
        end
        local deficit = t.lowTh - t.ratio
        if deficit > bindDeficit then
            bindDeficit = deficit
            bindTank = t
        end
    end

    if #tanks == 0 then
        worstRel = 1
    end
    return needOn, allOkOff, bindTank, worstRel, anyEmergency
end

-- ========================= WAIT / RESCAN =========================
local function waitForTower(timeoutSec)
    local deadline = os.clock() + timeoutSec
    while true do
        tower, towerName = towerMod.discover(cfg)
        if tower then
            return true
        end
        if os.clock() >= deadline then
            return false
        end
        print("Ждём колонну... " .. networkSummary())
        sleepWatch(cfg.boot_poll)
    end
end

local function waitForTanks(timeoutSec)
    local deadline = os.clock() + timeoutSec
    local lastPrint = 0
    while true do
        local list = tanksMod.discover(cfg, tanks)
        if #list > 0 then
            tanks = list
            netDirty = false
            return true
        end
        if os.clock() >= deadline then
            return false
        end
        local now = os.clock()
        if now - lastPrint >= 5 then
            print("Ждём танки (*" .. tostring(cfg.tank_substr) .. "* / *"
                .. tostring(cfg.tank_also) .. "*)... " .. networkSummary())
            lastPrint = now
        end
        sleepWatch(cfg.boot_poll)
    end
end

local function rescanNetwork(reason)
    local list = tanksMod.discover(cfg, tanks)
    if #list == 0 then
        if #tanks > 0 then
            print("Танки пропали из сети, ждём...")
            tanks = {}
        end
        netDirty = false
        return false
    end
    local before = #tanks
    tanks = list
    netDirty = false
    if reason and #list ~= before then
        print(("Рескан (%s): танков %d"):format(tostring(reason), #list))
    end
    return true
end

local function refreshTanks()
    if tanksMod.refresh(tanks, cfg) then
        netDirty = true
    end
end

-- ========================= CONTROL =========================
local function updateTower()
    if not towerName or not peripheral.isPresent(towerName) then
        return
    end

    local needOn, allOkOff, bindTank, worstRel, anyEmergency = analyzeTanks()
    lastMinRatio = worstRel
    if bindTank then
        lastBindLabel = shortFluid(bindTank.fluid, 12)
        lastBindDeficit = bindTank.lowTh - bindTank.ratio
    else
        lastBindLabel = "-"
        lastBindDeficit = 0
    end

    local enabled = towerMod.isWorking(towerName, towerState)

    if needOn then
        local blockedByCd = towerState.cooldownLeft > 0 and not anyEmergency
        local canStart = not enabled and not blockedByCd
        if canStart then
            towerMod.setWorking(towerName, towerState, true, cfg.cooldown)
            if bindTank then
                lastReason = string.format(
                    "ON %s %.0f%%<t%.0f%%",
                    lastBindLabel,
                    bindTank.ratio * 100,
                    bindTank.lowTh * 100
                )
            else
                lastReason = "ON need fill"
            end
            print(lastReason)
        elseif enabled then
            lastReason = "run " .. lastBindLabel
        elseif blockedByCd then
            lastReason = string.format(
                "CD %ds lim %s",
                math.ceil(towerState.cooldownLeft),
                lastBindLabel
            )
        end
    elseif allOkOff then
        if enabled then
            local age = towerMod.runAge(towerState)
            if age < cfg.min_run then
                lastReason = string.format("min-run %ds", math.ceil(cfg.min_run - age))
            else
                towerMod.setWorking(towerName, towerState, false, cfg.cooldown)
                lastReason = "OFF stock ok"
                print(lastReason)
            end
        else
            lastReason = "idle ok"
        end
    else
        -- hysteresis band: some above low, not all above high
        if enabled then
            lastReason = "hold ON " .. lastBindLabel
        else
            lastReason = "hold OFF"
        end
    end
end

-- ========================= UI =========================
local function draw()
    for i = 1, #tanks do
        enrichTank(tanks[i])
    end
    ui.draw(monitor, {
        tanks = tanks,
        towerEnabled = towerState.enabled,
        cooldownLeft = towerState.cooldownLeft,
        lastBindLabel = lastBindLabel,
        lastMinRatio = lastMinRatio,
        lastReason = lastReason,
        cyclesLow = cfg.cycles_low,
        cyclesHigh = cfg.cycles_high,
        minRatio = cfg.min_ratio,
        maxRatio = cfg.max_ratio,
        networkSummary = networkSummary(),
    })
end

-- ========================= MAIN =========================
local function init()
    flushEvents()
    netDirty = false

    if not waitForTower(cfg.boot_wait) then
        error("Колонна не найдена (искали " .. tostring(cfg.tower)
            .. " / *" .. tostring(cfg.tower_substr) .. "*). Сеть: " .. networkSummary())
    end

    monitor = discoverMonitor()
    ui.boot(monitor, "Waiting for tanks...")

    if not waitForTanks(cfg.boot_wait) then
        print("Танки ещё не в сети после " .. cfg.boot_wait
            .. "с — ждём дальше. Сеть: " .. networkSummary())
        tanks = {}
    end

    towerMod.isWorking(towerName, towerState)
    local _, allOkOff, _, worstRel = analyzeTanks()
    lastMinRatio = worstRel
    if towerState.enabled and allOkOff then
        towerMod.setWorking(towerName, towerState, false, cfg.cooldown)
        lastReason = "boot OFF (targets ok)"
    end
end

local function main()
    print("distill: cfg " .. tostring(cfgPath) .. (cfgLoaded and " (loaded)" or " (defaults)"))
    print("Старт distill ctrl, ждём периферию до " .. cfg.boot_wait .. "с...")
    init()
    print("Колонна: " .. tostring(towerName))
    print("Танков: " .. #tanks)
    for _, t in ipairs(tanks) do
        enrichTank(t)
        print(string.format(
            "  #%d %s %s/%s  %.1f%% → low%.1f%%/high%.1f%% (%s) out=%s",
            t.index,
            shortFluid(t.fluid),
            formatMb(t.amount),
            formatMb(t.capacity),
            t.ratio * 100,
            t.lowTh * 100,
            t.highTh * 100,
            tostring(t.thSrc),
            t.outMb and formatMb(t.outMb) or "?"
        ))
    end

    while true do
        if towerState.cooldownLeft > 0 then
            towerState.cooldownLeft = math.max(0, towerState.cooldownLeft - cfg.poll)
        end

        if netDirty or #tanks == 0 then
            if not rescanNetwork(netDirty and "hotplug" or "retry") then
                draw()
                sleepWatch(cfg.boot_poll)
            end
        end

        if not tower or not towerName or not peripheral.isPresent(towerName) then
            tower, towerName = towerMod.discover(cfg)
        end

        if #tanks > 0 and tower then
            refreshTanks()
            updateTower()
        end

        draw()
        sleepWatch(cfg.poll)
    end
end

local ok, err = pcall(main)
if not ok then
    print("Критическая ошибка: " .. tostring(err))
end
