-- Bundled from craft/greenhouse_clean.lua — do not edit by hand; rebuild with tools/bundle_project.py
-- Also copy the matching .cfg next to this file (same basename; sections [storage] and [recipes]).
-- Generated package.preload modules + entrypoint.

-- module: transfer (shared/transfer.lua)
package.preload["transfer"] = function(...)
-- Item and fluid transfers between peripherals.
-- Item queries: exact id, or #namespace:path (item tag via getItemDetail / fallbacks).
-- Domain food/spoil/tag fallbacks are registered by craft/food.lua (optional).

local transfer = {}

local tagFallbacks = {} -- tagId -> predicate(itemName) -> bool
local spoilCheck = nil -- function(detail) -> bool
local foodItemCheck = nil -- function(name) -> bool

function transfer.registerTagFallback(tagId, fn)
    if type(tagId) == "string" and type(fn) == "function" then
        tagFallbacks[tagId] = fn
    end
end

function transfer.setSpoilCheck(fn)
    spoilCheck = fn
end

function transfer.setFoodItemCheck(fn)
    foodItemCheck = fn
end

function transfer.isTag(query)
    return type(query) == "string" and query:sub(1, 1) == "#"
end

function transfer.tagId(query)
    if not transfer.isTag(query) then
        return query
    end
    return query:sub(2)
end

--- Does inventory item (name + optional tags list) match query (exact or #tag)?
function transfer.matches(itemName, tags, query)
    if not query or query == "" then
        return true
    end
    if not transfer.isTag(query) then
        return itemName == query
    end
    local tagId = transfer.tagId(query)
    if type(tags) == "table" then
        for i = 1, #tags do
            if tags[i] == tagId then
                return true
            end
        end
        if tags[tagId] then
            return true
        end
    end
    local fb = tagFallbacks[tagId]
    if fb then
        return fb(itemName) == true
    end
    return false
end

--- TFC/Firmalife food we should inspect for spoil (when food module registered).
function transfer.isFoodItem(name)
    if foodItemCheck then
        return foodItemCheck(name) == true
    end
    return false
end

--- Best-effort spoil detect (delegates to registered check).
function transfer.isSpoiled(detail)
    if spoilCheck then
        return spoilCheck(detail) == true
    end
    return false
end

local function itemTagsFromDetail(detail)
    if not detail then
        return nil
    end
    if type(detail.tags) == "table" then
        return detail.tags
    end
    return nil
end

--- Detail for #tags, or exact food ids when food module registered (spoil filter).
local function slotDetail(inv, slot, itemQuery, itemName)
    if not inv.getItemDetail then
        return nil
    end
    local need = transfer.isTag(itemQuery)
        or (itemName and transfer.isFoodItem(itemName))
    if not need then
        return nil
    end
    local ok, detail = pcall(inv.getItemDetail, slot)
    if ok then
        return detail
    end
    return nil
end

local function slotUsable(itemName, detail, itemQuery)
    if transfer.isSpoiled(detail) then
        return false
    end
    return transfer.matches(itemName, itemTagsFromDetail(detail), itemQuery)
end

local function transferItems(from, to, itemQuery, amount)
    if not from or not to or from == to then
        return 0
    end
    if not peripheral.isPresent(from) or not peripheral.isPresent(to) then
        return 0
    end
    local source = peripheral.wrap(from)
    if not source or not source.list or not source.pushItems then
        return 0
    end
    local movedTotal = 0
    local moveAll = amount == -1
    amount = tonumber(amount) or 0
    if not moveAll and amount <= 0 then
        return 0
    end

    local listed = source.list()
    if not listed then
        return 0
    end

    local n = 0
    for slot, item in pairs(listed) do
        if moveAll or movedTotal < amount then
            local detail = slotDetail(source, slot, itemQuery, item.name)
            if slotUsable(item.name, detail, itemQuery) then
                local limit = moveAll and item.count or (amount - movedTotal)
                local moved = source.pushItems(to, slot, limit) or 0
                movedTotal = movedTotal + moved
            end
        end
        n = n + 1
        if n % 8 == 0 then
            sleep(0)
        end
    end

    return movedTotal
end

setmetatable(transfer, {
    __call = function(_, from, to, itemName, amount)
        return transferItems(from, to, itemName, amount)
    end,
})

function transfer.countItem(invName, itemQuery)
    if not invName or not peripheral.isPresent(invName) then
        return 0
    end
    local inv = peripheral.wrap(invName)
    if not inv or not inv.list then
        return 0
    end
    local total = 0
    local listed = inv.list()
    if not listed then
        return 0
    end
    local n = 0
    for slot, item in pairs(listed) do
        local detail = slotDetail(inv, slot, itemQuery, item.name)
        if slotUsable(item.name, detail, itemQuery) then
            total = total + (item.count or 0)
        end
        n = n + 1
        if n % 8 == 0 then
            sleep(0)
        end
    end
    return total
end

function transfer.countFromMany(sources, itemQuery)
    local total = 0
    if not sources then
        return 0
    end
    for i = 1, #sources do
        total = total + transfer.countItem(sources[i], itemQuery)
    end
    return total
end

function transfer.fromMany(sources, to, itemQuery, amount)
    if not sources or not to then
        return 0
    end
    local movedTotal = 0
    local moveAll = amount == -1
    for i = 1, #sources do
        local from = sources[i]
        if from and from ~= to and peripheral.isPresent(from) then
            if moveAll then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, -1)
            elseif movedTotal < amount then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, amount - movedTotal)
            end
            if not moveAll and movedTotal >= amount then
                break
            end
        end
    end
    return movedTotal
end

function transfer.toMany(from, destinations, itemQuery, amount)
    if not from or not destinations then
        return 0
    end
    local movedTotal = 0
    local moveAll = amount == -1
    for i = 1, #destinations do
        local to = destinations[i]
        if to and to ~= from and peripheral.isPresent(to) then
            if moveAll then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, -1)
            elseif movedTotal < amount then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, amount - movedTotal)
            end
            if not moveAll and movedTotal >= amount then
                break
            end
        end
    end
    return movedTotal
end

function transfer.countFluid(tankName, fluidName)
    local tank = peripheral.wrap(tankName)
    if not tank or type(tank.tanks) ~= "function" then
        return 0
    end
    local total = 0
    for _, t in pairs(tank.tanks()) do
        if t and t.name == fluidName then
            total = total + (t.amount or 0)
        end
    end
    return total
end

function transfer.fluid(from, to, fluidName, amount)
    if not from or not to then
        return 0
    end
    local source = peripheral.wrap(from)
    if not source or type(source.pushFluid) ~= "function" then
        return 0
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then
        return 0
    end
    local moved = source.pushFluid(to, amount, fluidName)
    return tonumber(moved) or 0
end

return transfer
end

-- module: food (craft/food.lua)
package.preload["food"] = function(...)
-- TFC/Firmalife food helpers for craft (tag fallbacks + spoil).
-- Registers into shared/transfer on require so craft stock/push skip rotten food.

local transfer = require("transfer")

local food = {}

local function isRawMeatName(name)
    if type(name) ~= "string" or name:find("/cooked_", 1, true) then
        return false
    end
    local leaf = name:match("([^/]+)$") or ""
    local raw = {
        beef = true, pork = true, chicken = true, mutton = true, bear = true,
        horse_meat = true, venison = true, wolf = true, rabbit = true, hyena = true,
        duck = true, quail = true, chevon = true, camelidae = true, gran_feline = true,
        turtle = true, frog_legs = true, cod = true, salmon = true, tropical_fish = true,
        bluegill = true, largemouth_bass = true, smallmouth_bass = true, rainbow_trout = true,
        lake_trout = true, lake_whitefish = true, crappie = true, oysters = true,
        calamari = true,
    }
    if raw[leaf] then
        return true
    end
    if leaf:find("bass", 1, true) or leaf:find("trout", 1, true)
        or leaf:find("fish", 1, true) or leaf:find("meat", 1, true) then
        return name:sub(1, 9) == "tfc:food/" or name:sub(1, 9) == "tfg:food/"
            or name:sub(1, 15) == "firmalife:food/"
    end
    return false
end

local function isCookedMeatName(name)
    if type(name) ~= "string" then
        return false
    end
    local rawName = name:gsub("/cooked_", "/", 1)
    if rawName == name then
        return false
    end
    return isRawMeatName(rawName)
end

food.isRawMeatName = isRawMeatName
food.isCookedMeatName = isCookedMeatName

local TAG_FALLBACKS = {
    ["tfc:foods/raw_meats"] = isRawMeatName,
    ["tfc:foods/cooked_meats"] = isCookedMeatName,
    ["firmalife:foods/cooked_meats_and_substitutes"] = isCookedMeatName,
    ["firmalife:foods/pizza_ingredients"] = function(name)
        if isCookedMeatName(name) then
            return true
        end
        return name == "tfg:food/magmango"
    end,
}

function food.isFoodItem(name)
    if type(name) ~= "string" then
        return false
    end
    return name:sub(1, 9) == "tfc:food/"
        or name:sub(1, 9) == "tfg:food/"
        or name:sub(1, 15) == "firmalife:food/"
        or name:sub(1, 16) == "firmalife:spice/"
        or name:find(":food/", 1, true) ~= nil
end

function food.isSpoiled(detail)
    if type(detail) ~= "table" then
        return false
    end
    if detail.rotten == true or detail.spoiled == true or detail.decayed == true then
        return true
    end
    local decay = tonumber(detail.decay)
    if decay and decay >= 1 then
        return true
    end
    if type(detail.food) == "table" then
        local f = detail.food
        if f.rotten == true or f.spoiled == true then
            return true
        end
        decay = tonumber(f.decay)
        if decay and decay >= 1 then
            return true
        end
    end
    local dn = tostring(detail.displayName or detail.display_name or ""):lower()
    if dn:find("rotten", 1, true)
        or dn:find("spoiled", 1, true)
        or dn:find("испорч", 1, true)
        or dn:find("гниль", 1, true)
    then
        return true
    end
    return false
end

--- Wire food checks into a transfer module (defaults to shared transfer).
function food.register(t)
    t = t or transfer
    if t.setSpoilCheck then
        t.setSpoilCheck(food.isSpoiled)
    end
    if t.setFoodItemCheck then
        t.setFoodItemCheck(food.isFoodItem)
    end
    if t.registerTagFallback then
        for tag, fn in pairs(TAG_FALLBACKS) do
            t.registerTagFallback(tag, fn)
        end
    end
    return t
end

food.register(transfer)

return food
end

-- module: util (shared/util.lua)
package.preload["util"] = function(...)
-- Shared string / path helpers for CC:Tweaked scripts.

local util = {}

function util.trim(s)
    return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

function util.split(s, sep)
    local out = {}
    s = tostring(s or "")
    for part in (s .. sep):gmatch("(.-)" .. sep) do
        out[#out + 1] = part
    end
    return out
end

--- Resolve a config path relative to the running program directory.
function util.resolvePath(path, defaultName)
    path = path or defaultName
    if not path then
        error("resolvePath: path required", 2)
    end
    if path:sub(1, 1) == "/" then
        return path
    end
    local base = ""
    if shell and shell.getRunningProgram then
        local prog = shell.getRunningProgram()
        if prog then
            base = fs.getDir(prog)
        end
    end
    return fs.combine(base, path)
end

--- Read entire file as string, or nil if missing.
function util.readAll(path)
    if not path or not fs.exists(path) then
        return nil
    end
    local file = fs.open(path, "r")
    if not file then
        return nil
    end
    local text = file.readAll()
    file.close()
    return text
end

--- Basename of the running program without .lua (e.g. pizza_maintain).
function util.programStem()
    if not (shell and shell.getRunningProgram) then
        return nil
    end
    local prog = shell.getRunningProgram()
    if not prog then
        return nil
    end
    local name = fs.getName(prog)
    return (name:gsub("%.lua$", ""))
end

--- Lines of `[section]` from a sectioned cfg. Nil if file/section missing.
function util.cfgSectionLines(path, section)
    local text = util.readAll(path)
    if not text or not section then
        return nil
    end
    local current = nil
    local buf = {}
    local found = false
    for line in (text .. "\n"):gmatch("(.-)\n") do
        local sec = line:match("^%s*%[([%w_]+)%]%s*$")
        if sec then
            if found then
                break
            end
            if sec == section then
                found = true
                current = sec
                buf = {}
            else
                current = nil
            end
        elseif found and current == section then
            buf[#buf + 1] = line
        end
    end
    if not found then
        return nil
    end
    return buf
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Try sectioned cfg at path; return lines, label or nil.
local function trySectioned(path, section)
    if not path or not fs.exists(path) then
        return nil
    end
    local sectionLines = util.cfgSectionLines(path, section)
    if not sectionLines then
        return nil
    end
    return sectionLines, path .. "[" .. section .. "]"
end

--- Config lines for a logical section.
-- Order: explicit path → <program>.cfg [section] → craft.cfg [section] → fallbackName.
-- Returns lines, label (for errors).
function util.openConfigLines(explicitPath, section, fallbackName)
    if explicitPath then
        local path = util.resolvePath(explicitPath)
        local text = util.readAll(path)
        if not text then
            error("Cannot open " .. path, 2)
        end
        return linesFromText(text), path
    end

    local stem = util.programStem()
    if stem then
        local lines, label = trySectioned(util.resolvePath(nil, stem .. ".cfg"), section)
        if lines then
            return lines, label
        end
    end

    local lines, label = trySectioned(util.resolvePath(nil, "craft.cfg"), section)
    if lines then
        return lines, label
    end

    local path = util.resolvePath(nil, fallbackName)
    local text = util.readAll(path)
    if not text then
        local hint = stem and (stem .. ".cfg") or "program.cfg"
        error(
            "Cannot open " .. path
                .. " (deploy "
                .. hint
                .. " next to the program, or "
                .. tostring(fallbackName)
                .. ")",
            2
        )
    end
    return linesFromText(text), path
end

--- Short display name: last path segment after `/`.
function util.short(id)
    id = tostring(id or "")
    return id:match("([^/]+)$") or id
end

function util.clamp(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

return util
end

-- module: recipes (craft/recipes.lua)
package.preload["recipes"] = function(...)
-- Parse recipes.cfg into structured recipe tables.
--
-- Recipe fields:
--   machine  string   e.g. "tfg:hv_food_processor_3"
--   base     string   machine without circuit suffix
--   circuit  number   trailing _N from machine id
--   inputs   { { name, count, fluid? }, ... }
--   outputs  { { name, count, fluid? }, ... }
--   flag     "grow" | "craft" | "processing"
--   oneshot  bool   if true, feed one craft then wait for outputs before next

local util = require("util")

local recipes = {}

--- Override in tests; default prints a warning line.
function recipes.warn(msg)
    print(tostring(msg))
end

--- Parse "mod:id 4" or "mod:fluid 100mb" or "#tag:path 1"
local function parseStack(token)
    token = util.trim(token)
    if token == "" or token == "-" or token:lower() == "null" then
        return nil
    end

    local name, amount, unit = token:match("^(%S+)%s+(%d+)(mb?)$")
    if name then
        return {
            name = name,
            count = tonumber(amount),
            fluid = true,
        }
    end

    name, amount = token:match("^(%S+)%s+(%-?%d+)$")
    if not name then
        error("Bad stack token: " .. token)
    end

    return {
        name = name,
        count = tonumber(amount),
        fluid = false,
    }
end

local function parseStackList(field)
    field = util.trim(field)
    if field == "" or field == "-" or field:lower() == "null" then
        return {}
    end

    field = field:gsub("^%(", ""):gsub("%)$", "")

    local stacks = {}
    for _, token in ipairs(util.split(field, ",")) do
        local stack = parseStack(token)
        if stack then
            stacks[#stacks + 1] = stack
        end
    end
    return stacks
end

local function parseMachine(machine)
    machine = util.trim(machine)
    local base, circuit = machine:match("^(.-)_(%d+)$")
    if base and circuit then
        return machine, base, tonumber(circuit)
    end
    return machine, machine, nil
end

local function parseFlagField(field, lineNo)
    field = util.trim(field or ""):lower()
    local tokens = {}
    for token in field:gmatch("%S+") do
        tokens[#tokens + 1] = token
    end
    if #tokens == 0 then
        error(("Recipe line %s: empty flag"):format(tostring(lineNo)))
    end

    local flag = tokens[1]
    if flag ~= "grow" and flag ~= "craft" and flag ~= "processing" then
        error(("Recipe line %s: unknown flag %q"):format(tostring(lineNo), flag))
    end

    local oneshot = false
    for i = 2, #tokens do
        local t = tokens[i]
        if t == "oneshot" or t == "one" or t == "serial" then
            oneshot = true
        else
            error(("Recipe line %s: unknown flag option %q"):format(tostring(lineNo), t))
        end
    end

    -- Optional 5th field: oneshot / serial (also accepted in flag field as "processing oneshot")
    return flag, oneshot
end

function recipes.parseLine(line, lineNo)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return nil
    end

    local parts = util.split(line, "|")
    if #parts < 4 then
        error(("Recipe line %s: expected machine|inputs|outputs|flag[|oneshot]"):format(tostring(lineNo)))
    end

    local machineRaw = util.trim(parts[1])
    local machine, base, circuit = parseMachine(machineRaw)
    local flag, oneshot = parseFlagField(parts[4], lineNo)

    if #parts >= 5 then
        local extra = util.trim(parts[5]):lower()
        if extra == "oneshot" or extra == "one" or extra == "serial" then
            oneshot = true
        elseif extra ~= "" then
            error(("Recipe line %s: unknown option %q (use oneshot)"):format(tostring(lineNo), extra))
        end
    end

    return {
        machine = machine,
        base = base,
        circuit = circuit,
        inputs = parseStackList(parts[2]),
        outputs = parseStackList(parts[3]),
        flag = flag,
        oneshot = oneshot,
        line = lineNo,
    }
end

--- Map non-fluid output name -> list of recipes that produce it (cfg order).
function recipes.findDuplicateOutputs(list)
    local byOut = {}
    if not list then
        return byOut
    end
    for i = 1, #list do
        local recipe = list[i]
        local outs = recipe.outputs or {}
        for j = 1, #outs do
            local out = outs[j]
            if out and not out.fluid and out.name then
                local bucket = byOut[out.name]
                if not bucket then
                    bucket = {}
                    byOut[out.name] = bucket
                end
                bucket[#bucket + 1] = recipe
            end
        end
    end
    local dups = {}
    for name, bucket in pairs(byOut) do
        if #bucket > 1 then
            dups[name] = bucket
        end
    end
    return dups
end

local function warnDuplicateOutputs(list)
    local dups = recipes.findDuplicateOutputs(list)
    for name, bucket in pairs(dups) do
        local lines = {}
        for i = 1, #bucket do
            lines[#lines + 1] = tostring(bucket[i].line or "?")
        end
        recipes.warn(string.format(
            "recipes: duplicate output %s — using first (lines %s)",
            tostring(name),
            table.concat(lines, ", ")
        ))
    end
end

--- Load recipes. Prefers <program>.cfg [recipes], else recipes.cfg.
-- Duplicate non-fluid outputs: keep cfg order (first wins in craft_plan); warn once.
function recipes.load(path)
    local lines = util.openConfigLines(path, "recipes", "recipes.cfg")
    local list = {}
    for n = 1, #lines do
        local recipe = recipes.parseLine(lines[n], n)
        if recipe then
            list[#list + 1] = recipe
        end
    end
    warnDuplicateOutputs(list)
    return list
end

function recipes.filter(list, pred)
    local out = {}
    for i = 1, #list do
        if pred(list[i]) then
            out[#out + 1] = list[i]
        end
    end
    return out
end

function recipes.byFlag(list, flag)
    return recipes.filter(list, function(r) return r.flag == flag end)
end

function recipes.byMachine(list, machine)
    return recipes.filter(list, function(r) return r.machine == machine end)
end

--- Primary non-fluid output stack, or nil.
function recipes.primaryOutput(recipe)
    if not recipe or not recipe.outputs then
        return nil
    end
    for i = 1, #recipe.outputs do
        if not recipe.outputs[i].fluid then
            return recipe.outputs[i]
        end
    end
    return nil
end

--- Stable key for machine locking: same recipe identity, different from siblings on same machine.
function recipes.recipeKey(recipe)
    if not recipe then
        return "unknown"
    end
    local out = recipes.primaryOutput(recipe)
    local outName = out and out.name or "-"
    return tostring(recipe.machine) .. "|" .. outName
end

return recipes
end

-- module: storage (craft/storage.lua)
package.preload["storage"] = function(...)
-- Parse storage.cfg into named inventories, sources, seeds, routes, settings.

local util = require("util")

local storage = {}

local function emptyConfig()
    return {
        named = {},
        sources = {},
        fluids = {}, -- key -> { peripheral, fluid }
        seeds = {},
        routes = {},
        settings = {},
    }
end

local NAMED_KEYS = {
    main = true,
    flora = true,
    overflow = true,
    seed_chest_prefix = true,
    output_bus_prefix = true,
}

local function parseLine(cfg, line, lineNo)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return
    end

    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end

    local key = parts[1]
    if not key or key == "" then
        error(("storage.cfg line %s: empty key"):format(tostring(lineNo)))
    end

    if key == "source" then
        if #parts < 3 then
            error(("storage.cfg line %s: source | item | peripheral"):format(tostring(lineNo)))
        end
        cfg.sources[parts[2]] = parts[3]
        return
    end

    if key == "fluid_source" then
        if #parts < 4 then
            error(("storage.cfg line %s: fluid_source | tagOrFluid | tank | concreteFluid"):format(tostring(lineNo)))
        end
        cfg.fluids[parts[2]] = {
            peripheral = parts[3],
            fluid = parts[4],
        }
        return
    end

    if key == "seed" then
        if #parts < 3 then
            error(("storage.cfg line %s: seed | crop | seedItem"):format(tostring(lineNo)))
        end
        cfg.seeds[parts[2]] = parts[3]
        return
    end

    if key == "route" then
        if #parts < 3 then
            error(("storage.cfg line %s: route | item | dest"):format(tostring(lineNo)))
        end
        cfg.routes[parts[2]] = parts[3]
        return
    end

    if NAMED_KEYS[key] then
        if #parts < 2 then
            error(("storage.cfg line %s: %s | value"):format(tostring(lineNo), key))
        end
        cfg.named[key] = parts[2]
        return
    end

    if #parts >= 2 then
        cfg.settings[key] = parts[2]
        return
    end

    error(("storage.cfg line %s: bad directive %q"):format(tostring(lineNo), key))
end

local function resolveAlias(cfg, dest)
    if not dest then
        return nil
    end
    if dest == "main" or dest == "flora" or dest == "overflow" then
        return cfg.named[dest]
    end
    return dest
end

--- Load storage settings. Prefers <program>.cfg [storage], else storage.cfg.
function storage.load(path)
    local lines = util.openConfigLines(path, "storage", "storage.cfg")
    local cfg = emptyConfig()
    for n = 1, #lines do
        parseLine(cfg, lines[n], n)
    end

    function cfg.main()
        return cfg.named.main
    end

    function cfg.flora()
        return cfg.named.flora
    end

    function cfg.overflow()
        return cfg.named.overflow
    end

    function cfg.seedChestPrefix()
        return cfg.named.seed_chest_prefix or "gtceu:lv_super_chest_"
    end

    function cfg.outputBusPrefix()
        return cfg.named.output_bus_prefix or "gtceu:mv_output_bus_"
    end

    function cfg.sourceOf(itemId)
        return cfg.sources[itemId] or cfg.named.main
    end

    --- @return { peripheral, fluid } | nil
    function cfg.fluidSourceOf(fluidOrTag)
        return cfg.fluids[fluidOrTag]
    end

    function cfg.destFor(itemId)
        local route = cfg.routes[itemId]
        if route then
            return resolveAlias(cfg, route) or cfg.named.main
        end
        return cfg.named.main
    end

    --- Ordered unique inventories used for both counting and pulling an item.
    -- Order: explicit source → dest/route → main.
    -- Overflow crate is included ONLY when it is that item's home (route/source),
    -- never as a dump for fridge food (pizza etc. rot at room temp).
    function cfg.pullSources(itemId, extra)
        local seen = {}
        local list = {}
        local function add(inv)
            if inv and not seen[inv] and peripheral.isPresent(inv) then
                seen[inv] = true
                list[#list + 1] = inv
            end
        end

        add(cfg.sources[itemId]) -- explicit source only (not default main yet)
        add(cfg.destFor(itemId))
        add(cfg.named.main)
        local overflow = cfg.named.overflow
        if overflow and (cfg.sources[itemId] == overflow or cfg.destFor(itemId) == overflow) then
            add(overflow)
        end
        if extra then
            if type(extra) == "string" then
                add(extra)
            elseif type(extra) == "table" then
                for i = 1, #extra do
                    add(extra[i])
                end
            end
        end
        -- Fallback: if nothing present, still return default source name for errors.
        if #list == 0 then
            local fallback = cfg.sourceOf(itemId)
            if fallback then
                list[1] = fallback
            end
        end
        return list
    end

    function cfg.seedDest(index)
        index = tonumber(index) or 0
        return cfg.seedChestPrefix() .. tostring(index)
    end

    function cfg.outputBus(index)
        index = tonumber(index) or 0
        return cfg.outputBusPrefix() .. tostring(index)
    end

    function cfg.seedForCrop(cropId)
        return cfg.seeds[cropId]
    end

    function cfg.get(key, default)
        local v = cfg.settings[key]
        if v == nil then
            return default
        end
        return v
    end

    function cfg.getNumber(key, default)
        local v = tonumber(cfg.settings[key])
        if v == nil then
            return default
        end
        return v
    end

    return cfg
end

return storage
end

-- module: peripherals (craft/peripherals.lua)
package.preload["peripherals"] = function(...)
-- Resolve GT / TFG machine peripherals from recipe machine ids.
-- Yields while scanning; supports a per-request cache table.

local peripherals = {}

local function peripheralTypes(name)
    local ok, ptype = pcall(peripheral.getType, name)
    if not ok or not ptype then
        return {}
    end
    if type(ptype) == "table" then
        return ptype
    end
    return { ptype }
end

local function typeMatchesRecipe(ptype, recipe)
    if not ptype then
        return false
    end
    ptype = tostring(ptype)
    if ptype == recipe.machine or ptype == recipe.base then
        return true
    end
    local shortBase = recipe.base:match("([^:]+)$") or recipe.base
    if ptype:find(shortBase, 1, true) then
        return true
    end
    if recipe.flag == "grow" and ptype:lower():find("electric_greenhouse", 1, true) then
        return true
    end
    return false
end

local function nameMatchesRecipe(name, recipe)
    if name == recipe.machine or name == recipe.base then
        return true
    end
    local prefix = recipe.base .. "_"
    if name:sub(1, #prefix) == prefix then
        return true
    end
    local shortBase = recipe.base:match("([^:]+)$") or recipe.base
    if name:find(shortBase, 1, true) then
        return true
    end
    if recipe.flag == "grow" and name:lower():find("greenhouse", 1, true) then
        return true
    end
    return false
end

local function collectMatches(recipe)
    local names = peripheral.getNames()
    local matches = {}
    local seen = {}

    for i = 1, #names do
        local name = names[i]
        local matched = nameMatchesRecipe(name, recipe)
        if not matched then
            local types = peripheralTypes(name)
            for j = 1, #types do
                if typeMatchesRecipe(types[j], recipe) then
                    matched = true
                    break
                end
            end
        end
        if matched and not seen[name] then
            seen[name] = true
            matches[#matches + 1] = name
        end
        -- Yield every few peripherals — large TFG networks otherwise kill the computer.
        if i % 8 == 0 then
            sleep(0)
        end
    end
    return matches
end

--- Resolve a physical machine peripheral for a recipe.
-- Optional cache table: cache[recipe.machine] = name|false
function peripherals.resolveMachine(recipe, cache)
    if not recipe then
        return nil
    end
    local key = recipe.machine or "?"
    if cache then
        local hit = cache[key]
        if hit ~= nil then
            if hit == false then
                return nil
            end
            return hit
        end
    end

    local matches = collectMatches(recipe)
    local found = nil
    if #matches > 0 then
        for i = 1, #matches do
            if matches[i] == recipe.machine then
                found = matches[i]
                break
            end
        end
        if not found and recipe.circuit ~= nil then
            local suffix = "_" .. tostring(recipe.circuit)
            for i = 1, #matches do
                if matches[i]:sub(-#suffix) == suffix then
                    found = matches[i]
                    break
                end
            end
        end
        if not found then
            table.sort(matches)
            found = matches[1]
        end
    end

    if cache then
        cache[key] = found or false
    end
    return found
end

return peripherals
end

-- module: greenhouse (craft/greenhouse.lua)
package.preload["greenhouse"] = function(...)
-- Electric greenhouse control.
-- Greenhouses stay disabled by default. A short enable pulse is enough for
-- GregTech to finish one grow recipe after the machine is turned off again.

local Greenhouse = {}

local DEFAULT_PULSE = 3 -- seconds; enough to latch one grow cycle

local function wrapMachine(machineName)
    local machine = peripheral.wrap(machineName)
    if not machine then
        return nil, "greenhouse not found: " .. tostring(machineName)
    end
    if type(machine.setWorkingEnabled) ~= "function" then
        return nil, "no setWorkingEnabled: " .. tostring(machineName)
    end
    return machine
end

function Greenhouse.setEnabled(machineName, enabled)
    local machine, err = wrapMachine(machineName)
    if not machine then
        return false, err
    end
    machine.setWorkingEnabled(enabled and true or false)
    return true
end

--- Keep greenhouse off (default state).
function Greenhouse.disable(machineName)
    return Greenhouse.setEnabled(machineName, false)
end

function Greenhouse.enable(machineName)
    return Greenhouse.setEnabled(machineName, true)
end

--- Brief on-pulse, then force off. Recipe continues to completion on its own.
-- @return ok, err
function Greenhouse.pulse(machineName, pulseSeconds)
    local machine, err = wrapMachine(machineName)
    if not machine then
        return false, err
    end

    pulseSeconds = tonumber(pulseSeconds) or DEFAULT_PULSE
    if pulseSeconds < 1 then
        pulseSeconds = DEFAULT_PULSE
    end

    machine.setWorkingEnabled(true)
    sleep(pulseSeconds)
    machine.setWorkingEnabled(false)
    return true
end

--- Disable every resolved grow machine (call on cleaner/craft startup).
-- @param resolveFn function(recipe) -> peripheral name | nil
-- @param growRecipes list of grow recipes
function Greenhouse.disableAll(resolveFn, growRecipes)
    if type(resolveFn) ~= "function" or type(growRecipes) ~= "table" then
        return
    end
    local seen = {}
    for i = 1, #growRecipes do
        local name = resolveFn(growRecipes[i])
        if name and not seen[name] then
            seen[name] = true
            Greenhouse.disable(name)
        end
    end
end

-- Back-compat alias used by older callers
Greenhouse.runFor = Greenhouse.pulse

return Greenhouse
end

-- entry: craft/greenhouse_clean.lua
-- Autonomous greenhouse output sorter.
-- Requires on this computer: greenhouse_clean.cfg (or storage.cfg + recipes.cfg).
-- Works on any computer attached to the same peripheral network.
--
-- Bundle:  python tools/bundle_project.py craft greenhouse_clean
-- Deploy:  dist/greenhouse_clean.lua + greenhouse_clean.cfg

require("food")
local transfer = require("transfer")
local recipes = require("recipes")
local storage = require("storage")
local peripherals = require("peripherals")
local util = require("util")

local FLORA_ITEM = "tfg:flora_pellets"

--- Seed/plant chest for this item, if it matches any grow recipe seed mapping.
local function seedDestForItem(store, growRecipes, itemName)
    for i = 1, #growRecipes do
        local recipe = growRecipes[i]
        local primary = recipes.primaryOutput(recipe)
        local crop = primary and primary.name
        local seedItem = crop and store.seedForCrop(crop)
        if seedItem and seedItem == itemName then
            return store.seedDest(recipe.circuit or 0)
        end
    end
    return nil
end

local function destForItem(store, growRecipes, itemName)
    if itemName == FLORA_ITEM then
        return store.flora()
    end

    local seedDest = seedDestForItem(store, growRecipes, itemName)
    if seedDest then
        return seedDest
    end

    return store.destFor(itemName)
end

--- Move to dest. Spill into overflow ONLY if that item's configured home is overflow
-- (basil leaves). Never dump perishable fridge food into a bronze crate.
local function moveToDest(store, from, dest, itemName)
    local before = transfer.countItem(from, itemName)
    if before <= 0 then
        return 0
    end
    if not dest or not peripheral.isPresent(dest) or from == dest then
        return 0
    end

    local moved = transfer(from, dest, itemName, -1)
    local left = transfer.countItem(from, itemName)
    local overflow = store.overflow()
    local home = store.destFor(itemName)

    if left > 0 and overflow and home == overflow and dest ~= overflow
        and peripheral.isPresent(overflow)
    then
        local buffered = transfer(from, overflow, itemName, -1)
        if buffered > 0 then
            print(("overflow: %s x%s -> %s"):format(
                util.short(itemName), tostring(buffered), util.short(overflow)
            ))
        end
        moved = moved + buffered
    elseif left > 0 and dest ~= overflow then
        print(("dest full, kept: %s x%s (no crate dump)"):format(
            util.short(itemName), tostring(left)
        ))
    end

    return moved
end

local function drainOverflow(store, growRecipes)
    local overflow = store.overflow()
    if not overflow or not peripheral.isPresent(overflow) then
        return
    end

    local inv = peripheral.wrap(overflow)
    if not inv or not inv.list then
        return
    end

    local seen = {}
    for _, item in pairs(inv.list()) do
        local name = item.name
        if not seen[name] then
            seen[name] = true
            -- Routed items (basil leaves) stay in overflow — that IS their home.
            if store.routes[name] then
                -- keep
            else
                local dest = destForItem(store, growRecipes, name)
                if dest and dest ~= overflow and peripheral.isPresent(dest) then
                    local n = transfer(overflow, dest, name, -1)
                    if n > 0 then
                        print(("drain: %s x%s -> %s"):format(
                            util.short(name), tostring(n), util.short(dest)
                        ))
                    end
                end
            end
        end
    end
end

local function cleanGreenhouse(store, growRecipes, recipe)
    -- Products leave via GT output bus, not the greenhouse controller inventory.
    local source = store.outputBus(recipe.circuit or 0)
    if not peripheral.isPresent(source) then
        source = peripherals.resolveMachine(recipe)
    end
    if not source then
        print(("no output bus/greenhouse for %s"):format(recipe.machine))
        return
    end

    local inv = peripheral.wrap(source)
    if not inv or not inv.list then
        return
    end

    local seen = {}
    for _, item in pairs(inv.list()) do
        local name = item.name
        if not seen[name] then
            seen[name] = true
            local dest = destForItem(store, growRecipes, name)
            if dest and peripheral.isPresent(dest) then
                moveToDest(store, source, dest, name)
            elseif dest then
                print(("missing dest %s for %s"):format(tostring(dest), util.short(name)))
            end
        end
    end
end

local function main()
    local greenhouse = require("greenhouse")
    local store = storage.load()
    local all = recipes.load()
    local growRecipes = recipes.byFlag(all, "grow")
    local interval = store.getNumber("clean_interval", 2)

    greenhouse.disableAll(peripherals.resolveMachine, growRecipes)

    print(("greenhouse_clean: %s grow recipes, interval %ss (GH off)"):format(
        tostring(#growRecipes), tostring(interval)
    ))

    while true do
        greenhouse.disableAll(peripherals.resolveMachine, growRecipes)
        drainOverflow(store, growRecipes)
        for i = 1, #growRecipes do
            local ok, err = pcall(cleanGreenhouse, store, growRecipes, growRecipes[i])
            if not ok then
                print("clean error: " .. tostring(err))
            end
        end
        sleep(interval)
    end
end

main()
