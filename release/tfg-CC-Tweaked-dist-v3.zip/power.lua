-- Bundled from power/main.lua — do not edit by hand; rebuild with tools/bundle_project.py
-- Also copy power.cfg next to this file on the computer.
-- Generated package.preload modules + entrypoint.

-- module: util (shared/util.lua)
package.preload["util"] = function(...)
-- Shared string / path helpers for CC:Tweaked scripts.

local util = {}

function util.trim(s)
    return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

function util.split(s, sep)
    local out = {}
    s = tostring(s or "")
    for part in (s .. sep):gmatch("(.-)" .. sep) do
        out[#out + 1] = part
    end
    return out
end

--- Resolve a config path relative to the running program directory.
function util.resolvePath(path, defaultName)
    path = path or defaultName
    if not path then
        error("resolvePath: path required", 2)
    end
    if path:sub(1, 1) == "/" then
        return path
    end
    local base = ""
    if shell and shell.getRunningProgram then
        local prog = shell.getRunningProgram()
        if prog then
            base = fs.getDir(prog)
        end
    end
    return fs.combine(base, path)
end

--- Read entire file as string, or nil if missing.
function util.readAll(path)
    if not path or not fs.exists(path) then
        return nil
    end
    local file = fs.open(path, "r")
    if not file then
        return nil
    end
    local text = file.readAll()
    file.close()
    return text
end

--- Basename of the running program without .lua (e.g. pizza_maintain).
function util.programStem()
    if not (shell and shell.getRunningProgram) then
        return nil
    end
    local prog = shell.getRunningProgram()
    if not prog then
        return nil
    end
    local name = fs.getName(prog)
    return (name:gsub("%.lua$", ""))
end

--- Lines of `[section]` from a sectioned cfg. Nil if file/section missing.
function util.cfgSectionLines(path, section)
    local text = util.readAll(path)
    if not text or not section then
        return nil
    end
    local current = nil
    local buf = {}
    local found = false
    for line in (text .. "\n"):gmatch("(.-)\n") do
        local sec = line:match("^%s*%[([%w_]+)%]%s*$")
        if sec then
            if found then
                break
            end
            if sec == section then
                found = true
                current = sec
                buf = {}
            else
                current = nil
            end
        elseif found and current == section then
            buf[#buf + 1] = line
        end
    end
    if not found then
        return nil
    end
    return buf
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Try sectioned cfg at path; return lines, label or nil.
local function trySectioned(path, section)
    if not path or not fs.exists(path) then
        return nil
    end
    local sectionLines = util.cfgSectionLines(path, section)
    if not sectionLines then
        return nil
    end
    return sectionLines, path .. "[" .. section .. "]"
end

--- Config lines for a logical section.
-- Order: explicit path → <program>.cfg [section] → craft.cfg [section] → fallbackName.
-- Returns lines, label (for errors).
function util.openConfigLines(explicitPath, section, fallbackName)
    if explicitPath then
        local path = util.resolvePath(explicitPath)
        local text = util.readAll(path)
        if not text then
            error("Cannot open " .. path, 2)
        end
        return linesFromText(text), path
    end

    local stem = util.programStem()
    if stem then
        local lines, label = trySectioned(util.resolvePath(nil, stem .. ".cfg"), section)
        if lines then
            return lines, label
        end
    end

    local lines, label = trySectioned(util.resolvePath(nil, "craft.cfg"), section)
    if lines then
        return lines, label
    end

    local path = util.resolvePath(nil, fallbackName)
    local text = util.readAll(path)
    if not text then
        local hint = stem and (stem .. ".cfg") or "program.cfg"
        error(
            "Cannot open " .. path
                .. " (deploy "
                .. hint
                .. " next to the program, or "
                .. tostring(fallbackName)
                .. ")",
            2
        )
    end
    return linesFromText(text), path
end

--- Short display name: last path segment after `/`.
function util.short(id)
    id = tostring(id or "")
    return id:match("([^/]+)$") or id
end

function util.clamp(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

return util
end

-- module: cfg_pipe (shared/cfg_pipe.lua)
package.preload["cfg_pipe"] = function(...)
-- Shared pipe-delimited cfg helpers (key | value [| ...]).

local util = require("util")

local cfg_pipe = {}

cfg_pipe.trim = util.trim
cfg_pipe.split = util.split
cfg_pipe.resolvePath = util.resolvePath

function cfg_pipe.parseScale(raw)
    raw = util.trim(tostring(raw or "")):lower()
    if raw == "" or raw == "auto" then
        return "auto"
    end
    local n = tonumber(raw)
    if not n then
        return "auto"
    end
    n = math.floor(n * 2 + 0.5) / 2
    return util.clamp(n, 0.5, 5)
end

--- Split a cfg line into key, value, parts (or nil, errHint).
function cfg_pipe.splitLine(line)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return nil
    end
    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end
    local key = (parts[1] or ""):lower()
    if key == "" then
        return nil, "empty key"
    end
    if parts[2] == nil or parts[2] == "" then
        return nil, key .. " | value"
    end
    return key, parts[2], parts
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Load all lines from a cfg file.
-- @return lines, path, ok
function cfg_pipe.loadLines(path, defaultName)
    path = util.resolvePath(path, defaultName)
    if not fs.exists(path) then
        return nil, path, false
    end
    local text = util.readAll(path)
    if not text then
        error("Cannot open " .. path, 2)
    end
    return linesFromText(text), path, true
end

return cfg_pipe
end

-- module: config (power/config.lua)
package.preload["config"] = function(...)
-- Load power.cfg (defaults if file missing).
-- `config` is project-local (power/); deploy one bundle per computer.

local util = require("util")
local cfg_pipe = require("cfg_pipe")

local config = {}

local function defaults()
    return {
        monitor = "left",
        text_scale = "auto", -- "auto" or number 0.5..5
        substation = nil,
        turbine_substr = "gas_large_turbine",
        engine_substr = "extreme_combustion_engine",
        substation_substr = "power_substation",
        threshold_low = 0.60,
        threshold_high = 0.90,
        threshold_critical = 0.95,
        threshold_warn = 0.75,
        threshold_emergency = 0.40,
        -- Fill mode: enter at threshold_low, exit (and ДГ catch-up target) here
        engine_target = 0.95,
        -- Maintain: step turbines only when |net| > rated * mult
        turbine_rated_eut = 9012,
        turbine_diff_mult = 2,
        maintain_net_eut = -2000, -- legacy unused
        ramp_speed_pct = 60,
        drain_override_eut = -4000, -- below this → ДГ spike response
        spike_clear_eut = 0,        -- unused (kept for cfg compat)
        fill_enable_cooldown = 2,   -- short gap between turbine enables in fill
        cooldown = 20,          -- turbines (inertia)
        engine_cooldown = 2,    -- ДГ recipe ~2s — peaker can switch faster
        engine_off_cooldown = 15, -- after parking a ДГ in maintain (anti-chatter)
        measure_interval = 5,
        boot_wait = 120,
        boot_poll = 2,
        rotor_warn_pct = 20,
        max_history = 4,
        -- Assumed EU/t while engine recipe is mid-cycle (dynamo hatch hides controller OutputPerSec)
        engine_rated_eut = 32768,
    }
end

local parseScale = cfg_pipe.parseScale

local function setNumber(cfg, key, raw, lineNo)
    local n = tonumber(raw)
    if not n then
        error(("power.cfg line %s: %s needs a number"):format(tostring(lineNo), key))
    end
    cfg[key] = n
end

local function parseLine(cfg, line, lineNo)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return
    end

    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end

    local key = (parts[1] or ""):lower()
    local val = parts[2]
    if key == "" then
        error(("power.cfg line %s: empty key"):format(tostring(lineNo)))
    end
    if val == nil or val == "" then
        error(("power.cfg line %s: %s | value"):format(tostring(lineNo), key))
    end

    if key == "monitor" then
        cfg.monitor = val
    elseif key == "text_scale" or key == "monitor_scale" then
        cfg.text_scale = parseScale(val)
    elseif key == "substation" then
        cfg.substation = val
    elseif key == "turbine_substr" then
        cfg.turbine_substr = val
    elseif key == "engine_substr" then
        cfg.engine_substr = val
    elseif key == "substation_substr" then
        cfg.substation_substr = val
    elseif key == "threshold_low" then
        setNumber(cfg, "threshold_low", val, lineNo)
    elseif key == "threshold_high" then
        setNumber(cfg, "threshold_high", val, lineNo)
    elseif key == "threshold_critical" then
        setNumber(cfg, "threshold_critical", val, lineNo)
    elseif key == "threshold_warn" then
        setNumber(cfg, "threshold_warn", val, lineNo)
    elseif key == "threshold_emergency" then
        setNumber(cfg, "threshold_emergency", val, lineNo)
    elseif key == "ramp_speed_pct" then
        setNumber(cfg, "ramp_speed_pct", val, lineNo)
    elseif key == "drain_override_eut" or key == "drain_override" then
        setNumber(cfg, "drain_override_eut", val, lineNo)
    elseif key == "cooldown" then
        setNumber(cfg, "cooldown", val, lineNo)
    elseif key == "engine_cooldown" then
        setNumber(cfg, "engine_cooldown", val, lineNo)
    elseif key == "measure_interval" then
        setNumber(cfg, "measure_interval", val, lineNo)
    elseif key == "boot_wait" then
        setNumber(cfg, "boot_wait", val, lineNo)
    elseif key == "boot_poll" then
        setNumber(cfg, "boot_poll", val, lineNo)
    elseif key == "rotor_warn_pct" then
        setNumber(cfg, "rotor_warn_pct", val, lineNo)
    elseif key == "engine_rated_eut" then
        setNumber(cfg, "engine_rated_eut", val, lineNo)
    elseif key == "engine_target" then
        setNumber(cfg, "engine_target", val, lineNo)
    elseif key == "turbine_rated_eut" then
        setNumber(cfg, "turbine_rated_eut", val, lineNo)
    elseif key == "turbine_diff_mult" then
        setNumber(cfg, "turbine_diff_mult", val, lineNo)
    elseif key == "maintain_net_eut" or key == "maintain_net" then
        setNumber(cfg, "maintain_net_eut", val, lineNo)
    elseif key == "spike_clear_eut" or key == "spike_clear" then
        setNumber(cfg, "spike_clear_eut", val, lineNo)
    elseif key == "fill_enable_cooldown" then
        setNumber(cfg, "fill_enable_cooldown", val, lineNo)
    elseif key == "engine_off_cooldown" then
        setNumber(cfg, "engine_off_cooldown", val, lineNo)
    else
        error(("power.cfg line %s: unknown key %q"):format(tostring(lineNo), key))
    end
end

--- Load power.cfg next to the program; missing file → defaults.
function config.load(path)
    local cfg = defaults()
    local lines, resolved, ok = cfg_pipe.loadLines(path, "power.cfg")
    if not ok then
        return cfg, resolved, false
    end
    for n = 1, #lines do
        parseLine(cfg, lines[n], n)
    end
    return cfg, resolved, true
end

return config
end

-- module: net_watch (shared/net_watch.lua)
package.preload["net_watch"] = function(...)
-- Shared peripheral hotplug / sleep helpers for long-running controllers.

local net_watch = {}

function net_watch.flushEvents(tag)
    tag = tag or "net_watch_flush"
    os.queueEvent(tag)
    while true do
        local ev = os.pullEvent()
        if ev == tag then
            return
        end
    end
end

--- Sleep seconds; return true if a peripheral attach/detach arrived (wakes early).
function net_watch.sleepWatch(seconds)
    local timer = os.startTimer(seconds)
    while true do
        local ev, p1 = os.pullEvent()
        if ev == "timer" and p1 == timer then
            return false
        elseif ev == "peripheral" or ev == "peripheral_detach" then
            return true
        end
    end
end

--- Sleep full duration; call onHotplug() on attach/detach but do not wake early.
function net_watch.sleepDrain(seconds, onHotplug)
    local timer = os.startTimer(seconds)
    while true do
        local ev, p1 = os.pullEvent()
        if ev == "timer" and p1 == timer then
            return
        elseif ev == "peripheral" or ev == "peripheral_detach" then
            if type(onHotplug) == "function" then
                onHotplug()
            end
        end
    end
end

function net_watch.safeCall(name, method, ...)
    local ok, a, b, c = pcall(peripheral.call, name, method, ...)
    if not ok then
        return nil
    end
    return a, b, c
end

function net_watch.safeMethod(obj, method, ...)
    if not obj or type(obj[method]) ~= "function" then
        return nil
    end
    local ok, a, b, c = pcall(obj[method], obj, ...)
    if not ok then
        return nil
    end
    return a, b, c
end

return net_watch
end

-- module: machine_common (power/machine_common.lua)
package.preload["machine_common"] = function(...)
-- Shared CC peripheral helpers for power generators.

local net_watch = require("net_watch")

local M = {}

function M.safeCall(name, method, ...)
    return net_watch.safeCall(name, method, ...)
end

function M.indexFromName(name)
    return tonumber(name:match("_(%d+)$"))
end

function M.discover(substr, kind, newUnit)
    local list = {}
    if not substr or substr == "" then
        return list
    end
    for _, name in ipairs(peripheral.getNames()) do
        if name:find(substr, 1, true) then
            local idx = M.indexFromName(name)
            if idx == nil then
                idx = #list
            end
            list[#list + 1] = newUnit(name, idx, kind)
        end
    end
    table.sort(list, function(a, b)
        if a.index == b.index then
            return a.name < b.name
        end
        return a.index < b.index
    end)
    return list
end

function M.isWorking(unit)
    local v = M.safeCall(unit.name, "isWorkingEnabled")
    if v == nil then
        return unit.workingEnabled
    end
    unit.workingEnabled = v and true or false
    return unit.workingEnabled
end

function M.setWorking(unit, state, graceful)
    if state then
        M.safeCall(unit.name, "setSuspendAfterFinish", false)
        M.safeCall(unit.name, "setWorkingEnabled", true)
        unit.workingEnabled = true
        unit.enabledAt = os.clock()
    else
        if graceful then
            M.safeCall(unit.name, "setSuspendAfterFinish", true)
            M.safeCall(unit.name, "setWorkingEnabled", false)
        else
            M.safeCall(unit.name, "setWorkingEnabled", false)
        end
        unit.workingEnabled = false
        unit.enabledAt = nil
    end
end

function M.syncWorkingFlags(list)
    for _, u in ipairs(list) do
        u.workingEnabled = M.safeCall(u.name, "isWorkingEnabled") == true
        if u.workingEnabled and not u.enabledAt then
            u.enabledAt = os.clock()
        elseif not u.workingEnabled then
            u.enabledAt = nil
        end
    end
end

--- Merge discovered list onto previous units (keep runtime stats).
function M.applyList(list, prevList, mergeFields)
    local prev = {}
    for _, u in ipairs(prevList) do
        prev[u.name] = u
    end
    for _, u in ipairs(list) do
        local old = prev[u.name]
        if old then
            for _, key in ipairs(mergeFields) do
                u[key] = old[key]
            end
        end
    end
    M.syncWorkingFlags(list)
    for i, u in ipairs(list) do
        u.slot = i
    end
    return list
end

function M.fmtNum(n)
    n = tonumber(n) or 0
    local sign = n < 0 and "-" or ""
    local a = math.abs(n)
    if a >= 1e9 then
        return sign .. string.format("%.2fG", a / 1e9)
    elseif a >= 1e6 then
        return sign .. string.format("%.2fM", a / 1e6)
    elseif a >= 1e4 then
        return sign .. string.format("%.1fk", a / 1e3)
    end
    return sign .. string.format("%.0f", a)
end

return M
end

-- module: gas_turbine (power/gas_turbine.lua)
package.preload["gas_turbine"] = function(...)
-- Adapter: gtceu large gas turbines (TurbineMachinePeripheral).

local common = require("machine_common")

local M = {}
M.kind = "turbine"
M.labelRu = "турбина"
M.defaultSubstr = "gas_large_turbine"

local MERGE = {
    "totalRunTime", "lastSpeed", "lastProduction", "lastDurability",
    "lastProgress", "enabledAt", "hasRotor",
}

local function newUnit(name, index, kind)
    return {
        name = name,
        index = index,
        kind = kind,
        totalRunTime = 0,
        lastSpeed = 0,
        lastProduction = 0,
        lastDurability = 100,
        lastProgress = 0,
        hasRotor = true,
        isActive = false,
        workingEnabled = false,
        enabledAt = nil,
        engineWait = false,
    }
end

function M.discover(substr)
    return common.discover(substr or M.defaultSubstr, M.kind, newUnit)
end

function M.apply(list, prev)
    return common.applyList(list, prev, MERGE)
end

local function rotorSpeedPct(unit)
    local current = common.safeCall(unit.name, "getRotorSpeed") or 0
    local max = common.safeCall(unit.name, "getMaxRotorHolderSpeed") or 1
    if max == 0 then
        max = 1
    end
    return (current / max) * 100
end

function M.updateStats(unit, measureInterval)
    unit.isActive = common.safeCall(unit.name, "isActive") == true
    unit.lastProduction = common.safeCall(unit.name, "getCurrentProduction") or 0
    common.isWorking(unit)

    local has = common.safeCall(unit.name, "hasRotor")
    unit.hasRotor = (has ~= false)
    unit.lastSpeed = rotorSpeedPct(unit)
    unit.lastDurability = common.safeCall(unit.name, "getRotorDurabilityPercent")
        or unit.lastDurability or 100
    unit.lastProgress = unit.lastSpeed
    unit.engineWait = false

    if unit.isActive then
        unit.totalRunTime = unit.totalRunTime + measureInterval
    end
end

function M.isRamping(unit, rampSpeedPct)
    return unit.workingEnabled and (unit.lastSpeed or 0) < rampSpeedPct
end

function M.canEnable(unit)
    return not common.isWorking(unit) and unit.hasRotor ~= false
end

function M.status(unit, rampSpeedPct, rotorWarnPct)
    if not unit.hasRotor then
        return "NOR", colors.red
    end
    if unit.workingEnabled and (unit.lastSpeed or 0) < rampSpeedPct then
        return "RMP", colors.yellow
    end
    if unit.workingEnabled then
        local color = colors.lime
        local dur = unit.lastDurability or 0
        if dur <= rotorWarnPct then
            color = colors.orange
        end
        return "ON ", color
    end
    return "OFF", colors.white
end

function M.title(wide)
    if wide then
        return "Турбины (скорость/EU/t/прочность/аптайм):"
    end
    return "Турбины (скр/EU/t/прч/раб):"
end

function M.formatLine(unit, status)
    return string.format(
        "%2d:[%s] %3.0f%% %5s %3.0f%% %dm",
        unit.slot or 0,
        status,
        unit.lastSpeed or 0,
        common.fmtNum(unit.lastProduction or 0),
        unit.lastDurability or 0,
        math.floor((unit.totalRunTime or 0) / 60)
    )
end

function M.label(unit)
    return M.labelRu .. " #" .. tostring(unit.slot)
end

M.isWorking = common.isWorking
M.setWorking = common.setWorking

return M
end

-- module: combustion_engine (power/combustion_engine.lua)
package.preload["combustion_engine"] = function(...)
-- Adapter: gtceu extreme/large combustion engines.
--
-- CC has no getCurrentProduction for these (turbine-only peripheral).
-- Controller getOutputPerSec is often 0 because EU leaves via dynamo hatches.
-- So we infer RUN from Workable progress mid-cycle, and WAIT when stuck at
-- recipe end («Недостаточно вывода») with isActive and no measured output.

local common = require("machine_common")

local M = {}
M.kind = "engine"
M.labelRu = "двигатель"
M.defaultSubstr = "extreme_combustion_engine"
-- LuV extreme CE @ full parallels (override in power.cfg)
M.defaultRatedEuT = 32768

local MERGE = {
    "totalRunTime", "lastSpeed", "lastProduction", "lastDurability",
    "lastProgress", "enabledAt", "engineWait", "prevProgress",
}

local function newUnit(name, index, kind)
    return {
        name = name,
        index = index,
        kind = kind,
        totalRunTime = 0,
        lastSpeed = 0,
        lastProduction = 0,
        lastDurability = 100,
        lastProgress = 0,
        prevProgress = nil,
        hasRotor = true,
        isActive = false,
        workingEnabled = false,
        enabledAt = nil,
        engineWait = false,
    }
end

function M.discover(substr)
    return common.discover(substr or M.defaultSubstr, M.kind, newUnit)
end

function M.apply(list, prev)
    return common.applyList(list, prev, MERGE)
end

local function measuredEuT(unit)
    local outSec = common.safeCall(unit.name, "getOutputPerSec")
    if outSec ~= nil and outSec > 0 then
        return outSec / 20
    end
    local cur = common.safeCall(unit.name, "getCurrentProduction")
    if cur ~= nil and cur > 0 then
        return cur
    end
    return 0
end

--- @param ratedEuT number|nil assumed EU/t while cycling if hatch flow is invisible
function M.updateStats(unit, measureInterval, ratedEuT)
    ratedEuT = tonumber(ratedEuT) or M.defaultRatedEuT

    unit.isActive = common.safeCall(unit.name, "isActive") == true
    common.isWorking(unit)
    unit.hasRotor = true
    unit.lastDurability = 100

    local prog = common.safeCall(unit.name, "getProgress") or 0
    local maxProg = common.safeCall(unit.name, "getMaxProgress") or 0
    local pct = 0
    if maxProg > 0 then
        pct = (prog / maxProg) * 100
    end
    unit.lastProgress = pct

    local measured = measuredEuT(unit)
    -- Mid-cycle = actually burning fuel / generating (smoke, GT "Производит …")
    local cycling = unit.isActive and maxProg > 0 and prog > 0 and prog < maxProg
    -- Stuck at end of recipe waiting to push EU (GT "Недостаточно вывода")
    local stuckOut = unit.isActive and maxProg > 0 and prog >= maxProg

    if measured > 0 then
        unit.lastProduction = measured
        unit.engineWait = false
    elseif cycling then
        unit.lastProduction = ratedEuT
        unit.engineWait = false
    elseif stuckOut then
        unit.lastProduction = 0
        unit.engineWait = true
    elseif unit.isActive then
        -- Active but progress 0: start of tick or odd wait
        unit.lastProduction = 0
        unit.engineWait = true
    else
        unit.lastProduction = 0
        unit.engineWait = false
    end

    if (unit.lastProduction or 0) > 0 then
        unit.lastSpeed = 100
        unit.totalRunTime = unit.totalRunTime + measureInterval
    else
        unit.lastSpeed = 0
    end

    unit.prevProgress = pct
end

function M.isRamping(_unit, _rampSpeedPct)
    return false
end

function M.canEnable(unit)
    return not common.isWorking(unit)
end

function M.status(unit, _rampSpeedPct, _rotorWarnPct)
    if not unit.workingEnabled then
        return "OFF", colors.white
    end
    if (unit.lastProduction or 0) > 0 then
        return "ON ", colors.lime
    end
    if unit.engineWait then
        return "WAIT", colors.orange
    end
    if unit.isActive then
        return "WAIT", colors.orange
    end
    return "IDLE", colors.yellow
end

function M.title(wide)
    if wide then
        return "Двигатели (EU/t/прогресс/аптайм):"
    end
    return "Двигатели (EU/t/прог/раб):"
end

function M.formatLine(unit, status)
    return string.format(
        "%2d:[%s] %5s %3.0f%% %dm",
        unit.slot or 0,
        status,
        common.fmtNum(unit.lastProduction or 0),
        unit.lastProgress or 0,
        math.floor((unit.totalRunTime or 0) / 60)
    )
end

function M.label(unit)
    return M.labelRu .. " #" .. tostring(unit.slot)
end

M.isWorking = common.isWorking
M.setWorking = common.setWorking

return M
end

-- entry: power/main.lua
-- GTCEU power substation controller (CC: Tweaked / TFG).
-- Bundle:  python tools/bundle_project.py power
-- Deploy:  dist/power.lua + power.cfg
--
-- Machine APIs live in adapters:
--   gas_turbine.lua, combustion_engine.lua (+ machine_common.lua)

local configMod = require("config")
local gasTurbine = require("gas_turbine")
local combustion = require("combustion_engine")
local common = require("machine_common")
local net_watch = require("net_watch")

local cfg, cfgPath, cfgLoaded = configMod.load()

-- ========================= STATE =========================
local turbines = {}
local engines = {}
local substation = nil
local substationName = nil
local monitor = nil
local monW, monH = 0, 0
local textScale = 0.5
local netDirty = false

local energyHistory = {}
local tickCounter = 0
local cooldownCounter = 0
local lastNetEuT = 0
local lastInputEuT = 0
local lastOutputEuT = 0
local netFromApi = false
-- Fill mode: enter at threshold_low (60%), exit at engine_target (95%).
-- Outside fill: turbines keep a mild deficit; ДГ only for consumption spikes.
local fillMode = false

-- ========================= HELPERS =========================
local function safeMethod(obj, method, ...)
    return net_watch.safeMethod(obj, method, ...)
end

local function networkSummary()
    return table.concat(peripheral.getNames(), ", ")
end

local function fmtNum(n)
    return common.fmtNum(n)
end

local function flushEvents()
    net_watch.flushEvents("power_ctrl_flush")
end

local function sleepWatch(seconds)
    local dirty = net_watch.sleepWatch(seconds)
    if dirty then
        netDirty = true
    end
    return dirty
end

local function adapterFor(unit)
    if unit.kind == combustion.kind then
        return combustion
    end
    return gasTurbine
end

local function eachGen(fn)
    for _, t in ipairs(turbines) do
        fn(t)
    end
    for _, t in ipairs(engines) do
        fn(t)
    end
end

local function genCount()
    return #turbines + #engines
end

local function genLabel(unit)
    return adapterFor(unit).label(unit)
end

-- ========================= DISCOVERY =========================
local function discoverSubstation()
    if cfg.substation and peripheral.isPresent(cfg.substation) then
        return peripheral.wrap(cfg.substation), cfg.substation
    end
    for _, name in ipairs(peripheral.getNames()) do
        if name:find(cfg.substation_substr, 1, true) then
            return peripheral.wrap(name), name
        end
    end
    return nil, nil
end

local function discoverMonitor()
    local want = cfg.monitor
    if want and peripheral.isPresent(want) then
        local m = peripheral.wrap(want)
        if m and m.getSize then
            return m
        end
    end
    for _, name in ipairs(peripheral.getNames()) do
        if peripheral.getType(name) == "monitor" then
            return peripheral.wrap(name)
        end
    end
    return nil
end

local function discoverAllGens()
    return gasTurbine.discover(cfg.turbine_substr),
        combustion.discover(cfg.engine_substr)
end

local function applyAllGens(tList, eList)
    turbines = gasTurbine.apply(tList, turbines)
    engines = combustion.apply(eList, engines)
    netDirty = false
end

-- ========================= MONITOR LAYOUT =========================
local COL_W = 28
local COL_GAP = 4
local TABLES_START_Y = 10

local function tableRows(n)
    n = math.max(n, 0)
    if n == 0 then
        return 0, 1
    end
    local cols = (n >= 2) and 2 or 1
    return math.ceil(n / cols), cols
end

local function layoutPlan()
    local tRows, tCols = tableRows(#turbines)
    local eRows, eCols = tableRows(#engines)
    local y = TABLES_START_Y
    local turbineHeaderY, turbineFirstY = nil, nil
    local engineHeaderY, engineFirstY = nil, nil

    if #turbines > 0 then
        turbineHeaderY = y
        turbineFirstY = y + 1
        y = turbineFirstY + tRows
    end
    if #engines > 0 then
        if #turbines > 0 then
            y = y + 1
        end
        engineHeaderY = y
        engineFirstY = y + 1
        y = engineFirstY + eRows
    end

    local useTwo = (tCols == 2) or (eCols == 2)
    return {
        tCols = tCols,
        eCols = eCols,
        colW = COL_W,
        gap = COL_GAP,
        turbineHeaderY = turbineHeaderY,
        turbineFirstY = turbineFirstY,
        engineHeaderY = engineHeaderY,
        engineFirstY = engineFirstY,
        needH = math.max(y - 1, TABLES_START_Y),
        needW = useTwo and (COL_W * 2 + COL_GAP) or 40,
    }
end

local function applyMonitorScale()
    if not monitor then
        return
    end
    local plan = layoutPlan()
    local chosen = 0.5
    if cfg.text_scale == "auto" then
        for scale = 5, 0.5, -0.5 do
            monitor.setTextScale(scale)
            local w, h = monitor.getSize()
            if w >= plan.needW and h >= plan.needH then
                chosen = scale
                break
            end
        end
    else
        chosen = cfg.text_scale
    end
    monitor.setTextScale(chosen)
    textScale = chosen
    monW, monH = monitor.getSize()
end

-- ========================= WAIT / RESCAN =========================
local function waitForSubstation(timeoutSec)
    local deadline = os.clock() + timeoutSec
    while true do
        substation, substationName = discoverSubstation()
        if substation then
            return true
        end
        if os.clock() >= deadline then
            return false
        end
        print("Ждём подстанцию... " .. networkSummary())
        sleepWatch(cfg.boot_poll)
    end
end

local function waitForGens(timeoutSec)
    local deadline = os.clock() + timeoutSec
    local lastPrint = 0
    while true do
        local tList, eList = discoverAllGens()
        if #tList > 0 or #eList > 0 then
            applyAllGens(tList, eList)
            return true
        end
        if os.clock() >= deadline then
            return false
        end
        local now = os.clock()
        if now - lastPrint >= 5 then
            print("Ждём генераторы (*" .. tostring(cfg.turbine_substr)
                .. "* / *" .. tostring(cfg.engine_substr) .. "*)... " .. networkSummary())
            lastPrint = now
        end
        sleepWatch(cfg.boot_poll)
    end
end

local function rescanNetwork(reason)
    local tList, eList = discoverAllGens()
    if #tList == 0 and #eList == 0 then
        if genCount() > 0 then
            print("Генераторы пропали из сети, ждём...")
            turbines = {}
            engines = {}
        end
        netDirty = false
        return false
    end
    local beforeT, beforeE = #turbines, #engines
    applyAllGens(tList, eList)
    if #tList ~= beforeT or #eList ~= beforeE then
        applyMonitorScale()
        if reason then
            print(("Рескан (%s): турбин %d, двигателей %d"):format(
                tostring(reason), #turbines, #engines))
        end
    end
    return true
end

local function init()
    flushEvents()
    netDirty = false

    if not waitForSubstation(cfg.boot_wait) then
        error("Подстанция не найдена. Сеть: " .. networkSummary())
    end

    monitor = discoverMonitor()
    if monitor then
        applyMonitorScale()
        monitor.clear()
        monitor.setCursorPos(1, 1)
        monitor.write("Ждём генераторы...")
    end

    if not waitForGens(cfg.boot_wait) then
        print("Генераторы ещё не в сети после " .. cfg.boot_wait
            .. "с — ждём дальше. Сеть: " .. networkSummary())
        turbines = {}
        engines = {}
    else
        applyMonitorScale()
    end
end

-- ========================= ENERGY =========================
local function getEnergy()
    return safeMethod(substation, "getEnergyStored") or 0
end

local function getEnergyCapacity()
    local cap = safeMethod(substation, "getEnergyCapacity") or 1
    if cap == 0 then
        return 1
    end
    return cap
end

local function getEnergyRatio()
    local energy = getEnergy()
    local capacity = getEnergyCapacity()
    return energy / capacity, energy, capacity
end

local function readSubstationFlowEuT()
    local inp = safeMethod(substation, "getInputPerSec")
    local out = safeMethod(substation, "getOutputPerSec")
    if inp == nil or out == nil then
        return nil
    end
    return inp / 20 - out / 20, inp / 20, out / 20
end

local function etaSeconds(energy, capacity, netEuT)
    if not netEuT or netEuT == 0 then
        return nil, nil
    end
    if netEuT < 0 then
        if energy <= 0 then
            return 0, "empty"
        end
        return (energy / -netEuT) / 20, "empty"
    end
    local room = capacity - energy
    if room <= 0 then
        return 0, "full"
    end
    return (room / netEuT) / 20, "full"
end

local function fmtDuration(sec)
    if sec == nil then
        return "—"
    end
    sec = math.max(0, math.floor(sec + 0.5))
    if sec < 60 then
        return sec .. "с"
    end
    if sec < 3600 then
        return math.floor(sec / 60) .. "м"
    end
    local h = math.floor(sec / 3600)
    local m = math.floor((sec % 3600) / 60)
    if m > 0 then
        return string.format("%dч %dм", h, m)
    end
    return h .. "ч"
end

local function addEnergyMeasurement()
    local flow, inp, out = readSubstationFlowEuT()
    if flow ~= nil then
        lastNetEuT = flow
        lastInputEuT = inp
        lastOutputEuT = out
        netFromApi = true
    else
        netFromApi = false
    end

    local energy = getEnergy()
    tickCounter = tickCounter + 1
    energyHistory[#energyHistory + 1] = { energy = energy, tick = tickCounter }
    while #energyHistory > cfg.max_history do
        table.remove(energyHistory, 1)
    end

    if not netFromApi and #energyHistory >= 2 then
        local oldest = energyHistory[1]
        local newest = energyHistory[#energyHistory]
        local timeDiff = (newest.tick - oldest.tick) * cfg.measure_interval
        if timeDiff > 0 then
            lastNetEuT = ((newest.energy - oldest.energy) / timeDiff) / 20
        end
    end
end

-- ========================= CONTROL =========================
local function setWorking(unit, state, graceful, cooldownOverride)
    adapterFor(unit).setWorking(unit, state, graceful)
    if cooldownOverride ~= nil then
        cooldownCounter = cooldownOverride
    elseif unit.kind == combustion.kind then
        cooldownCounter = cfg.engine_cooldown or 2
    else
        cooldownCounter = cfg.cooldown or 20
    end
end

local function updateAllStats()
    for _, t in ipairs(turbines) do
        gasTurbine.updateStats(t, cfg.measure_interval)
    end
    for _, t in ipairs(engines) do
        combustion.updateStats(t, cfg.measure_interval, cfg.engine_rated_eut)
    end
end

local function anyEnabledStillRamping()
    for _, t in ipairs(turbines) do
        if gasTurbine.isRamping(t, cfg.ramp_speed_pct) then
            return true, t
        end
    end
    return false, nil
end

local function totalProduction()
    local sum = 0
    eachGen(function(t)
        sum = sum + (t.lastProduction or 0)
    end)
    return sum
end

--- Pick best unit from list (enable: speed/runtime/dur; disable: low prod/runtime).
local function selectBest(list, forEnable)
    local best, bestA, bestB, bestC = nil, nil, nil, nil
    for _, t in ipairs(list) do
        local mod = adapterFor(t)
        if forEnable then
            if mod.canEnable(t) then
                local speed, run, dur = t.lastSpeed or 0, t.totalRunTime or 0, t.lastDurability or 0
                if not best
                    or speed > bestA
                    or (speed == bestA and run > bestB)
                    or (speed == bestA and run == bestB and dur > bestC)
                then
                    best, bestA, bestB, bestC = t, speed, run, dur
                end
            end
        else
            if mod.isWorking(t) then
                local prod, run = t.lastProduction or 0, t.totalRunTime or 0
                if not best or prod < bestA or (prod == bestA and run < bestB) then
                    best, bestA, bestB = t, prod, run
                end
            end
        end
    end
    return best
end

local function selectTurbineToEnable()
    return selectBest(turbines, true)
end

local function selectEngineToEnable()
    return selectBest(engines, true)
end

--- Prefer shutting engines before turbines (peaker off first, base load stays).
local function selectToDisable()
    local e = selectBest(engines, false)
    if e then
        return e
    end
    return selectBest(turbines, false)
end

local function canEnableDespiteRamp(ratio, netEuT)
    return ratio < cfg.threshold_emergency or netEuT < cfg.drain_override_eut
end

local function updateCritical(ratio)
    if ratio <= cfg.threshold_critical then
        return false
    end
    -- Past target — never re-enter fill until threshold_low again
    fillMode = false
    local unit = selectToDisable()
    if unit then
        setWorking(unit, false, false)
        print("КРИТИЧНО: выключен " .. genLabel(unit))
        return true
    end
    return false
end

--- Fill mode (60%→95%): all turbines + ДГ catch-up.
--- Maintain: turbines hold a slight deficit; ДГ only when turbines can't cover.
local function updateControl()
    local ratio = getEnergyRatio()
    local net = lastNetEuT
    local fillEnter = cfg.threshold_low or 0.60
    local fillExit = cfg.engine_target or cfg.threshold_critical or 0.95
    local turbineRated = cfg.turbine_rated_eut or 9012
    local turbineDiff = turbineRated * (cfg.turbine_diff_mult or 2)
    local spikeNet = cfg.drain_override_eut or -4000
    local fillCd = cfg.fill_enable_cooldown or 2
    -- After shutting a maintain/spike ДГ, stay quiet so net wobble can't re-toggle
    local dgOffCd = cfg.engine_off_cooldown or 15

    if updateCritical(ratio) then
        return
    end
    if cooldownCounter > 0 then
        return
    end

    -- Enter fill at 60%. Exit immediately on first touch of 95% (no re-enable if we dip).
    if not fillMode and ratio <= fillEnter then
        fillMode = true
        print(("Режим заполнения (%.0f%%)"):format(ratio * 100))
    elseif fillMode and ratio >= fillExit then
        fillMode = false
        print("Заполнение завершено")
    end

    if fillMode then
        local turbineWindDown = ratio >= (cfg.threshold_high or 0.90)

        -- From 90%: start killing turbines early (cooldown + rotor inertia)
        if turbineWindDown then
            local t = selectBest(turbines, false)
            if t then
                setWorking(t, false, true, fillCd)
                print("Выключен " .. genLabel(t) .. " (с 90%)")
                return
            end
        else
            local t = selectTurbineToEnable()
            if t then
                local rampBlocked = anyEnabledStillRamping()
                    and not canEnableDespiteRamp(ratio, net)
                if not rampBlocked then
                    setWorking(t, true, nil, fillCd)
                    print("Включен " .. genLabel(t) .. " (заполнение)")
                    return
                end
            end
        end

        -- ДГ догоняют до 95%
        local e = selectEngineToEnable()
        if e then
            setWorking(e, true)
            print("Включен " .. genLabel(e) .. " (догон)")
            return
        end
        return
    end

    -- ===== MAINTAIN (outside fill) =====
    -- Turbines are base load. ДГ only if emergency / turbines exhausted.

    -- Leftover ДГ after fill or spike → park them (long cooldown = no chatter)
    local canAddTurbine = selectTurbineToEnable() ~= nil
    local needPeak = ratio < (cfg.threshold_emergency or 0.40)
        or (net < spikeNet and not canAddTurbine)

    if not needPeak then
        local e = selectBest(engines, false)
        if e then
            setWorking(e, false, true, dgOffCd)
            print("Выключен " .. genLabel(e) .. " (не нужен)")
            return
        end
    end

    -- Turbines: only step when |net| > 2× rated (avoids 9k flip-flop around 0)
    if net > turbineDiff then
        local t = selectBest(turbines, false)
        if t then
            setWorking(t, false, true)
            print("Выключен " .. genLabel(t) .. " (избыток)")
            return
        end
    elseif net < -turbineDiff then
        local rampBlocked = anyEnabledStillRamping()
            and not canEnableDespiteRamp(ratio, net)
        if not rampBlocked then
            local t = selectTurbineToEnable()
            if t then
                setWorking(t, true)
                print("Включен " .. genLabel(t) .. " (база)")
                return
            end
        end
    end

    -- Peak: turbines already maxed (or emergency) and still draining hard
    if needPeak then
        local e = selectEngineToEnable()
        if e then
            setWorking(e, true)
            print("Включен " .. genLabel(e) .. " (скачок)")
            return
        end
    end
end

-- ========================= DRAW =========================
local function writeAt(x, y, text, color)
    if y < 1 or y > monH or x > monW then
        return
    end
    if color then
        monitor.setTextColor(color)
    end
    monitor.setCursorPos(x, y)
    local room = monW - x + 1
    if #text > room then
        text = text:sub(1, room)
    end
    monitor.write(text)
    if color then
        monitor.setTextColor(colors.white)
    end
end

local function drawBar(ratio, y)
    local label = string.format("Уровень: %5.1f%% ", ratio * 100)
    local barRoom = math.max(4, monW - #label)
    local filled = math.floor(ratio * (barRoom - 2) + 1e-9)
    filled = math.max(0, math.min(barRoom - 2, filled))
    local bar = "[" .. string.rep("#", filled) .. string.rep("-", barRoom - 2 - filled) .. "]"
    writeAt(1, y, label .. bar)
end

local function drawGenTable(list, mod, headerY, firstY, cols, colW, gap)
    if #list == 0 or not headerY or not firstY then
        return
    end
    if cols == 2 and monW < (colW * 2 + gap) then
        cols = 1
    end
    writeAt(1, headerY, mod.title(cols >= 2))
    local rowsPerCol = math.ceil(#list / cols)

    for i, unit in ipairs(list) do
        local col = math.floor((i - 1) / rowsPerCol)
        local row = (i - 1) % rowsPerCol
        if col >= cols then
            break
        end
        local x = 1 + col * (colW + gap)
        local y = firstY + row
        if y > monH then
            break
        end
        local status, color = mod.status(unit, cfg.ramp_speed_pct, cfg.rotor_warn_pct)
        writeAt(x, y, mod.formatLine(unit, status), color)
    end
end

local function draw()
    if not monitor then
        return
    end

    local w, h = monitor.getSize()
    if w ~= monW or h ~= monH then
        applyMonitorScale()
    end

    monitor.clear()
    monitor.setTextColor(colors.white)

    if genCount() == 0 then
        writeAt(1, 1, "=== GTCEU POWER CTRL ===")
        writeAt(1, 3, "Ждём генераторы...", colors.yellow)
        writeAt(1, 5, networkSummary())
        return
    end

    local ratio, energy, capacity = getEnergyRatio()
    local net = lastNetEuT
    local etaSec, etaKind = etaSeconds(energy, capacity, net)

    writeAt(1, 1, "=== GTCEU POWER CTRL ===")
    writeAt(1, 3, string.format("Энергия: %s / %s EU", fmtNum(energy), fmtNum(capacity)))
    drawBar(ratio, 4)

    local netColor = colors.white
    if net > 0 then
        netColor = colors.green
    elseif net < 0 then
        netColor = colors.red
    end
    if netFromApi then
        writeAt(1, 5, string.format(
            "Баланс: %s EU/t (вход %s / выход %s)",
            fmtNum(net), fmtNum(lastInputEuT), fmtNum(lastOutputEuT)
        ), netColor)
    else
        writeAt(1, 5, string.format("Баланс: %s EU/t (история)", fmtNum(net)), netColor)
    end

    if etaKind == "empty" then
        writeAt(1, 6, "До опустошения: " .. fmtDuration(etaSec), colors.red)
    elseif etaKind == "full" then
        writeAt(1, 6, "До заполнения: " .. fmtDuration(etaSec), colors.green)
    else
        writeAt(1, 6, "Баланс стабилен", colors.white)
    end

    if fillMode then
        local tgt = (cfg.engine_target or cfg.threshold_critical or 0.95) * 100
        writeAt(1, 7, string.format("Заполнение → %.0f%%", tgt), colors.yellow)
    elseif cooldownCounter > 0 then
        writeAt(1, 7, string.format("Пауза: %dс", cooldownCounter), colors.gray)
    elseif anyEnabledStillRamping() then
        writeAt(1, 7, "Разгон (ждём)", colors.yellow)
    else
        writeAt(1, 7, "Поддержание")
    end

    writeAt(1, 8, string.format(
        "Выработка: %s EU/t  scale:%s",
        fmtNum(totalProduction()),
        tostring(textScale)
    ))

    local plan = layoutPlan()
    drawGenTable(
        turbines, gasTurbine,
        plan.turbineHeaderY, plan.turbineFirstY,
        plan.tCols, plan.colW, plan.gap
    )
    drawGenTable(
        engines, combustion,
        plan.engineHeaderY, plan.engineFirstY,
        plan.eCols, plan.colW, plan.gap
    )
end

-- ========================= MAIN =========================
local function main()
    print("power: cfg " .. tostring(cfgPath) .. (cfgLoaded and " (loaded)" or " (defaults)"))
    print("power: ждём периферию до " .. cfg.boot_wait .. "с...")
    init()
    print("Подстанция: " .. tostring(substationName))
    print(("Турбин: %d  двигателей: %d  scale:%s (%sx%s)"):format(
        #turbines, #engines, tostring(textScale), tostring(monW), tostring(monH)))
    eachGen(function(t)
        print(string.format(
            "  %s %s (id %s) enabled=%s",
            genLabel(t), t.name, tostring(t.index), tostring(t.workingEnabled)
        ))
    end)

    addEnergyMeasurement()
    updateAllStats()

    local measureCounter = 0
    while true do
        if netDirty or genCount() == 0 then
            if not rescanNetwork(netDirty and "hotplug" or "retry") then
                draw()
                sleepWatch(cfg.boot_poll)
            end
        end

        if genCount() > 0 then
            if not substation or not peripheral.isPresent(substationName) then
                substation, substationName = discoverSubstation()
            end

            if substation then
                local ratio = getEnergyRatio()
                if ratio > cfg.threshold_critical then
                    updateCritical(ratio)
                end

                -- Energy + turbine stats on measure_interval; engines every second (2s recipes)
                measureCounter = measureCounter + 1
                if measureCounter >= cfg.measure_interval then
                    addEnergyMeasurement()
                    for _, t in ipairs(turbines) do
                        gasTurbine.updateStats(t, cfg.measure_interval)
                    end
                    measureCounter = 0
                end
                for _, t in ipairs(engines) do
                    combustion.updateStats(t, 1, cfg.engine_rated_eut)
                end

                -- Control every second so engine_cooldown (~2s) can actually fire
                if ratio <= cfg.threshold_critical then
                    updateControl()
                end
            end
        end

        if cooldownCounter > 0 then
            cooldownCounter = cooldownCounter - 1
        end

        draw()
        sleepWatch(1)
    end
end

local ok, err = pcall(main)
if not ok then
    print("Критическая ошибка: " .. tostring(err))
end
