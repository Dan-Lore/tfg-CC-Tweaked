-- Bundled from crystals/main.lua — do not edit by hand; rebuild with tools/bundle_project.py
-- Also copy crystals.cfg next to this file on the computer.
-- Generated package.preload modules + entrypoint.

-- module: util (shared/util.lua)
package.preload["util"] = function(...)
-- Shared string / path helpers for CC:Tweaked scripts.

local util = {}

function util.trim(s)
    return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

function util.split(s, sep)
    local out = {}
    s = tostring(s or "")
    for part in (s .. sep):gmatch("(.-)" .. sep) do
        out[#out + 1] = part
    end
    return out
end

--- Resolve a config path relative to the running program directory.
function util.resolvePath(path, defaultName)
    path = path or defaultName
    if not path then
        error("resolvePath: path required", 2)
    end
    if path:sub(1, 1) == "/" then
        return path
    end
    local base = ""
    if shell and shell.getRunningProgram then
        local prog = shell.getRunningProgram()
        if prog then
            base = fs.getDir(prog)
        end
    end
    return fs.combine(base, path)
end

--- Read entire file as string, or nil if missing.
function util.readAll(path)
    if not path or not fs.exists(path) then
        return nil
    end
    local file = fs.open(path, "r")
    if not file then
        return nil
    end
    local text = file.readAll()
    file.close()
    return text
end

--- Basename of the running program without .lua (e.g. pizza_maintain).
function util.programStem()
    if not (shell and shell.getRunningProgram) then
        return nil
    end
    local prog = shell.getRunningProgram()
    if not prog then
        return nil
    end
    local name = fs.getName(prog)
    return (name:gsub("%.lua$", ""))
end

--- Lines of `[section]` from a sectioned cfg. Nil if file/section missing.
function util.cfgSectionLines(path, section)
    local text = util.readAll(path)
    if not text or not section then
        return nil
    end
    local current = nil
    local buf = {}
    local found = false
    for line in (text .. "\n"):gmatch("(.-)\n") do
        local sec = line:match("^%s*%[([%w_]+)%]%s*$")
        if sec then
            if found then
                break
            end
            if sec == section then
                found = true
                current = sec
                buf = {}
            else
                current = nil
            end
        elseif found and current == section then
            buf[#buf + 1] = line
        end
    end
    if not found then
        return nil
    end
    return buf
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Try sectioned cfg at path; return lines, label or nil.
local function trySectioned(path, section)
    if not path or not fs.exists(path) then
        return nil
    end
    local sectionLines = util.cfgSectionLines(path, section)
    if not sectionLines then
        return nil
    end
    return sectionLines, path .. "[" .. section .. "]"
end

--- Config lines for a logical section.
-- Order: explicit path → <program>.cfg [section] → craft.cfg [section] → fallbackName.
-- Returns lines, label (for errors).
function util.openConfigLines(explicitPath, section, fallbackName)
    if explicitPath then
        local path = util.resolvePath(explicitPath)
        local text = util.readAll(path)
        if not text then
            error("Cannot open " .. path, 2)
        end
        return linesFromText(text), path
    end

    local stem = util.programStem()
    if stem then
        local lines, label = trySectioned(util.resolvePath(nil, stem .. ".cfg"), section)
        if lines then
            return lines, label
        end
    end

    local lines, label = trySectioned(util.resolvePath(nil, "craft.cfg"), section)
    if lines then
        return lines, label
    end

    local path = util.resolvePath(nil, fallbackName)
    local text = util.readAll(path)
    if not text then
        local hint = stem and (stem .. ".cfg") or "program.cfg"
        error(
            "Cannot open " .. path
                .. " (deploy "
                .. hint
                .. " next to the program, or "
                .. tostring(fallbackName)
                .. ")",
            2
        )
    end
    return linesFromText(text), path
end

--- Short display name: last path segment after `/`.
function util.short(id)
    id = tostring(id or "")
    return id:match("([^/]+)$") or id
end

function util.clamp(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

return util
end

-- module: cfg_pipe (shared/cfg_pipe.lua)
package.preload["cfg_pipe"] = function(...)
-- Shared pipe-delimited cfg helpers (key | value [| ...]).

local util = require("util")

local cfg_pipe = {}

cfg_pipe.trim = util.trim
cfg_pipe.split = util.split
cfg_pipe.resolvePath = util.resolvePath

function cfg_pipe.parseScale(raw)
    raw = util.trim(tostring(raw or "")):lower()
    if raw == "" or raw == "auto" then
        return "auto"
    end
    local n = tonumber(raw)
    if not n then
        return "auto"
    end
    n = math.floor(n * 2 + 0.5) / 2
    return util.clamp(n, 0.5, 5)
end

--- Split a cfg line into key, value, parts (or nil, errHint).
function cfg_pipe.splitLine(line)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return nil
    end
    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end
    local key = (parts[1] or ""):lower()
    if key == "" then
        return nil, "empty key"
    end
    if parts[2] == nil or parts[2] == "" then
        return nil, key .. " | value"
    end
    return key, parts[2], parts
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Load all lines from a cfg file.
-- @return lines, path, ok
function cfg_pipe.loadLines(path, defaultName)
    path = util.resolvePath(path, defaultName)
    if not fs.exists(path) then
        return nil, path, false
    end
    local text = util.readAll(path)
    if not text then
        error("Cannot open " .. path, 2)
    end
    return linesFromText(text), path, true
end

return cfg_pipe
end

-- module: config (crystals/config.lua)
package.preload["config"] = function(...)
-- Load crystals.cfg from disk (next to the running program).
-- `config` is project-local (crystals/); deploy one bundle per computer.

local util = require("util")
local cfg_pipe = require("cfg_pipe")

local config = {}

local function empty()
    return {
        MONITOR = "left",
        BUFFER = "top",
        OVERFLOW = nil, -- extra crates when the main buffer fills
        MACHINES = nil,
        MACHINE_SUBSTR = nil, -- filled via appendList or default in finalize
        MAX_STACK = 64,
        BATCH = 2,
        POLL = 0.5,
        KEEP_FREE = 8, -- leave this many empty slots in the main buffer
        ALIASES = {}, -- { { item, material, tier }, ... }
    }
end

local function appendList(cfg, key, value)
    local cur = cfg[key]
    if type(cur) ~= "table" then
        local list = {}
        if type(cur) == "string" and cur ~= "" then
            list[1] = cur
        end
        cfg[key] = list
    end
    cfg[key][#cfg[key] + 1] = value
end

local function parseLine(cfg, line, lineNo, label)
    label = label or "crystals.cfg"
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return
    end

    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end

    local key = parts[1] and parts[1]:lower() or ""
    if key == "" then
        error(("%s line %s: empty key"):format(label, tostring(lineNo)))
    end

    if key == "monitor" then
        if #parts < 2 then
            error(("%s line %s: monitor | side"):format(label, tostring(lineNo)))
        end
        cfg.MONITOR = parts[2]
        return
    end

    if key == "buffer" or key == "chest" or key == "storage" then
        if #parts < 2 then
            error(("%s line %s: buffer | peripheral"):format(label, tostring(lineNo)))
        end
        cfg.BUFFER = parts[2]
        return
    end

    if key == "overflow" or key == "extra" or key == "overflow_buffer" then
        if #parts < 2 then
            error(("%s line %s: overflow | peripheral"):format(label, tostring(lineNo)))
        end
        appendList(cfg, "OVERFLOW", parts[2])
        return
    end

    if key == "machine" or key == "machines" or key == "engraver" then
        if #parts < 2 then
            error(("%s line %s: machine | peripheral"):format(label, tostring(lineNo)))
        end
        appendList(cfg, "MACHINES", parts[2])
        return
    end

    if key == "machine_substr" then
        if #parts < 2 then
            error(("%s line %s: machine_substr | needle"):format(label, tostring(lineNo)))
        end
        appendList(cfg, "MACHINE_SUBSTR", parts[2])
        return
    end

    if key == "max_stack" then
        cfg.MAX_STACK = tonumber(parts[2]) or cfg.MAX_STACK
        return
    end

    if key == "batch" or key == "n" then
        cfg.BATCH = tonumber(parts[2]) or cfg.BATCH
        return
    end

    if key == "poll" then
        cfg.POLL = tonumber(parts[2]) or cfg.POLL
        return
    end

    if key == "keep_free" or key == "keepfree" then
        cfg.KEEP_FREE = tonumber(parts[2]) or cfg.KEEP_FREE
        return
    end

    -- alias | item_id | material | tier(optional, default 3)
    if key == "alias" or key == "gem_alias" then
        if #parts < 3 then
            error(("%s line %s: alias | item | material [| tier]"):format(label, tostring(lineNo)))
        end
        cfg.ALIASES[#cfg.ALIASES + 1] = {
            item = parts[2],
            material = parts[3],
            tier = tonumber(parts[4]) or 3,
        }
        return
    end

    error(("%s line %s: unknown key %q"):format(label, tostring(lineNo), key))
end

local function finalize(cfg)
    if type(cfg.MACHINE_SUBSTR) == "table" then
        if #cfg.MACHINE_SUBSTR == 0 then
            cfg.MACHINE_SUBSTR = "laser_engraver"
        elseif #cfg.MACHINE_SUBSTR == 1 then
            cfg.MACHINE_SUBSTR = cfg.MACHINE_SUBSTR[1]
        end
    elseif cfg.MACHINE_SUBSTR == nil or cfg.MACHINE_SUBSTR == "" then
        cfg.MACHINE_SUBSTR = "laser_engraver"
    end

    if cfg.BATCH < 2 then
        cfg.BATCH = 2
    end
    if cfg.BATCH % 2 == 1 then
        cfg.BATCH = cfg.BATCH + 1
    end
    if cfg.MAX_STACK < cfg.BATCH then
        cfg.MAX_STACK = 64
    end
    if cfg.POLL < 0 then
        cfg.POLL = 0
    end
    if not cfg.KEEP_FREE or cfg.KEEP_FREE < 1 then
        cfg.KEEP_FREE = 8
    end
    return cfg
end

local function parseText(text, label)
    local cfg = empty()
    local n = 0
    for line in (tostring(text or "") .. "\n"):gmatch("(.-)\n") do
        n = n + 1
        parseLine(cfg, line, n, label)
    end
    return finalize(cfg)
end

--- crystals.cfg is required next to the program (not embedded).
function config.load(path)
    local lines, resolved, ok = cfg_pipe.loadLines(path, "crystals.cfg")
    if not ok then
        error("Cannot open " .. tostring(resolved) .. " (copy crystals.cfg next to crystals.lua)", 2)
    end
    return parseText(table.concat(lines, "\n"), resolved)
end

return config
end

-- module: discover (crystals/discover.lua)
package.preload["discover"] = function(...)
-- Discover buffer chest, laser engravers, and monitor.

local discover = {}

local SKIP_TYPES = {
    modem = true,
    wired_modem = true,
    wireless_modem = true,
    monitor = true,
    computer = true,
    turtle = true,
    speaker = true,
    drive = true,
    printer = true,
    command = true,
    redstone = true,
}

local LOCAL_SIDES = {
    left = true,
    right = true,
    top = true,
    bottom = true,
    front = true,
    back = true,
}

local BUFFER_NEEDLES = {
    "crate",
    "chest",
    "barrel",
    "drawer",
    "shulker",
}

local function peripheralTypes(name)
    local ok, ptype = pcall(peripheral.getType, name)
    if not ok or not ptype then
        return {}
    end
    if type(ptype) == "table" then
        return ptype
    end
    return { ptype }
end

local function shouldSkip(name, types)
    local lowerName = tostring(name):lower()
    if LOCAL_SIDES[lowerName] then
        return true
    end
    for i = 1, #types do
        local t = tostring(types[i]):lower()
        if SKIP_TYPES[t] then
            return true
        end
    end
    if lowerName:find("modem", 1, true) or lowerName:find("monitor", 1, true) then
        return true
    end
    return false
end

local function isInventory(name)
    if not name or not peripheral.isPresent(name) then
        return false
    end
    local inv = peripheral.wrap(name)
    return inv and type(inv.list) == "function" and type(inv.pushItems) == "function"
end

--- GT crate ids sometimes drop the underscore: tungsten_steel <-> tungstensteel
local function nameAliases(name)
    local out = { name }
    if not name then
        return out
    end
    local alt = name:gsub("tungsten_steel", "tungstensteel", 1)
    if alt ~= name then
        out[#out + 1] = alt
    else
        alt = name:gsub("tungstensteel", "tungsten_steel", 1)
        if alt ~= name then
            out[#out + 1] = alt
        end
    end
    return out
end

local function resolveInventory(preferred, label, machineSet)
    machineSet = machineSet or {}
    if not preferred then
        return nil
    end
    local aliases = nameAliases(preferred)
    for i = 1, #aliases do
        local name = aliases[i]
        if isInventory(name) and not machineSet[name] then
            if name ~= preferred then
                print(("crystals: %s %s -> %s"):format(label, preferred, name))
            end
            return name
        end
    end
    print(("crystals: missing %s %s"):format(label, tostring(preferred)))
    return nil
end

local function matchesNeedle(name, types, needle)
    if not needle or needle == "" then
        return false
    end
    local n = tostring(needle):lower()
    if tostring(name):lower():find(n, 1, true) then
        return true
    end
    for i = 1, #types do
        if tostring(types[i]):lower():find(n, 1, true) then
            return true
        end
    end
    return false
end

local function matchesAny(name, types, needles)
    if not needles then
        return false
    end
    if type(needles) == "string" then
        return matchesNeedle(name, types, needles)
    end
    for i = 1, #needles do
        if matchesNeedle(name, types, needles[i]) then
            return true
        end
    end
    return false
end

local function indexFromName(name)
    return tonumber(tostring(name):match("_(%d+)$"))
end

local function sortMachines(list)
    table.sort(list, function(a, b)
        local ia, ib = indexFromName(a), indexFromName(b)
        if ia and ib and ia ~= ib then
            return ia < ib
        end
        if ia and not ib then
            return true
        end
        if ib and not ia then
            return false
        end
        return a < b
    end)
    return list
end

local function resolveName(preferred, label)
    if preferred and peripheral.isPresent(preferred) then
        return preferred
    end
    if preferred then
        print(("crystals: missing %s %s"):format(label, tostring(preferred)))
    end
    return nil
end

local function isLocalSide(name)
    return name and LOCAL_SIDES[tostring(name):lower()] == true
end

--- Network inventories that can pushItems to modem-connected engravers.
local function findNetworkBuffers(machineSet)
    machineSet = machineSet or {}
    local list = {}
    local names = peripheral.getNames()
    for i = 1, #names do
        local name = names[i]
        if not machineSet[name] and not isLocalSide(name) then
            local types = peripheralTypes(name)
            if not shouldSkip(name, types) and isInventory(name)
                and matchesAny(name, types, BUFFER_NEEDLES)
            then
                list[#list + 1] = name
            end
        end
        if i % 8 == 0 then
            sleep(0)
        end
    end
    table.sort(list)
    return list
end

--- Find monitor: preferred side/name, else first monitor peripheral.
function discover.monitor(preferred)
    local name = resolveName(preferred, "monitor")
    if name then
        local m = peripheral.wrap(name)
        if m and m.clear then
            return m, name
        end
    end
    for _, n in ipairs(peripheral.getNames()) do
        if peripheral.getType(n) == "monitor" then
            local m = peripheral.wrap(n)
            if m and m.clear then
                return m, n
            end
        end
    end
    return nil, nil
end

--- Buffer: explicit network name > networked crate/chest > local side (last resort).
-- Local sides often cannot pushItems to modem engravers.
function discover.buffer(preferred, machineSet, skip)
    machineSet = machineSet or {}
    skip = skip or {}

    -- Explicit networked peripheral name (not a side).
    if preferred and not isLocalSide(preferred) then
        local name = resolveInventory(preferred, "buffer", machineSet)
        if name and not skip[name] then
            return name
        end
    end

    local netBufs = findNetworkBuffers(machineSet)
    local filtered = {}
    for i = 1, #netBufs do
        if not skip[netBufs[i]] then
            filtered[#filtered + 1] = netBufs[i]
        end
    end
    netBufs = filtered
    if #netBufs == 1 then
        if preferred and isLocalSide(preferred) then
            print("crystals: using networked buffer " .. netBufs[1]
                .. " (local " .. preferred .. " cannot reach modem engravers)")
        end
        return netBufs[1]
    end
    if #netBufs > 1 then
        local pick = netBufs[1]
        for i = 1, #netBufs do
            local n = netBufs[i]:lower()
            if n:find("tungsten", 1, true) or n:find("stainless", 1, true) then
                pick = netBufs[i]
                break
            end
        end
        print("crystals: multiple buffers, using " .. pick)
        return pick
    end

    -- Local side fallback.
    if preferred and isLocalSide(preferred) and isInventory(preferred) and not machineSet[preferred] then
        print("crystals: warning: buffer " .. preferred
            .. " is local-only; put a modem on the crate")
        return preferred
    end
    for _, side in ipairs({ "top", "bottom", "front", "back", "left", "right" }) do
        if isInventory(side) and not machineSet[side] then
            print("crystals: warning: buffer " .. side
                .. " is local-only; put a modem on the crate")
            return side
        end
    end
    return nil
end

function discover.machines(cfg)
    cfg = cfg or {}
    local list = {}
    local taken = {}

    if type(cfg.MACHINES) == "table" and #cfg.MACHINES > 0 then
        for i = 1, #cfg.MACHINES do
            local name = cfg.MACHINES[i]
            if peripheral.isPresent(name) and isInventory(name) then
                list[#list + 1] = name
                taken[name] = true
            else
                print("crystals: missing machine " .. tostring(name))
            end
        end
        return sortMachines(list), taken
    end

    local needles = cfg.MACHINE_SUBSTR or "laser_engraver"
    local names = peripheral.getNames()
    for i = 1, #names do
        local name = names[i]
        local types = peripheralTypes(name)
        if not shouldSkip(name, types) and isInventory(name) and matchesAny(name, types, needles) then
            list[#list + 1] = name
            taken[name] = true
        end
        if i % 8 == 0 then
            sleep(0)
        end
    end
    return sortMachines(list), taken
end

function discover.overflow(cfg, machineSet, primary)
    machineSet = machineSet or {}
    cfg = cfg or {}
    local names = {}
    if type(cfg.OVERFLOW) == "table" then
        names = cfg.OVERFLOW
    elseif type(cfg.OVERFLOW) == "string" and cfg.OVERFLOW ~= "" then
        names = { cfg.OVERFLOW }
    end
    local out = {}
    local seen = {}
    if primary then
        seen[primary] = true
    end
    for i = 1, #names do
        local resolved = resolveInventory(names[i], "overflow", machineSet)
        if resolved and not seen[resolved] then
            seen[resolved] = true
            out[#out + 1] = resolved
        end
    end
    return out
end

function discover.scan(cfg)
    local machines, machineSet = discover.machines(cfg)
    local skip = {}
    local overflowNames = {}
    if type(cfg.OVERFLOW) == "table" then
        overflowNames = cfg.OVERFLOW
    elseif type(cfg.OVERFLOW) == "string" then
        overflowNames = { cfg.OVERFLOW }
    end
    for i = 1, #overflowNames do
        local aliases = nameAliases(overflowNames[i])
        for a = 1, #aliases do
            skip[aliases[a]] = true
        end
    end
    local buffer = discover.buffer(cfg.BUFFER, machineSet, skip)
    local overflow = discover.overflow(cfg, machineSet, buffer)
    local monitor, monitorName = discover.monitor(cfg.MONITOR)
    return {
        machines = machines,
        buffer = buffer,
        overflow = overflow,
        monitor = monitor,
        monitorName = monitorName,
    }
end

function discover.printSummary(net)
    local ov = net.overflow or {}
    print(("crystals: buffer=%s  overflow=%d  engravers=%d  monitor=%s"):format(
        tostring(net.buffer),
        #ov,
        #(net.machines or {}),
        tostring(net.monitorName)
    ))
    for i = 1, #ov do
        print("  overflow: " .. ov[i])
    end
    local m = net.machines or {}
    local show = math.min(#m, 8)
    for i = 1, show do
        print("  engraver: " .. m[i])
    end
    if #m > show then
        print(("  ... +%d more"):format(#m - show))
    end
end

return discover
end

-- module: gems (crystals/gems.lua)
package.preload["gems"] = function(...)
-- Parse GTCEu gem item ids into material + tier (1..5).

local gems = {}

-- Tier order: each next costs 2 of previous (laser engraver upgrade).
gems.TIER_CHIPPED = 1
gems.TIER_FLAWED = 2
gems.TIER_GEM = 3
gems.TIER_FLAWLESS = 4
gems.TIER_EXQUISITE = 5

gems.TIER_NAME = {
    [1] = "chipped",
    [2] = "flawed",
    [3] = "gem",
    [4] = "flawless",
    [5] = "exquisite",
}

gems.MAX_PROCESS_TIER = gems.TIER_FLAWLESS -- exquisite is sink / leaves buffer

-- GT maps these vanilla items as the normal (tier-3) gem for the material.
-- Quality variants stay gtceu:chipped_<mat>_gem / flawless_<mat>_gem / …
local VANILLA_GEMS = {
    ["minecraft:diamond"] = { material = "diamond", tier = 3 },
    ["minecraft:emerald"] = { material = "emerald", tier = 3 },
    ["minecraft:lapis_lazuli"] = { material = "lapis", tier = 3 },
    ["minecraft:quartz"] = { material = "nether_quartz", tier = 3 },
    ["minecraft:amethyst_shard"] = { material = "amethyst", tier = 3 },
    ["minecraft:echo_shard"] = { material = "echo_shard", tier = 3 },
    ["minecraft:coal"] = { material = "coal", tier = 3 },
}

-- Extra crystals common in TFG that should ride the same pipeline / sort.
local EXTRA_GEMS = {
    ["ae2:certus_quartz_crystal"] = { material = "certus_quartz", tier = 3 },
    ["ae2:charged_certus_quartz_crystal"] = { material = "certus_quartz", tier = 3 },
    ["ae2:fluix_crystal"] = { material = "fluix", tier = 3 },
}

local PATTERNS = {
    { tier = 1, re = "^gtceu:chipped_(.+)_gem$" },
    { tier = 2, re = "^gtceu:flawed_(.+)_gem$" },
    { tier = 4, re = "^gtceu:flawless_(.+)_gem$" },
    { tier = 5, re = "^gtceu:exquisite_(.+)_gem$" },
    { tier = 3, re = "^gtceu:(.+)_gem$" },
}

local function makeInfo(itemName, material, tier)
    return {
        name = itemName,
        material = material,
        tier = tier,
        processable = tier <= gems.MAX_PROCESS_TIER,
    }
end

--- Optional runtime aliases from config: gems.addAlias(itemId, material, tier)
local runtimeAliases = {}

function gems.addAlias(itemName, material, tier)
    if not itemName or not material then
        return
    end
    tier = tonumber(tier) or gems.TIER_GEM
    runtimeAliases[itemName] = { material = material, tier = tier }
end

--- @return { name, material, tier, processable } | nil
function gems.parse(itemName)
    if not itemName or type(itemName) ~= "string" then
        return nil
    end

    local alias = runtimeAliases[itemName] or VANILLA_GEMS[itemName] or EXTRA_GEMS[itemName]
    if alias then
        return makeInfo(itemName, alias.material, alias.tier)
    end

    for i = 1, #PATTERNS do
        local p = PATTERNS[i]
        local mat = itemName:match(p.re)
        if mat then
            return makeInfo(itemName, mat, p.tier)
        end
    end
    return nil
end

function gems.isGem(itemName)
    return gems.parse(itemName) ~= nil
end

function gems.short(itemName, maxLen)
    maxLen = maxLen or 18
    local info = gems.parse(itemName)
    local text
    if info then
        text = gems.TIER_NAME[info.tier] .. " " .. info.material
    else
        text = tostring(itemName or "?"):match("([^:/]+)$") or tostring(itemName)
    end
    text = text:gsub("_", " ")
    if #text > maxLen then
        return text:sub(1, maxLen - 1) .. "."
    end
    return text
end

--- Even amount we may take from stock, leaving a single remainder in the buffer.
function gems.evenStock(count)
    count = tonumber(count) or 0
    if count < 2 then
        return 0
    end
    return count - (count % 2)
end

--- How many items we can add so the final stack count stays even (and ≤ maxStack).
function gems.evenRoom(current, maxStack)
    current = tonumber(current) or 0
    maxStack = tonumber(maxStack) or 64
    local room = maxStack - current
    if room <= 0 then
        return 0
    end
    if current % 2 == 1 then
        local rest = room - 1
        return 1 + (rest - (rest % 2))
    end
    return room - (room % 2)
end

return gems
end

-- module: feed (crystals/feed.lua)
package.preload["feed"] = function(...)
-- Feed buffer gems into laser engravers (even counts, dual-slot queue).

local gems = require("gems")

local feed = {}

local INPUT_SLOTS = 2 -- main + extra; queue different crystal types

local function listInv(name)
    if not name or not peripheral.isPresent(name) then
        return nil
    end
    local inv = peripheral.wrap(name)
    if not inv or not inv.list then
        return nil
    end
    local ok, list = pcall(inv.list)
    if not ok or type(list) ~= "table" then
        return nil
    end
    return inv, list
end

--- Aggregate gem stock from one or more buffers.
function feed.bufferStock(bufferNames)
    if type(bufferNames) == "string" then
        bufferNames = { bufferNames }
    end
    local byName = {}
    if not bufferNames then
        return byName
    end
    for bi = 1, #bufferNames do
        local _, list = listInv(bufferNames[bi])
        if list then
            for _, item in pairs(list) do
                if item and item.name then
                    local info = gems.parse(item.name)
                    if info then
                        local cur = byName[item.name]
                        if not cur then
                            cur = {
                                name = item.name,
                                material = info.material,
                                tier = info.tier,
                                processable = info.processable,
                                count = 0,
                            }
                            byName[item.name] = cur
                        end
                        cur.count = cur.count + (item.count or 0)
                    end
                end
            end
        end
    end
    for _, cur in pairs(byName) do
        if cur.processable then
            cur.even = gems.evenStock(cur.count)
        else
            cur.even = 0
        end
        cur.single = cur.count % 2
    end
    return byName
end

--- Inspect engraver gem occupancy (ignores lenses / non-gems).
function feed.inspectMachine(name, maxStack)
    maxStack = maxStack or 64
    local inv, list = listInv(name)
    local stacks = {}
    local byName = {}
    if list then
        for slot, item in pairs(list) do
            if item and item.name then
                local info = gems.parse(item.name)
                if info then
                    local st = {
                        slot = slot,
                        name = item.name,
                        count = item.count or 0,
                        info = info,
                        room = gems.evenRoom(item.count or 0, maxStack),
                    }
                    stacks[#stacks + 1] = st
                    byName[item.name] = st
                end
            end
        end
    end
    return {
        name = name,
        stacks = stacks,
        byName = byName,
        gemSlots = #stacks,
        freeSlots = math.max(0, INPUT_SLOTS - #stacks),
    }
end

local function scoreTarget(m, itemName, room)
    -- Higher = better. Prefer topping up same item, then queue on busy machine, then empty.
    if m.byName[itemName] then
        return 3000 + (m.byName[itemName].count or 0) + room
    end
    if m.freeSlots > 0 and m.gemSlots > 0 then
        return 2000 + m.gemSlots * 10 + room
    end
    if m.freeSlots > 0 then
        return 1000 + room
    end
    return 0
end

local function machineRoom(m, itemName, maxStack)
    local existing = m.byName[itemName]
    if existing then
        return existing.room, existing.count or 0
    end
    if m.freeSlots > 0 then
        return gems.evenRoom(0, maxStack), 0
    end
    return 0, 0
end

--- How many to push: final machine count even; leave 0/1 in buffer when possible.
local function feedAmount(bufferCount, machineCount, maxStack)
    bufferCount = tonumber(bufferCount) or 0
    machineCount = tonumber(machineCount) or 0
    maxStack = tonumber(maxStack) or 64
    local room = maxStack - machineCount
    if room <= 0 or bufferCount <= 0 then
        return 0
    end

    -- Default: take only even stock, leave a single in the buffer.
    local leave = bufferCount % 2
    local takeMax = bufferCount - leave
    local want = math.min(takeMax, room)

    -- Final stack in the machine must be even (otherwise the recipe stalls).
    if (machineCount + want) % 2 ~= 0 then
        if want > 0 then
            want = want - 1
        end
    end

    -- Odd machine with no even adjustment left: spend 1 from buffer to unstall.
    if want == 0 and machineCount % 2 == 1 and room >= 1 and bufferCount >= 1 then
        want = 1
    end

    if want <= 0 then
        return 0
    end
    if (machineCount + want) % 2 ~= 0 then
        return 0
    end
    return want
end

--- Pick best engraver for itemName that still has feed room.
local function bestMachine(machines, itemName, maxStack, bufferCount)
    local best, bestScore, bestWant = nil, 0, 0
    for i = 1, #machines do
        local m = machines[i]
        local _, cur = machineRoom(m, itemName, maxStack)
        local can = false
        if m.byName[itemName] then
            can = true
        elseif m.freeSlots > 0 then
            can = true
            cur = 0
        end
        if can then
            local want = feedAmount(bufferCount, cur, maxStack)
            if want > 0 then
                local sc = scoreTarget(m, itemName, want)
                if sc > bestScore then
                    best, bestScore, bestWant = m, sc, want
                end
            end
        end
    end
    return best, bestWant
end

--- Push up to `limit` of itemName from buffers (primary first) into machine.
-- Returns: moved (number), err (nil | "missing" | "xfer")
local function pushFromBuffer(bufferNames, machineName, itemName, limit)
    if type(bufferNames) == "string" then
        bufferNames = { bufferNames }
    end
    if limit <= 0 then
        return 0, nil
    end
    if not peripheral.isPresent(machineName) then
        return 0, "missing"
    end
    if not bufferNames or #bufferNames == 0 then
        return 0, "xfer"
    end

    local movedTotal = 0
    local anyPresent = false
    local allXferFail = true

    for bi = 1, #bufferNames do
        local bufferName = bufferNames[bi]
        if peripheral.isPresent(bufferName) then
            anyPresent = true
            local source = peripheral.wrap(bufferName)
            if source and source.list and source.pushItems then
                local okList, list = pcall(source.list)
                if okList and type(list) == "table" then
                    local crateFail = false
                    for slot, item in pairs(list) do
                        if item and item.name == itemName and movedTotal < limit then
                            local need = limit - movedTotal
                            local ok, moved = pcall(source.pushItems, machineName, slot, need)
                            if not ok then
                                if not peripheral.isPresent(machineName) then
                                    return movedTotal, "missing"
                                end
                                crateFail = true
                                break
                            end
                            allXferFail = false
                            movedTotal = movedTotal + (tonumber(moved) or 0)
                            if movedTotal >= limit then
                                return movedTotal, nil
                            end
                        end
                    end
                    if not crateFail then
                        allXferFail = false
                    end
                end
            end
        end
    end

    if movedTotal > 0 then
        return movedTotal, nil
    end
    if not anyPresent or allXferFail then
        return 0, "xfer"
    end
    return 0, nil
end

--- Priority: more even stock first, then lower tier (cascade upward), then name.
local function stockPriority(a, b)
    if a.even ~= b.even then
        return a.even > b.even
    end
    if a.tier ~= b.tier then
        return a.tier < b.tier
    end
    return a.name < b.name
end

--- One feed pass. Returns { moved, fed, status, stock, machineStats }.
function feed.tick(bufferNames, machineNames, opts)
    opts = opts or {}
    local maxStack = opts.maxStack or 64
    local batch = opts.batch or 2
    if type(bufferNames) == "string" then
        bufferNames = { bufferNames }
    end

    local stockMap = feed.bufferStock(bufferNames)
    local stockList = {}
    for _, s in pairs(stockMap) do
        if s.processable and (s.count or 0) >= 1 then
            stockList[#stockList + 1] = s
        end
    end
    table.sort(stockList, stockPriority)

    local machines = {}
    local busy, queued, empty, oddFix = 0, 0, 0, 0
    local missing = false
    for i = 1, #machineNames do
        local mName = machineNames[i]
        if not peripheral.isPresent(mName) then
            missing = true
        else
            local m = feed.inspectMachine(mName, maxStack)
            machines[#machines + 1] = m
            if m.gemSlots == 0 then
                empty = empty + 1
            elseif m.gemSlots >= INPUT_SLOTS then
                busy = busy + 1
            else
                queued = queued + 1
            end
            for _, st in ipairs(m.stacks) do
                if st.count % 2 == 1 then
                    oddFix = oddFix + 1
                end
            end
        end
    end

    local anyEven = false
    for i = 1, #stockList do
        if (stockList[i].even or 0) >= batch then
            anyEven = true
            break
        end
    end

    if not anyEven and oddFix == 0 then
        return {
            moved = 0,
            fed = 0,
            status = "idle all singles",
            stock = stockMap,
            stockList = stockList,
            busy = busy,
            queued = queued,
            empty = empty,
            oddFix = oddFix,
            engravers = #machines,
            missing = missing,
        }
    end

    local movedTotal = 0
    local fedOps = 0
    local lastItem = nil
    local xferFail = false

    -- Cap work per tick so the monitor can redraw live between bursts.
    local maxOps = math.max(8, #machines)
    local guard = 0
    while guard < maxOps do
        guard = guard + 1
        local progressed = false

        for si = 1, #stockList do
            local s = stockList[si]
            local available = s.count or 0
            if available >= 1 then
                local m, want = bestMachine(machines, s.name, maxStack, available)
                if m and want and want > 0 then
                    local moved, err = pushFromBuffer(bufferNames, m.name, s.name, want)
                    if err == "missing" then
                        missing = true
                        for mi = #machines, 1, -1 do
                            if machines[mi].name == m.name then
                                table.remove(machines, mi)
                                break
                            end
                        end
                        progressed = true
                    elseif err == "xfer" then
                        xferFail = true
                        break
                    elseif moved > 0 then
                        movedTotal = movedTotal + moved
                        fedOps = fedOps + 1
                        lastItem = s.name
                        s.count = available - moved
                        s.even = gems.evenStock(s.count)
                        s.single = s.count % 2
                        local idx = nil
                        for mi = 1, #machines do
                            if machines[mi].name == m.name then
                                idx = mi
                                break
                            end
                        end
                        if idx then
                            machines[idx] = feed.inspectMachine(m.name, maxStack)
                        end
                        progressed = true
                        sleep(0)
                    end
                end
            end
            if xferFail then
                break
            end
        end

        if xferFail or not progressed then
            break
        end
    end

    busy, queued, empty = 0, 0, 0
    for i = 1, #machines do
        local m = machines[i]
        if peripheral.isPresent(m.name) then
            m = feed.inspectMachine(m.name, maxStack)
            machines[i] = m
            if m.gemSlots == 0 then
                empty = empty + 1
            elseif m.gemSlots >= INPUT_SLOTS then
                busy = busy + 1
            else
                queued = queued + 1
            end
        else
            missing = true
        end
    end

    local status
    if movedTotal > 0 then
        status = ("fed %d"):format(movedTotal)
    elseif xferFail then
        status = "buffer not networked"
    elseif #machines == 0 then
        status = "no live engravers"
    elseif missing then
        status = "rescan engravers"
    else
        status = "wait engravers full"
    end

    return {
        moved = movedTotal,
        fed = fedOps,
        status = status,
        stock = stockMap,
        stockList = stockList,
        busy = busy,
        queued = queued,
        empty = empty,
        oddFix = oddFix,
        engravers = #machines,
        missing = missing,
        xferFail = xferFail,
    }
end

return feed
end

-- module: sort (crystals/sort.lua)
package.preload["sort"] = function(...)
-- Idle sort: same material tiers adjacent; odd leftovers stay as count=1.

local gems = require("gems")

local sort = {}

local function getInv(name)
    if not name or not peripheral.isPresent(name) then
        return nil
    end
    local inv = peripheral.wrap(name)
    if not inv or not inv.list or not inv.pushItems or not inv.size then
        return nil
    end
    return inv
end

local function itemAt(list, slot)
    return list and list[slot] or nil
end

local function push(inv, name, fromSlot, limit, toSlot)
    local ok, moved
    if toSlot ~= nil then
        ok, moved = pcall(inv.pushItems, name, fromSlot, limit, toSlot)
    else
        ok, moved = pcall(inv.pushItems, name, fromSlot, limit)
    end
    if not ok then
        return 0
    end
    return tonumber(moved) or 0
end

local function aggregateGems(list)
    local byName = {}
    for _, item in pairs(list) do
        if item and item.name and gems.isGem(item.name) then
            local info = gems.parse(item.name)
            local cur = byName[item.name]
            if not cur then
                cur = {
                    name = item.name,
                    material = info.material,
                    tier = info.tier,
                    count = 0,
                }
                byName[item.name] = cur
            end
            cur.count = cur.count + (item.count or 0)
        end
    end
    return byName
end

local function materialOrder(byName)
    local mats, seen = {}, {}
    for _, g in pairs(byName) do
        if not seen[g.material] then
            seen[g.material] = true
            mats[#mats + 1] = g.material
        end
    end
    table.sort(mats)
    return mats
end

local function buildPlan(byName, maxStack)
    maxStack = maxStack or 64
    local evenCap = maxStack - (maxStack % 2)
    if evenCap < 2 then
        evenCap = 2
    end
    local plan = {}
    local mats = materialOrder(byName)

    for mi = 1, #mats do
        local mat = mats[mi]
        for tier = 1, 5 do
            local itemName, count = nil, 0
            for _, g in pairs(byName) do
                if g.material == mat and g.tier == tier then
                    itemName, count = g.name, g.count
                    break
                end
            end
            if itemName and count > 0 then
                local even = count - (count % 2)
                local single = count % 2
                while even >= 2 do
                    local n = math.min(even, evenCap)
                    plan[#plan + 1] = { name = itemName, count = n }
                    even = even - n
                end
                if single > 0 then
                    plan[#plan + 1] = { name = itemName, count = 1 }
                end
            end
        end
    end
    return plan
end

local function layoutMatches(list, plan, size)
    for i = 1, #plan do
        local item = itemAt(list, i)
        local want = plan[i]
        if not item or item.name ~= want.name or (item.count or 0) ~= want.count then
            return false
        end
    end
    for i = #plan + 1, size do
        local item = itemAt(list, i)
        if item and gems.isGem(item.name) then
            return false
        end
    end
    return true
end

local function findFree(list, size, avoid)
    for slot = size, 1, -1 do
        if slot ~= avoid and not itemAt(list, slot) then
            return slot
        end
    end
    return nil
end

local function findLowestGem(list, size, maxSlot)
    maxSlot = maxSlot or size
    for slot = 1, maxSlot do
        local item = itemAt(list, slot)
        if item and gems.isGem(item.name) then
            return slot, item
        end
    end
    return nil
end

local function findSource(list, size, itemName, minSlot)
    for slot = minSlot, size do
        local item = itemAt(list, slot)
        if item and item.name == itemName and (item.count or 0) > 0 then
            return slot
        end
    end
    return nil
end

--- Park every gem into the highest free slots so low slots are clear for the plan.
local function parkGemsHigh(inv, name, size)
    local moved = false
    local guard = 0
    while guard < size * 2 do
        guard = guard + 1
        local list = inv.list() or {}
        local free = findFree(list, size, nil)
        if not free then
            break
        end
        -- Only park gems that sit below the free slot (otherwise already high enough).
        local src = findLowestGem(list, size, free - 1)
        if not src then
            break
        end
        local item = itemAt(list, src)
        if push(inv, name, src, item.count, free) > 0 then
            moved = true
        else
            break
        end
        sleep(0)
    end
    return moved
end

local function placePlan(inv, name, size, plan)
    local moved = false
    for dest = 1, #plan do
        local want = plan[dest]
        local guard = 0
        while guard < 48 do
            guard = guard + 1
            local list = inv.list() or {}
            local cur = itemAt(list, dest)

            if cur and cur.name == want.name and (cur.count or 0) == want.count then
                break
            end

            if cur and cur.name == want.name and (cur.count or 0) > want.count then
                local free = findFree(list, size, dest)
                if not free then
                    return moved, false
                end
                if push(inv, name, dest, cur.count - want.count, free) <= 0 then
                    return moved, false
                end
                moved = true
                sleep(0)
            elseif cur then
                local free = findFree(list, size, dest)
                if not free then
                    return moved, false
                end
                if push(inv, name, dest, cur.count, free) <= 0 then
                    return moved, false
                end
                moved = true
                sleep(0)
            else
                local need = want.count
                local src = findSource(inv.list() or {}, size, want.name, dest + 1)
                if not src then
                    break
                end
                local got = push(inv, name, src, need, dest)
                if got <= 0 then
                    -- Fallback: untarged push then hope it lands / retry targeted later.
                    got = push(inv, name, src, need, nil)
                    if got <= 0 then
                        break
                    end
                end
                moved = true
                sleep(0)
            end
        end
        if dest % 4 == 0 then
            sleep(0)
        end
    end
    return moved, true
end

--- Try to free one slot by merging identical partial stacks.
local function tryFreeSlot(inv, name, size, maxStack)
    local list = inv.list() or {}
    if findFree(list, size, nil) then
        return true
    end
    for a = 1, size do
        list = inv.list() or {}
        local ia = itemAt(list, a)
        if ia and gems.isGem(ia.name) and ia.count < maxStack then
            for b = a + 1, size do
                list = inv.list() or {}
                local ib = itemAt(list, b)
                if ib and ib.name == ia.name then
                    if push(inv, name, b, ib.count, a) > 0 then
                        sleep(0)
                        list = inv.list() or {}
                        if findFree(list, size, nil) then
                            return true
                        end
                        ia = itemAt(list, a)
                        if not ia or ia.count >= maxStack then
                            break
                        end
                    end
                end
            end
        end
        if a % 8 == 0 then
            sleep(0)
        end
    end
    list = inv.list() or {}
    return findFree(list, size, nil) ~= nil
end

function sort.buffer(bufferName, opts)
    opts = opts or {}
    local maxStack = opts.maxStack or 64
    local inv = getInv(bufferName)
    if not inv then
        return false, "no buffer"
    end

    local size = inv.size()
    if not size or size < 1 then
        return false, "bad size"
    end

    local list = inv.list() or {}
    local plan = buildPlan(aggregateGems(list), maxStack)
    if #plan == 0 then
        return false, "empty"
    end
    if #plan > size then
        return false, "plan>slots"
    end
    if layoutMatches(list, plan, size) then
        return false, "ok"
    end

    if not tryFreeSlot(inv, bufferName, size, maxStack) then
        return false, "chest full"
    end

    local movedAny = false
    for _ = 1, 3 do
        list = inv.list() or {}
        plan = buildPlan(aggregateGems(list), maxStack)
        if layoutMatches(list, plan, size) then
            return movedAny, ("sorted %d"):format(#plan)
        end

        if parkGemsHigh(inv, bufferName, size) then
            movedAny = true
        end

        local moved, okSpace = placePlan(inv, bufferName, size, plan)
        if moved then
            movedAny = true
        end
        if not okSpace then
            if not tryFreeSlot(inv, bufferName, size, maxStack) then
                return movedAny, "chest full"
            end
        end

        list = inv.list() or {}
        if layoutMatches(list, plan, size) then
            return true, ("sorted %d"):format(#plan)
        end
        sleep(0)
    end

    list = inv.list() or {}
    plan = buildPlan(aggregateGems(list), maxStack)
    if layoutMatches(list, plan, size) then
        return true, ("sorted %d"):format(#plan)
    end
    if movedAny then
        return true, "sort partial"
    end
    return false, "sort failed"
end

local function occupiedCount(list, size)
    local n = 0
    for slot = 1, size do
        if itemAt(list, slot) then
            n = n + 1
        end
    end
    return n
end

--- CC-only overflow: push bulk even gem stacks from main until keepFree empty slots remain.
function sort.spillTo(fromName, overflowNames, opts)
    opts = opts or {}
    local keepFree = tonumber(opts.keepFree) or 8
    local maxMoves = tonumber(opts.maxMoves) or 16
    if type(overflowNames) == "string" then
        overflowNames = { overflowNames }
    end
    if not overflowNames or #overflowNames == 0 then
        return 0, "no overflow"
    end

    local inv = getInv(fromName)
    if not inv then
        return 0, "no buffer"
    end
    local size = inv.size()
    if not size or size < 1 then
        return 0, "bad size"
    end

    local list = inv.list() or {}
    local free = size - occupiedCount(list, size)
    if free >= keepFree then
        return 0, "ok"
    end

    local need = keepFree - free
    local movedTotal = 0
    local ops = 0

    while need > 0 and ops < maxMoves do
        ops = ops + 1
        list = inv.list() or {}
        local pick = nil
        -- Prefer even bulk stacks from high slots; leave odd singles in main.
        for slot = size, 1, -1 do
            local item = itemAt(list, slot)
            if item and gems.isGem(item.name) and (item.count or 0) >= 2 then
                pick = slot
                break
            end
        end
        if not pick then
            break
        end

        local item = itemAt(list, pick)
        local even = (item.count or 0) - ((item.count or 0) % 2)
        if even < 2 then
            break
        end

        local dest = nil
        for i = 1, #overflowNames do
            if overflowNames[i] ~= fromName and peripheral.isPresent(overflowNames[i]) then
                dest = overflowNames[i]
                break
            end
        end
        if not dest then
            return movedTotal, "overflow missing"
        end

        local got = push(inv, dest, pick, even)
        if got <= 0 then
            return movedTotal, "overflow full"
        end
        movedTotal = movedTotal + got
        need = need - 1
        sleep(0)
    end

    if movedTotal > 0 then
        return movedTotal, ("spill %d"):format(movedTotal)
    end
    return 0, "ok"
end

return sort
end

-- module: ui (crystals/ui.lua)
package.preload["ui"] = function(...)
-- 1-block monitor UI for crystal engraver controller (ASCII only).

local ui = {}

local function clip(text, maxLen)
    text = tostring(text or "")
    if maxLen <= 0 or #text <= maxLen then
        return text
    end
    if maxLen <= 1 then
        return "."
    end
    return text:sub(1, maxLen - 1) .. "."
end

local function writeAt(mon, x, y, text, color, maxW)
    mon.setCursorPos(x, y)
    mon.setTextColor(color or colors.white)
    mon.write(clip(text, maxW or 99))
end

local function pad(text, width)
    text = tostring(text or "")
    if #text >= width then
        return text:sub(1, width)
    end
    return text .. string.rep(" ", width - #text)
end

function ui.boot(mon, msg)
    if not mon then
        return
    end
    mon.setTextScale(0.5)
    mon.clear()
    local w = select(1, mon.getSize())
    writeAt(mon, 1, 1, "CRYSTALS", colors.cyan, w)
    writeAt(mon, 1, 3, msg or "boot...", colors.yellow, w)
end

local function stockStats(stockMap)
    local pcs = { 0, 0, 0, 0, 0 }
    local pairCount = 0
    local oddNames = 0
    if stockMap then
        for _, s in pairs(stockMap) do
            local tier = s.tier
            if tier and pcs[tier] then
                pcs[tier] = pcs[tier] + (s.count or 0)
            end
            pairCount = pairCount + math.floor((s.even or 0) / 2)
            if (s.count or 0) % 2 == 1 then
                oddNames = oddNames + 1
            end
        end
    end
    return pcs, pairCount, oddNames
end

--- Two columns with a 1-char gap so "gem 159" + "fls 62" never merge.
local function dual(mon, y, left, right, w, color)
    local gap = 1
    local inner = w - gap
    if inner < 2 then
        writeAt(mon, 1, y, left, color, w)
        return
    end
    local leftW = math.floor(inner / 2)
    local rightW = inner - leftW
    writeAt(mon, 1, y, pad(left, leftW), color, leftW)
    writeAt(mon, leftW + gap + 1, y, pad(right, rightW), color, rightW)
end

--- Compact "tag N" that fits half-width (~6-7 chars on 1x1 @0.5).
local function cell(tag, n, maxW)
    maxW = maxW or 7
    n = tonumber(n) or 0
    local s = tostring(n)
    local room = maxW - #tag - 1
    if room < 1 then
        return clip(tag, maxW)
    end
    if #s > room then
        if n >= 1000 and room >= 3 then
            s = string.format("%dk", math.floor(n / 1000 + 0.5))
        end
        if #s > room then
            s = s:sub(1, room)
        end
    end
    return tag .. " " .. s
end

function ui.draw(mon, state)
    if not mon then
        return
    end
    state = state or {}
    mon.setTextScale(0.5)
    local w, h = mon.getSize()
    mon.clear()

    local live = state.engravers or 0
    local total = state.engraverTotal or live
    local busy = state.busy or 0
    local empty = state.empty or 0
    local pcs, pairCount, oddNames = stockStats(state.stock)
    local colW = math.max(4, math.floor((w - 1) / 2))

    writeAt(mon, 1, 1, "CRYSTALS", colors.cyan, w)
    local engStr
    if total > 0 and live ~= total then
        engStr = live .. "/" .. total
    else
        engStr = tostring(live)
    end
    writeAt(mon, math.max(1, w - #engStr + 1), 1, engStr, colors.white, #engStr)
    writeAt(mon, 1, 2, ("busy %d free %d"):format(busy, empty), colors.white, w)

    writeAt(mon, 1, 3, "buffer pcs", colors.yellow, w)
    dual(mon, 4, cell("chi", pcs[1], colW), cell("flw", pcs[2], colW), w, colors.white)
    dual(mon, 5, cell("gem", pcs[3], colW), cell("fls", pcs[4], colW), w, colors.white)

    local pairColor = pairCount > 0 and colors.lime or colors.lightGray
    dual(mon, 6, cell("pr", pairCount, colW), cell("so", oddNames, colW), w, pairColor)

    local status = tostring(state.status or "-")
    local sc = colors.white
    if state.moved and state.moved > 0 then
        sc = colors.lime
    elseif status:find("sort", 1, true) then
        sc = colors.yellow
    elseif status:find("no live", 1, true) or status:find("no engraver", 1, true) then
        sc = colors.red
    elseif status:find("wait", 1, true) or status:find("idle", 1, true) or status:find("full", 1, true) then
        sc = colors.lightGray
    end
    if h >= 7 then
        writeAt(mon, 1, 7, status, sc, w)
    end
end

return ui
end

-- module: net_watch (shared/net_watch.lua)
package.preload["net_watch"] = function(...)
-- Shared peripheral hotplug / sleep helpers for long-running controllers.

local net_watch = {}

function net_watch.flushEvents(tag)
    tag = tag or "net_watch_flush"
    os.queueEvent(tag)
    while true do
        local ev = os.pullEvent()
        if ev == tag then
            return
        end
    end
end

--- Sleep seconds; return true if a peripheral attach/detach arrived (wakes early).
function net_watch.sleepWatch(seconds)
    local timer = os.startTimer(seconds)
    while true do
        local ev, p1 = os.pullEvent()
        if ev == "timer" and p1 == timer then
            return false
        elseif ev == "peripheral" or ev == "peripheral_detach" then
            return true
        end
    end
end

--- Sleep full duration; call onHotplug() on attach/detach but do not wake early.
function net_watch.sleepDrain(seconds, onHotplug)
    local timer = os.startTimer(seconds)
    while true do
        local ev, p1 = os.pullEvent()
        if ev == "timer" and p1 == timer then
            return
        elseif ev == "peripheral" or ev == "peripheral_detach" then
            if type(onHotplug) == "function" then
                onHotplug()
            end
        end
    end
end

function net_watch.safeCall(name, method, ...)
    local ok, a, b, c = pcall(peripheral.call, name, method, ...)
    if not ok then
        return nil
    end
    return a, b, c
end

function net_watch.safeMethod(obj, method, ...)
    if not obj or type(obj[method]) ~= "function" then
        return nil
    end
    local ok, a, b, c = pcall(obj[method], obj, ...)
    if not ok then
        return nil
    end
    return a, b, c
end

return net_watch
end

-- entry: crystals/main.lua
-- Laser engraver gem upgrade controller (CC: Tweaked / TFG).
-- Buffer on top, monitor on left, HV laser engravers on the network.
--
-- Bundle:  python tools/bundle_project.py crystals
-- Deploy:  dist/crystals.lua + crystals.cfg  (startup: shell.run("crystals"))

local configMod = require("config")
local discover = require("discover")
local feed = require("feed")
local sort = require("sort")
local ui = require("ui")
local gems = require("gems")
local net_watch = require("net_watch")

local config = configMod.load()
if config.ALIASES then
    for i = 1, #config.ALIASES do
        local a = config.ALIASES[i]
        gems.addAlias(a.item, a.material, a.tier)
    end
end
local net = { machines = {}, buffer = nil, overflow = {}, monitor = nil, monitorName = nil }
local dirty = false
local lastStatus = ""
local lastSortAt = 0
local lastRescanAt = -100
local SORT_COOLDOWN = 3
local RESCAN_COOLDOWN = 5
local booted = false

local function setStatus(msg)
    lastStatus = msg
    print("crystals: " .. msg)
end

local function bufferList()
    local list = {}
    if net.buffer then
        list[#list + 1] = net.buffer
    end
    local ov = net.overflow or {}
    for i = 1, #ov do
        if ov[i] ~= net.buffer then
            list[#list + 1] = ov[i]
        end
    end
    return list
end

local function rescan(reason, showBoot)
    net = discover.scan(config)
    if not net.overflow then
        net.overflow = {}
    end
    dirty = false
    lastRescanAt = os.clock()
    if reason then
        print("crystals: rescan (" .. tostring(reason) .. ")")
    end
    discover.printSummary(net)
    if not net.buffer then
        setStatus("no buffer: set buffer | top")
    elseif #net.machines == 0 then
        setStatus("no engravers found")
    end
    -- Only flash "scanning..." on the very first boot, not on every hotplug.
    if showBoot or not booted then
        ui.boot(net.monitor, "scanning...")
        booted = true
    end
end

local function ensureNet()
    local now = os.clock()
    local needScan = false
    local reason = nil

    if not net.buffer or not peripheral.isPresent(net.buffer or "") then
        needScan = true
        reason = "buffer"
    elseif #net.machines == 0 then
        needScan = true
        reason = "machines"
    elseif dirty and (now - lastRescanAt) >= RESCAN_COOLDOWN then
        needScan = true
        reason = "hotplug"
    end

    if needScan then
        rescan(reason, reason == "buffer" and not booted)
    end

    if net.buffer and not peripheral.isPresent(net.buffer) then
        dirty = true
        return false
    end
    return net.buffer ~= nil
end

local function flushEvents()
    net_watch.flushEvents("crystals_flush")
end

--- Sleep full duration; note hotplug but do not wake early (avoid rescan storms).
local function sleepWatch(seconds)
    net_watch.sleepDrain(seconds, function()
        dirty = true
    end)
    return false
end

local function countPairs(stock)
    local n = 0
    if not stock then
        return 0
    end
    for _, s in pairs(stock) do
        n = n + math.floor((s.even or 0) / 2)
    end
    return n
end

local function tick()
    if not ensureNet() then
        ui.draw(net.monitor, {
            status = lastStatus,
            engravers = 0,
            engraverTotal = #(net.machines or {}),
            stock = {},
        })
        return false
    end

    local result = feed.tick(bufferList(), net.machines, {
        maxStack = config.MAX_STACK,
        batch = config.BATCH,
    })

    local didWork = (result.moved or 0) > 0
    local status = result.status
    local pairsLeft = countPairs(result.stock)

    -- Main crate is the intake; CC spills bulk even stacks into overflow to keep room.
    local ov = net.overflow or {}
    if #ov > 0 and not result.xferFail then
        local spilled, spillMsg = sort.spillTo(net.buffer, ov, {
            keepFree = config.KEEP_FREE,
            maxMoves = 12,
        })
        if spilled and spilled > 0 then
            didWork = true
            status = spillMsg or ("spill " .. spilled)
            setStatus(status)
        elseif spillMsg == "overflow full" then
            status = "overflow full"
        elseif spillMsg == "overflow missing" then
            dirty = true
        end
    end

    -- Rescan later if many engravers dropped; ignore single blips.
    if (result.engravers or 0) == 0 and #net.machines > 0 then
        dirty = true
        status = "no live engravers"
    elseif result.missing and (result.engravers or 0) < math.max(1, math.floor(#net.machines / 2)) then
        dirty = true
    end

    if result.xferFail then
        status = "buffer not networked"
        setStatus(status)
    elseif #net.machines == 0 then
        dirty = true
        status = "no engravers found"
    end

    local canSort = not didWork
        and not result.xferFail
        and pairsLeft == 0
        and (result.engravers or 0) > 0

    if canSort then
        local now = os.clock()
        if now - lastSortAt >= SORT_COOLDOWN then
            local sorted, detail = sort.buffer(net.buffer, { maxStack = config.MAX_STACK })
            lastSortAt = now
            if detail == "ok" or detail == "chest full" then
                -- Main may be packed; still tidy overflow crates.
                local ov = net.overflow or {}
                for i = 1, #ov do
                    sort.buffer(ov[i], { maxStack = config.MAX_STACK })
                    sleep(0)
                end
            end
            if detail == "ok" then
                status = result.status
            elseif detail == "chest full" and #(net.overflow or {}) > 0 then
                local spilled = sort.spillTo(net.buffer, net.overflow, {
                    keepFree = config.KEEP_FREE,
                    maxMoves = 8,
                })
                if spilled and spilled > 0 then
                    lastSortAt = now - SORT_COOLDOWN
                    status = "spill then sort"
                else
                    status = "main full, using overflow"
                end
            else
                status = detail or (sorted and "sorted" or result.status)
                if detail and detail ~= "ok" then
                    setStatus(tostring(detail))
                end
                if detail == "sort partial" then
                    lastSortAt = now - SORT_COOLDOWN
                end
            end
        end
    elseif didWork then
        setStatus(status)
    end

    ui.draw(net.monitor, {
        engravers = result.engravers,
        engraverTotal = #(net.machines or {}),
        busy = result.busy,
        queued = result.queued,
        empty = result.empty,
        stock = result.stock,
        moved = result.moved,
        status = status,
    })

    return didWork
end

print(("crystals: batch=%d max_stack=%d poll=%.2fs"):format(
    config.BATCH, config.MAX_STACK, config.POLL
))
rescan("start", true)
flushEvents()
dirty = false

while true do
    local worked = tick()
    if worked then
        sleepWatch(0)
    else
        sleepWatch(config.POLL)
    end
end
