-- Bundled from ae_stats/sampler.lua — do not edit by hand; rebuild with tools/bundle_project.py
-- Also copy the matching .cfg next to this file (sampler.cfg / display.cfg / graphview.cfg; display+graphview also need labels.cfg).
-- Generated package.preload modules + entrypoint.

-- module: util (shared/util.lua)
package.preload["util"] = function(...)
-- Shared string / path helpers for CC:Tweaked scripts.

local util = {}

function util.trim(s)
    return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

function util.split(s, sep)
    local out = {}
    s = tostring(s or "")
    for part in (s .. sep):gmatch("(.-)" .. sep) do
        out[#out + 1] = part
    end
    return out
end

--- Resolve a config path relative to the running program directory.
function util.resolvePath(path, defaultName)
    path = path or defaultName
    if not path then
        error("resolvePath: path required", 2)
    end
    if path:sub(1, 1) == "/" then
        return path
    end
    local base = ""
    if shell and shell.getRunningProgram then
        local prog = shell.getRunningProgram()
        if prog then
            base = fs.getDir(prog)
        end
    end
    return fs.combine(base, path)
end

--- Read entire file as string, or nil if missing.
function util.readAll(path)
    if not path or not fs.exists(path) then
        return nil
    end
    local file = fs.open(path, "r")
    if not file then
        return nil
    end
    local text = file.readAll()
    file.close()
    return text
end

--- Basename of the running program without .lua (e.g. pizza_maintain).
function util.programStem()
    if not (shell and shell.getRunningProgram) then
        return nil
    end
    local prog = shell.getRunningProgram()
    if not prog then
        return nil
    end
    local name = fs.getName(prog)
    return (name:gsub("%.lua$", ""))
end

--- Lines of `[section]` from a sectioned cfg. Nil if file/section missing.
function util.cfgSectionLines(path, section)
    local text = util.readAll(path)
    if not text or not section then
        return nil
    end
    local current = nil
    local buf = {}
    local found = false
    for line in (text .. "\n"):gmatch("(.-)\n") do
        local sec = line:match("^%s*%[([%w_]+)%]%s*$")
        if sec then
            if found then
                break
            end
            if sec == section then
                found = true
                current = sec
                buf = {}
            else
                current = nil
            end
        elseif found and current == section then
            buf[#buf + 1] = line
        end
    end
    if not found then
        return nil
    end
    return buf
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Try sectioned cfg at path; return lines, label or nil.
local function trySectioned(path, section)
    if not path or not fs.exists(path) then
        return nil
    end
    local sectionLines = util.cfgSectionLines(path, section)
    if not sectionLines then
        return nil
    end
    return sectionLines, path .. "[" .. section .. "]"
end

--- Config lines for a logical section.
-- Order: explicit path → <program>.cfg [section] → craft.cfg [section] → fallbackName.
-- Returns lines, label (for errors).
function util.openConfigLines(explicitPath, section, fallbackName)
    if explicitPath then
        local path = util.resolvePath(explicitPath)
        local text = util.readAll(path)
        if not text then
            error("Cannot open " .. path, 2)
        end
        return linesFromText(text), path
    end

    local stem = util.programStem()
    if stem then
        local lines, label = trySectioned(util.resolvePath(nil, stem .. ".cfg"), section)
        if lines then
            return lines, label
        end
    end

    local lines, label = trySectioned(util.resolvePath(nil, "craft.cfg"), section)
    if lines then
        return lines, label
    end

    local path = util.resolvePath(nil, fallbackName)
    local text = util.readAll(path)
    if not text then
        local hint = stem and (stem .. ".cfg") or "program.cfg"
        error(
            "Cannot open " .. path
                .. " (deploy "
                .. hint
                .. " next to the program, or "
                .. tostring(fallbackName)
                .. ")",
            2
        )
    end
    return linesFromText(text), path
end

--- Short display name: last path segment after `/`.
function util.short(id)
    id = tostring(id or "")
    return id:match("([^/]+)$") or id
end

function util.clamp(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

return util
end

-- module: protocol (ae_stats/protocol.lua)
package.preload["protocol"] = function(...)
-- Rednet protocol for ae_stats sampler <-> display <-> graphview.

local protocol = {}

protocol.NAME = "tfg_ae_stats"
protocol.HOST = "ae_stats_sampler"
protocol.GRAPH_HOST = "ae_stats_graph"

-- Message kinds:
--   hello      { kind, role }                    sampler announce / display ping
--   list_req   { kind, q, offset, limit, reply }
--   list_res   { kind, items, total, q }
--   track_set  { kind, items }                   legacy no-op on sampler
--   track_ack  { kind, items }
--   history_req{ kind, item, since, reply }
--   history_res{ kind, item, points, amount }
--   sample     { kind, item, t, amount }         broadcast from sampler
--   focus_set  { kind, item, window?, step?, interp? }  display → graphview


function protocol.encode(msg)
    return textutils.serialize(msg)
end

function protocol.decode(payload)
    if type(payload) ~= "string" then
        return nil
    end
    local ok, msg = pcall(textutils.unserialize, payload)
    if not ok or type(msg) ~= "table" or type(msg.kind) ~= "string" then
        return nil
    end
    return msg
end

function protocol.send(id, msg)
    return rednet.send(id, protocol.encode(msg), protocol.NAME)
end

function protocol.broadcast(msg)
    return rednet.broadcast(protocol.encode(msg), protocol.NAME)
end

--- Wait for a message matching kind (and optional from id). Timeout in seconds.
function protocol.receive(timeout, wantKind, fromId)
    local deadline = timeout and (os.clock() + timeout) or nil
    while true do
        local left = nil
        if deadline then
            left = deadline - os.clock()
            if left <= 0 then
                return nil
            end
        end
        local id, payload, proto = rednet.receive(protocol.NAME, left)
        if not id then
            return nil
        end
        if fromId and id ~= fromId then
            -- keep waiting
        else
            local msg = protocol.decode(payload)
            if msg and (not wantKind or msg.kind == wantKind) then
                return id, msg
            end
        end
    end
end

return protocol
end

-- module: history (ae_stats/history.lua)
package.preload["history"] = function(...)
-- Per-item time series: ring buffer + optional disk persist.

local util = require("util")

local history = {}

local DEFAULT_RETAIN = 2.5 * 3600 -- seconds
local DEFAULT_MAX_SERIES = 512

local function now()
    return os.epoch("utc") / 1000
end

local function prune(self, item)
    local pts = self.series[item]
    if not pts then
        return
    end
    local cutoff = now() - self.retain
    local i = 1
    while i <= #pts and pts[i].t < cutoff do
        i = i + 1
    end
    if i > 1 then
        local trimmed = {}
        for j = i, #pts do
            trimmed[#trimmed + 1] = pts[j]
        end
        self.series[item] = trimmed
    end
end

--- Drop oldest-touched series keys when over max_series.
local function pruneSeriesKeys(self)
    local max = self.max_series
    if not max or max <= 0 then
        return
    end
    local count = 0
    for _ in pairs(self.series) do
        count = count + 1
    end
    if count <= max then
        return
    end
    local keys = {}
    for k in pairs(self.series) do
        keys[#keys + 1] = k
    end
    table.sort(keys, function(a, b)
        local ta = self.touched[a] or 0
        local tb = self.touched[b] or 0
        if ta ~= tb then
            return ta < tb
        end
        return tostring(a) < tostring(b)
    end)
    local remove = count - max
    for i = 1, remove do
        local k = keys[i]
        self.series[k] = nil
        self.touched[k] = nil
    end
end

local methods = {}

function methods:add(item, amount, t)
    if not item then
        return
    end
    t = t or now()
    amount = tonumber(amount) or 0
    local pts = self.series[item]
    if not pts then
        pts = {}
        self.series[item] = pts
    end
    local last = pts[#pts]
    if last and math.abs(last.t - t) < 0.5 then
        last.amount = amount
        last.t = t
    else
        pts[#pts + 1] = { t = t, amount = amount }
    end
    self.touched[item] = t
    self.dirty = true
    prune(self, item)
    pruneSeriesKeys(self)
end

function methods:get(item, since)
    local pts = self.series[item] or {}
    if item then
        self.touched[item] = now()
    end
    if not since then
        return pts
    end
    local out = {}
    for i = 1, #pts do
        if pts[i].t >= since then
            out[#out + 1] = pts[i]
        end
    end
    return out
end

function methods:latest(item)
    local pts = self.series[item]
    if not pts or #pts == 0 then
        return nil
    end
    return pts[#pts]
end

function methods:items()
    local keys = {}
    for k in pairs(self.series) do
        keys[#keys + 1] = k
    end
    table.sort(keys)
    return keys
end

function methods:save()
    if not self.path then
        return false
    end
    if not self.dirty and fs.exists(self.path) then
        return true
    end
    pruneSeriesKeys(self)
    local file = fs.open(self.path, "w")
    if not file then
        return false
    end
    file.write(textutils.serialize({
        retain = self.retain,
        max_series = self.max_series,
        series = self.series,
    }))
    file.close()
    self.dirty = false
    return true
end

function methods:load()
    if not self.path or not fs.exists(self.path) then
        return false
    end
    local text = util.readAll(self.path)
    if not text then
        return false
    end
    local ok, data = pcall(textutils.unserialize, text)
    if not ok or type(data) ~= "table" or type(data.series) ~= "table" then
        return false
    end
    self.series = data.series
    if data.retain then
        self.retain = data.retain
    end
    if data.max_series then
        self.max_series = data.max_series
    end
    self.touched = {}
    for item, pts in pairs(self.series) do
        local lastT = 0
        if type(pts) == "table" and #pts > 0 then
            lastT = pts[#pts].t or 0
        end
        self.touched[item] = lastT
        prune(self, item)
    end
    pruneSeriesKeys(self)
    self.dirty = false
    return true
end

function history.new(opts)
    opts = opts or {}
    local self = {
        retain = opts.retain or DEFAULT_RETAIN,
        max_series = opts.max_series or DEFAULT_MAX_SERIES,
        path = opts.path,
        series = {},
        touched = {},
        dirty = false,
    }
    for k, v in pairs(methods) do
        self[k] = v
    end
    return self
end

return history
end

-- module: cfg_pipe (shared/cfg_pipe.lua)
package.preload["cfg_pipe"] = function(...)
-- Shared pipe-delimited cfg helpers (key | value [| ...]).

local util = require("util")

local cfg_pipe = {}

cfg_pipe.trim = util.trim
cfg_pipe.split = util.split
cfg_pipe.resolvePath = util.resolvePath

function cfg_pipe.parseScale(raw)
    raw = util.trim(tostring(raw or "")):lower()
    if raw == "" or raw == "auto" then
        return "auto"
    end
    local n = tonumber(raw)
    if not n then
        return "auto"
    end
    n = math.floor(n * 2 + 0.5) / 2
    return util.clamp(n, 0.5, 5)
end

--- Split a cfg line into key, value, parts (or nil, errHint).
function cfg_pipe.splitLine(line)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return nil
    end
    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end
    local key = (parts[1] or ""):lower()
    if key == "" then
        return nil, "empty key"
    end
    if parts[2] == nil or parts[2] == "" then
        return nil, key .. " | value"
    end
    return key, parts[2], parts
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Load all lines from a cfg file.
-- @return lines, path, ok
function cfg_pipe.loadLines(path, defaultName)
    path = util.resolvePath(path, defaultName)
    if not fs.exists(path) then
        return nil, path, false
    end
    local text = util.readAll(path)
    if not text then
        error("Cannot open " .. path, 2)
    end
    return linesFromText(text), path, true
end

return cfg_pipe
end

-- module: config_common (ae_stats/config_common.lua)
package.preload["config_common"] = function(...)
-- Shared key|value cfg helpers for ae_stats (thin wrap over shared/cfg_pipe).

local util = require("util")
local cfg_pipe = require("cfg_pipe")

local config_common = {}

config_common.parseScale = cfg_pipe.parseScale
config_common.splitLine = cfg_pipe.splitLine
config_common.loadLines = cfg_pipe.loadLines

--- Track id: "item|<name>" or "fluid|<name>"
function config_common.trackId(kind, name)
    kind = (kind == "fluid") and "fluid" or "item"
    return kind .. "|" .. tostring(name)
end

function config_common.parseTrackId(id)
    id = tostring(id or "")
    local kind, name = id:match("^(%w+)|(.+)$")
    if kind == "item" or kind == "fluid" then
        return kind, name
    end
    return "item", id
end

function config_common.writeWatchlist(path, items)
    path = util.resolvePath(path)
    local file = fs.open(path, "w")
    if not file then
        return false
    end
    file.writeLine("# auto-saved watchlist (track | item|fluid | name)")
    for i = 1, #items do
        local kind, name = config_common.parseTrackId(items[i])
        file.writeLine("track | " .. kind .. " | " .. name)
    end
    file.close()
    return true
end

function config_common.readWatchlist(path)
    path = util.resolvePath(path)
    if not fs.exists(path) then
        return {}
    end
    local file = fs.open(path, "r")
    if not file then
        return {}
    end
    local items = {}
    local seen = {}
    while true do
        local line = file.readLine()
        if not line then
            break
        end
        local key, val, parts = config_common.splitLine(line)
        if key == "track" and val then
            local kind, name
            if parts[3] and parts[3] ~= "" then
                kind = val:lower()
                name = parts[3]
                if kind ~= "fluid" then
                    kind = "item"
                end
            else
                kind, name = "item", val
            end
            local id = config_common.trackId(kind, name)
            if not seen[id] then
                seen[id] = true
                items[#items + 1] = id
            end
        end
    end
    file.close()
    return items
end

return config_common
end

-- entry: ae_stats/sampler.lua
-- AE stats sampler: ME bridge + wireless rednet.
-- Continuously records ALL AE items/fluids so graphs have history
-- before the first time you open a resource on the display.
--
-- Bundle:  python tools/bundle_project.py ae_stats sampler
-- Deploy:  dist/sampler.lua + sampler.cfg on the ME computer
--          (meBridge bottom, wireless modem top)

local util = require("util")
local protocol = require("protocol")
local history = require("history")
local config_common = require("config_common")

local function defaults()
    return {
        modem = "top",
        bridge = "bottom",
        sample_interval = 30,
        retain_hours = 2.5,
        persist_every = 60,
        max_series = 512,
    }
end

local function loadConfig()
    local cfg = defaults()
    local lines, path, ok = config_common.loadLines(nil, "sampler.cfg")
    if not ok then
        return cfg, path, false
    end
    for n = 1, #lines do
        local key, val = config_common.splitLine(lines[n])
        if key == "modem" then
            cfg.modem = val
        elseif key == "bridge" then
            cfg.bridge = val
        elseif key == "sample_interval" then
            cfg.sample_interval = tonumber(val) or cfg.sample_interval
        elseif key == "retain_hours" then
            cfg.retain_hours = tonumber(val) or cfg.retain_hours
        elseif key == "persist_every" then
            cfg.persist_every = tonumber(val) or cfg.persist_every
        elseif key == "max_series" then
            cfg.max_series = tonumber(val) or cfg.max_series
        elseif key == "watchlist" or key == "track" then
            -- ignored: sampler records every AE resource
        elseif key then
            error(("sampler.cfg line %s: unknown key %q"):format(tostring(n), key))
        end
    end
    return cfg, path, true
end

local cfg = loadConfig()

local hist = history.new({
    retain = cfg.retain_hours * 3600,
    max_series = cfg.max_series,
    path = util.resolvePath(nil, "ae_stats_hist"),
})
hist:load()

local lastSampleCount = 0

local function openModem()
    local side = cfg.modem
    if not peripheral.isPresent(side) then
        error("No modem on " .. tostring(side))
    end
    rednet.open(side)
    rednet.host(protocol.NAME, protocol.HOST)
end

local function wrapBridge()
    local want = cfg.bridge
    if want and peripheral.isPresent(want) then
        local p = peripheral.wrap(want)
        if p and (p.getItem or p.listItems or p.listFluid) then
            return p, want
        end
    end
    for _, n in ipairs(peripheral.getNames()) do
        local t = peripheral.getType(n)
        if t == "meBridge" or t == "me_bridge" then
            return peripheral.wrap(n), n
        end
    end
    return nil, nil
end

local function callList(bridge, method)
    if not bridge or type(bridge[method]) ~= "function" then
        return nil
    end
    local ok, a = pcall(function()
        local r = bridge[method]()
        if type(r) == "table" then
            return r
        end
        r = bridge[method]({})
        if type(r) == "table" then
            return r
        end
        return nil
    end)
    if ok then
        return a
    end
    return nil
end

local function iterList(items, fn)
    if type(items) ~= "table" then
        return
    end
    if #items > 0 then
        for i = 1, #items do
            fn(items[i])
        end
    else
        for _, it in pairs(items) do
            fn(it)
        end
    end
end

local function fluidAmount(entry)
    if type(entry) ~= "table" then
        return 0
    end
    return tonumber(entry.amount or entry.count or entry.mb) or 0
end

local function getAmount(bridge, trackId)
    local kind, name = config_common.parseTrackId(trackId)
    if kind == "fluid" then
        if bridge and type(bridge.getFluid) == "function" then
            local ok, info = pcall(function()
                return bridge.getFluid({ name = name })
            end)
            if ok and type(info) == "table" then
                return fluidAmount(info)
            end
        end
        local fluids = callList(bridge, "listFluid") or callList(bridge, "listFluids")
        local found = 0
        iterList(fluids, function(it)
            if type(it) == "table" and tostring(it.name) == name then
                found = fluidAmount(it)
            end
        end)
        return found
    end

    if not bridge or type(bridge.getItem) ~= "function" then
        return 0
    end
    local ok, info = pcall(function()
        return bridge.getItem({ name = name })
    end)
    if not ok or type(info) ~= "table" then
        return 0
    end
    return tonumber(info.amount) or 0
end

local function listResources(bridge, q, offset, limit)
    offset = offset or 0
    limit = limit or 40
    q = util.trim(tostring(q or "")):lower()

    local filtered = {}

    local function push(kind, it)
        if type(it) ~= "table" or not it.name then
            return
        end
        local name = tostring(it.name)
        local disp = tostring(it.displayName or name)
        local amount = (kind == "fluid") and fluidAmount(it) or (tonumber(it.amount) or 0)
        if q == ""
            or name:lower():find(q, 1, true)
            or disp:lower():find(q, 1, true)
            or kind:find(q, 1, true)
        then
            filtered[#filtered + 1] = {
                name = name,
                displayName = disp,
                amount = amount,
                kind = kind,
                id = config_common.trackId(kind, name),
            }
        end
    end

    iterList(callList(bridge, "listItems"), function(it)
        push("item", it)
    end)
    iterList(callList(bridge, "listFluid") or callList(bridge, "listFluids"), function(it)
        push("fluid", it)
    end)

    -- fluids first by amount desc, then items by amount desc
    table.sort(filtered, function(a, b)
        if a.kind ~= b.kind then
            return a.kind == "fluid"
        end
        if a.amount ~= b.amount then
            return a.amount > b.amount
        end
        return a.name < b.name
    end)

    local total = #filtered
    local page = {}
    for i = offset + 1, math.min(total, offset + limit) do
        page[#page + 1] = filtered[i]
    end
    return page, total
end

--- Snapshot every AE item + fluid into history (no rednet flood).
local function sampleOnce(bridge)
    local t = os.epoch("utc") / 1000
    local n = 0

    local function record(kind, it)
        if type(it) ~= "table" or not it.name then
            return
        end
        local id = config_common.trackId(kind, it.name)
        local amount = (kind == "fluid") and fluidAmount(it) or (tonumber(it.amount) or 0)
        hist:add(id, amount, t)
        n = n + 1
        if n % 40 == 0 then
            sleep(0) -- yield so CC does not abort long loops
        end
    end

    iterList(callList(bridge, "listItems"), function(it)
        record("item", it)
    end)
    iterList(callList(bridge, "listFluid") or callList(bridge, "listFluids"), function(it)
        record("fluid", it)
    end)

    lastSampleCount = n
    return n
end

local function handleMessage(sender, msg, bridge)
    if msg.kind == "hello" then
        protocol.send(sender, {
            kind = "hello",
            role = "sampler",
            resources = lastSampleCount,
            series = #(hist:items()),
        })
    elseif msg.kind == "list_req" then
        local items, total = listResources(bridge, msg.q, msg.offset, msg.limit)
        protocol.send(sender, {
            kind = "list_res",
            items = items,
            total = total,
            q = msg.q or "",
        })
    elseif msg.kind == "track_set" or msg.kind == "track_get" then
        -- legacy no-op: everything is recorded continuously
        protocol.send(sender, { kind = "track_ack", items = {} })
    elseif msg.kind == "history_req" then
        local item = msg.item
        local since = msg.since
        -- always refresh with live AE amount so graph matches the list
        local live = bridge and getAmount(bridge, item) or nil
        if live ~= nil then
            hist:add(item, live)
        end
        local pts = hist:get(item, since)
        local latest = hist:latest(item)
        protocol.send(sender, {
            kind = "history_res",
            item = item,
            points = pts,
            amount = live or (latest and latest.amount) or 0,
            pointCount = #pts,
        })
    end
end

local function main()
    openModem()
    local bridge, bridgeName = wrapBridge()
    if not bridge then
        print("Waiting for meBridge...")
    else
        print("meBridge: " .. tostring(bridgeName))
    end
    print("Recording ALL AE items/fluids every " .. tostring(cfg.sample_interval) .. "s")
    print("Rednet host: " .. protocol.HOST)

    -- first full snapshot immediately
    if bridge then
        local ok, err = pcall(sampleOnce, bridge)
        if ok then
            print("Initial sample: " .. tostring(lastSampleCount) .. " resources")
            hist:save()
        else
            print("Initial sample err: " .. tostring(err))
        end
    end

    local sampleTimer = os.startTimer(1)
    local persistTimer = os.startTimer(cfg.persist_every)
    local lastSample = os.clock()

    while true do
        local ev, a, b, c = os.pullEvent()
        if ev == "timer" then
            if a == sampleTimer then
                if not bridge then
                    bridge, bridgeName = wrapBridge()
                end
                if bridge and (os.clock() - lastSample) >= cfg.sample_interval then
                    local ok, err = pcall(sampleOnce, bridge)
                    if not ok then
                        print("sample err: " .. tostring(err))
                        bridge = nil
                    else
                        print("sample " .. tostring(lastSampleCount) .. " @ " .. tostring(cfg.sample_interval) .. "s")
                    end
                    lastSample = os.clock()
                end
                sampleTimer = os.startTimer(1)
            elseif a == persistTimer then
                hist:save()
                persistTimer = os.startTimer(cfg.persist_every)
            end
        elseif ev == "rednet_message" and c == protocol.NAME then
            local msg = protocol.decode(b)
            if msg then
                if not bridge then
                    bridge, bridgeName = wrapBridge()
                end
                local ok, err = pcall(handleMessage, a, msg, bridge)
                if not ok then
                    print("msg err: " .. tostring(err))
                end
            end
        elseif ev == "peripheral" or ev == "peripheral_detach" then
            bridge, bridgeName = wrapBridge()
        end
    end
end

main()
