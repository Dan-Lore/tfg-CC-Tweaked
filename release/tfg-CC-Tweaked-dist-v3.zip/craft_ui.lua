-- Bundled from craft/craft_ui.lua — do not edit by hand; rebuild with tools/bundle_project.py
-- Also copy the matching .cfg next to this file (same basename; sections [storage] and [recipes]).
-- Generated package.preload modules + entrypoint.

-- module: transfer (shared/transfer.lua)
package.preload["transfer"] = function(...)
-- Item and fluid transfers between peripherals.
-- Item queries: exact id, or #namespace:path (item tag via getItemDetail / fallbacks).
-- Domain food/spoil/tag fallbacks are registered by craft/food.lua (optional).

local transfer = {}

local tagFallbacks = {} -- tagId -> predicate(itemName) -> bool
local spoilCheck = nil -- function(detail) -> bool
local foodItemCheck = nil -- function(name) -> bool

function transfer.registerTagFallback(tagId, fn)
    if type(tagId) == "string" and type(fn) == "function" then
        tagFallbacks[tagId] = fn
    end
end

function transfer.setSpoilCheck(fn)
    spoilCheck = fn
end

function transfer.setFoodItemCheck(fn)
    foodItemCheck = fn
end

function transfer.isTag(query)
    return type(query) == "string" and query:sub(1, 1) == "#"
end

function transfer.tagId(query)
    if not transfer.isTag(query) then
        return query
    end
    return query:sub(2)
end

--- Does inventory item (name + optional tags list) match query (exact or #tag)?
function transfer.matches(itemName, tags, query)
    if not query or query == "" then
        return true
    end
    if not transfer.isTag(query) then
        return itemName == query
    end
    local tagId = transfer.tagId(query)
    if type(tags) == "table" then
        for i = 1, #tags do
            if tags[i] == tagId then
                return true
            end
        end
        if tags[tagId] then
            return true
        end
    end
    local fb = tagFallbacks[tagId]
    if fb then
        return fb(itemName) == true
    end
    return false
end

--- TFC/Firmalife food we should inspect for spoil (when food module registered).
function transfer.isFoodItem(name)
    if foodItemCheck then
        return foodItemCheck(name) == true
    end
    return false
end

--- Best-effort spoil detect (delegates to registered check).
function transfer.isSpoiled(detail)
    if spoilCheck then
        return spoilCheck(detail) == true
    end
    return false
end

local function itemTagsFromDetail(detail)
    if not detail then
        return nil
    end
    if type(detail.tags) == "table" then
        return detail.tags
    end
    return nil
end

--- Detail for #tags, or exact food ids when food module registered (spoil filter).
local function slotDetail(inv, slot, itemQuery, itemName)
    if not inv.getItemDetail then
        return nil
    end
    local need = transfer.isTag(itemQuery)
        or (itemName and transfer.isFoodItem(itemName))
    if not need then
        return nil
    end
    local ok, detail = pcall(inv.getItemDetail, slot)
    if ok then
        return detail
    end
    return nil
end

local function slotUsable(itemName, detail, itemQuery)
    if transfer.isSpoiled(detail) then
        return false
    end
    return transfer.matches(itemName, itemTagsFromDetail(detail), itemQuery)
end

local function transferItems(from, to, itemQuery, amount)
    if not from or not to or from == to then
        return 0
    end
    if not peripheral.isPresent(from) or not peripheral.isPresent(to) then
        return 0
    end
    local source = peripheral.wrap(from)
    if not source or not source.list or not source.pushItems then
        return 0
    end
    local movedTotal = 0
    local moveAll = amount == -1
    amount = tonumber(amount) or 0
    if not moveAll and amount <= 0 then
        return 0
    end

    local listed = source.list()
    if not listed then
        return 0
    end

    local n = 0
    for slot, item in pairs(listed) do
        if moveAll or movedTotal < amount then
            local detail = slotDetail(source, slot, itemQuery, item.name)
            if slotUsable(item.name, detail, itemQuery) then
                local limit = moveAll and item.count or (amount - movedTotal)
                local moved = source.pushItems(to, slot, limit) or 0
                movedTotal = movedTotal + moved
            end
        end
        n = n + 1
        if n % 8 == 0 then
            sleep(0)
        end
    end

    return movedTotal
end

setmetatable(transfer, {
    __call = function(_, from, to, itemName, amount)
        return transferItems(from, to, itemName, amount)
    end,
})

function transfer.countItem(invName, itemQuery)
    if not invName or not peripheral.isPresent(invName) then
        return 0
    end
    local inv = peripheral.wrap(invName)
    if not inv or not inv.list then
        return 0
    end
    local total = 0
    local listed = inv.list()
    if not listed then
        return 0
    end
    local n = 0
    for slot, item in pairs(listed) do
        local detail = slotDetail(inv, slot, itemQuery, item.name)
        if slotUsable(item.name, detail, itemQuery) then
            total = total + (item.count or 0)
        end
        n = n + 1
        if n % 8 == 0 then
            sleep(0)
        end
    end
    return total
end

function transfer.countFromMany(sources, itemQuery)
    local total = 0
    if not sources then
        return 0
    end
    for i = 1, #sources do
        total = total + transfer.countItem(sources[i], itemQuery)
    end
    return total
end

function transfer.fromMany(sources, to, itemQuery, amount)
    if not sources or not to then
        return 0
    end
    local movedTotal = 0
    local moveAll = amount == -1
    for i = 1, #sources do
        local from = sources[i]
        if from and from ~= to and peripheral.isPresent(from) then
            if moveAll then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, -1)
            elseif movedTotal < amount then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, amount - movedTotal)
            end
            if not moveAll and movedTotal >= amount then
                break
            end
        end
    end
    return movedTotal
end

function transfer.toMany(from, destinations, itemQuery, amount)
    if not from or not destinations then
        return 0
    end
    local movedTotal = 0
    local moveAll = amount == -1
    for i = 1, #destinations do
        local to = destinations[i]
        if to and to ~= from and peripheral.isPresent(to) then
            if moveAll then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, -1)
            elseif movedTotal < amount then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, amount - movedTotal)
            end
            if not moveAll and movedTotal >= amount then
                break
            end
        end
    end
    return movedTotal
end

function transfer.countFluid(tankName, fluidName)
    local tank = peripheral.wrap(tankName)
    if not tank or type(tank.tanks) ~= "function" then
        return 0
    end
    local total = 0
    for _, t in pairs(tank.tanks()) do
        if t and t.name == fluidName then
            total = total + (t.amount or 0)
        end
    end
    return total
end

function transfer.fluid(from, to, fluidName, amount)
    if not from or not to then
        return 0
    end
    local source = peripheral.wrap(from)
    if not source or type(source.pushFluid) ~= "function" then
        return 0
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then
        return 0
    end
    local moved = source.pushFluid(to, amount, fluidName)
    return tonumber(moved) or 0
end

return transfer
end

-- module: food (craft/food.lua)
package.preload["food"] = function(...)
-- TFC/Firmalife food helpers for craft (tag fallbacks + spoil).
-- Registers into shared/transfer on require so craft stock/push skip rotten food.

local transfer = require("transfer")

local food = {}

local function isRawMeatName(name)
    if type(name) ~= "string" or name:find("/cooked_", 1, true) then
        return false
    end
    local leaf = name:match("([^/]+)$") or ""
    local raw = {
        beef = true, pork = true, chicken = true, mutton = true, bear = true,
        horse_meat = true, venison = true, wolf = true, rabbit = true, hyena = true,
        duck = true, quail = true, chevon = true, camelidae = true, gran_feline = true,
        turtle = true, frog_legs = true, cod = true, salmon = true, tropical_fish = true,
        bluegill = true, largemouth_bass = true, smallmouth_bass = true, rainbow_trout = true,
        lake_trout = true, lake_whitefish = true, crappie = true, oysters = true,
        calamari = true,
    }
    if raw[leaf] then
        return true
    end
    if leaf:find("bass", 1, true) or leaf:find("trout", 1, true)
        or leaf:find("fish", 1, true) or leaf:find("meat", 1, true) then
        return name:sub(1, 9) == "tfc:food/" or name:sub(1, 9) == "tfg:food/"
            or name:sub(1, 15) == "firmalife:food/"
    end
    return false
end

local function isCookedMeatName(name)
    if type(name) ~= "string" then
        return false
    end
    local rawName = name:gsub("/cooked_", "/", 1)
    if rawName == name then
        return false
    end
    return isRawMeatName(rawName)
end

food.isRawMeatName = isRawMeatName
food.isCookedMeatName = isCookedMeatName

local TAG_FALLBACKS = {
    ["tfc:foods/raw_meats"] = isRawMeatName,
    ["tfc:foods/cooked_meats"] = isCookedMeatName,
    ["firmalife:foods/cooked_meats_and_substitutes"] = isCookedMeatName,
    ["firmalife:foods/pizza_ingredients"] = function(name)
        if isCookedMeatName(name) then
            return true
        end
        return name == "tfg:food/magmango"
    end,
}

function food.isFoodItem(name)
    if type(name) ~= "string" then
        return false
    end
    return name:sub(1, 9) == "tfc:food/"
        or name:sub(1, 9) == "tfg:food/"
        or name:sub(1, 15) == "firmalife:food/"
        or name:sub(1, 16) == "firmalife:spice/"
        or name:find(":food/", 1, true) ~= nil
end

function food.isSpoiled(detail)
    if type(detail) ~= "table" then
        return false
    end
    if detail.rotten == true or detail.spoiled == true or detail.decayed == true then
        return true
    end
    local decay = tonumber(detail.decay)
    if decay and decay >= 1 then
        return true
    end
    if type(detail.food) == "table" then
        local f = detail.food
        if f.rotten == true or f.spoiled == true then
            return true
        end
        decay = tonumber(f.decay)
        if decay and decay >= 1 then
            return true
        end
    end
    local dn = tostring(detail.displayName or detail.display_name or ""):lower()
    if dn:find("rotten", 1, true)
        or dn:find("spoiled", 1, true)
        or dn:find("испорч", 1, true)
        or dn:find("гниль", 1, true)
    then
        return true
    end
    return false
end

--- Wire food checks into a transfer module (defaults to shared transfer).
function food.register(t)
    t = t or transfer
    if t.setSpoilCheck then
        t.setSpoilCheck(food.isSpoiled)
    end
    if t.setFoodItemCheck then
        t.setFoodItemCheck(food.isFoodItem)
    end
    if t.registerTagFallback then
        for tag, fn in pairs(TAG_FALLBACKS) do
            t.registerTagFallback(tag, fn)
        end
    end
    return t
end

food.register(transfer)

return food
end

-- module: util (shared/util.lua)
package.preload["util"] = function(...)
-- Shared string / path helpers for CC:Tweaked scripts.

local util = {}

function util.trim(s)
    return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

function util.split(s, sep)
    local out = {}
    s = tostring(s or "")
    for part in (s .. sep):gmatch("(.-)" .. sep) do
        out[#out + 1] = part
    end
    return out
end

--- Resolve a config path relative to the running program directory.
function util.resolvePath(path, defaultName)
    path = path or defaultName
    if not path then
        error("resolvePath: path required", 2)
    end
    if path:sub(1, 1) == "/" then
        return path
    end
    local base = ""
    if shell and shell.getRunningProgram then
        local prog = shell.getRunningProgram()
        if prog then
            base = fs.getDir(prog)
        end
    end
    return fs.combine(base, path)
end

--- Read entire file as string, or nil if missing.
function util.readAll(path)
    if not path or not fs.exists(path) then
        return nil
    end
    local file = fs.open(path, "r")
    if not file then
        return nil
    end
    local text = file.readAll()
    file.close()
    return text
end

--- Basename of the running program without .lua (e.g. pizza_maintain).
function util.programStem()
    if not (shell and shell.getRunningProgram) then
        return nil
    end
    local prog = shell.getRunningProgram()
    if not prog then
        return nil
    end
    local name = fs.getName(prog)
    return (name:gsub("%.lua$", ""))
end

--- Lines of `[section]` from a sectioned cfg. Nil if file/section missing.
function util.cfgSectionLines(path, section)
    local text = util.readAll(path)
    if not text or not section then
        return nil
    end
    local current = nil
    local buf = {}
    local found = false
    for line in (text .. "\n"):gmatch("(.-)\n") do
        local sec = line:match("^%s*%[([%w_]+)%]%s*$")
        if sec then
            if found then
                break
            end
            if sec == section then
                found = true
                current = sec
                buf = {}
            else
                current = nil
            end
        elseif found and current == section then
            buf[#buf + 1] = line
        end
    end
    if not found then
        return nil
    end
    return buf
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Try sectioned cfg at path; return lines, label or nil.
local function trySectioned(path, section)
    if not path or not fs.exists(path) then
        return nil
    end
    local sectionLines = util.cfgSectionLines(path, section)
    if not sectionLines then
        return nil
    end
    return sectionLines, path .. "[" .. section .. "]"
end

--- Config lines for a logical section.
-- Order: explicit path → <program>.cfg [section] → craft.cfg [section] → fallbackName.
-- Returns lines, label (for errors).
function util.openConfigLines(explicitPath, section, fallbackName)
    if explicitPath then
        local path = util.resolvePath(explicitPath)
        local text = util.readAll(path)
        if not text then
            error("Cannot open " .. path, 2)
        end
        return linesFromText(text), path
    end

    local stem = util.programStem()
    if stem then
        local lines, label = trySectioned(util.resolvePath(nil, stem .. ".cfg"), section)
        if lines then
            return lines, label
        end
    end

    local lines, label = trySectioned(util.resolvePath(nil, "craft.cfg"), section)
    if lines then
        return lines, label
    end

    local path = util.resolvePath(nil, fallbackName)
    local text = util.readAll(path)
    if not text then
        local hint = stem and (stem .. ".cfg") or "program.cfg"
        error(
            "Cannot open " .. path
                .. " (deploy "
                .. hint
                .. " next to the program, or "
                .. tostring(fallbackName)
                .. ")",
            2
        )
    end
    return linesFromText(text), path
end

--- Short display name: last path segment after `/`.
function util.short(id)
    id = tostring(id or "")
    return id:match("([^/]+)$") or id
end

function util.clamp(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

return util
end

-- module: recipes (craft/recipes.lua)
package.preload["recipes"] = function(...)
-- Parse recipes.cfg into structured recipe tables.
--
-- Recipe fields:
--   machine  string   e.g. "tfg:hv_food_processor_3"
--   base     string   machine without circuit suffix
--   circuit  number   trailing _N from machine id
--   inputs   { { name, count, fluid? }, ... }
--   outputs  { { name, count, fluid? }, ... }
--   flag     "grow" | "craft" | "processing"
--   oneshot  bool   if true, feed one craft then wait for outputs before next

local util = require("util")

local recipes = {}

--- Override in tests; default prints a warning line.
function recipes.warn(msg)
    print(tostring(msg))
end

--- Parse "mod:id 4" or "mod:fluid 100mb" or "#tag:path 1"
local function parseStack(token)
    token = util.trim(token)
    if token == "" or token == "-" or token:lower() == "null" then
        return nil
    end

    local name, amount, unit = token:match("^(%S+)%s+(%d+)(mb?)$")
    if name then
        return {
            name = name,
            count = tonumber(amount),
            fluid = true,
        }
    end

    name, amount = token:match("^(%S+)%s+(%-?%d+)$")
    if not name then
        error("Bad stack token: " .. token)
    end

    return {
        name = name,
        count = tonumber(amount),
        fluid = false,
    }
end

local function parseStackList(field)
    field = util.trim(field)
    if field == "" or field == "-" or field:lower() == "null" then
        return {}
    end

    field = field:gsub("^%(", ""):gsub("%)$", "")

    local stacks = {}
    for _, token in ipairs(util.split(field, ",")) do
        local stack = parseStack(token)
        if stack then
            stacks[#stacks + 1] = stack
        end
    end
    return stacks
end

local function parseMachine(machine)
    machine = util.trim(machine)
    local base, circuit = machine:match("^(.-)_(%d+)$")
    if base and circuit then
        return machine, base, tonumber(circuit)
    end
    return machine, machine, nil
end

local function parseFlagField(field, lineNo)
    field = util.trim(field or ""):lower()
    local tokens = {}
    for token in field:gmatch("%S+") do
        tokens[#tokens + 1] = token
    end
    if #tokens == 0 then
        error(("Recipe line %s: empty flag"):format(tostring(lineNo)))
    end

    local flag = tokens[1]
    if flag ~= "grow" and flag ~= "craft" and flag ~= "processing" then
        error(("Recipe line %s: unknown flag %q"):format(tostring(lineNo), flag))
    end

    local oneshot = false
    for i = 2, #tokens do
        local t = tokens[i]
        if t == "oneshot" or t == "one" or t == "serial" then
            oneshot = true
        else
            error(("Recipe line %s: unknown flag option %q"):format(tostring(lineNo), t))
        end
    end

    -- Optional 5th field: oneshot / serial (also accepted in flag field as "processing oneshot")
    return flag, oneshot
end

function recipes.parseLine(line, lineNo)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return nil
    end

    local parts = util.split(line, "|")
    if #parts < 4 then
        error(("Recipe line %s: expected machine|inputs|outputs|flag[|oneshot]"):format(tostring(lineNo)))
    end

    local machineRaw = util.trim(parts[1])
    local machine, base, circuit = parseMachine(machineRaw)
    local flag, oneshot = parseFlagField(parts[4], lineNo)

    if #parts >= 5 then
        local extra = util.trim(parts[5]):lower()
        if extra == "oneshot" or extra == "one" or extra == "serial" then
            oneshot = true
        elseif extra ~= "" then
            error(("Recipe line %s: unknown option %q (use oneshot)"):format(tostring(lineNo), extra))
        end
    end

    return {
        machine = machine,
        base = base,
        circuit = circuit,
        inputs = parseStackList(parts[2]),
        outputs = parseStackList(parts[3]),
        flag = flag,
        oneshot = oneshot,
        line = lineNo,
    }
end

--- Map non-fluid output name -> list of recipes that produce it (cfg order).
function recipes.findDuplicateOutputs(list)
    local byOut = {}
    if not list then
        return byOut
    end
    for i = 1, #list do
        local recipe = list[i]
        local outs = recipe.outputs or {}
        for j = 1, #outs do
            local out = outs[j]
            if out and not out.fluid and out.name then
                local bucket = byOut[out.name]
                if not bucket then
                    bucket = {}
                    byOut[out.name] = bucket
                end
                bucket[#bucket + 1] = recipe
            end
        end
    end
    local dups = {}
    for name, bucket in pairs(byOut) do
        if #bucket > 1 then
            dups[name] = bucket
        end
    end
    return dups
end

local function warnDuplicateOutputs(list)
    local dups = recipes.findDuplicateOutputs(list)
    for name, bucket in pairs(dups) do
        local lines = {}
        for i = 1, #bucket do
            lines[#lines + 1] = tostring(bucket[i].line or "?")
        end
        recipes.warn(string.format(
            "recipes: duplicate output %s — using first (lines %s)",
            tostring(name),
            table.concat(lines, ", ")
        ))
    end
end

--- Load recipes. Prefers <program>.cfg [recipes], else recipes.cfg.
-- Duplicate non-fluid outputs: keep cfg order (first wins in craft_plan); warn once.
function recipes.load(path)
    local lines = util.openConfigLines(path, "recipes", "recipes.cfg")
    local list = {}
    for n = 1, #lines do
        local recipe = recipes.parseLine(lines[n], n)
        if recipe then
            list[#list + 1] = recipe
        end
    end
    warnDuplicateOutputs(list)
    return list
end

function recipes.filter(list, pred)
    local out = {}
    for i = 1, #list do
        if pred(list[i]) then
            out[#out + 1] = list[i]
        end
    end
    return out
end

function recipes.byFlag(list, flag)
    return recipes.filter(list, function(r) return r.flag == flag end)
end

function recipes.byMachine(list, machine)
    return recipes.filter(list, function(r) return r.machine == machine end)
end

--- Primary non-fluid output stack, or nil.
function recipes.primaryOutput(recipe)
    if not recipe or not recipe.outputs then
        return nil
    end
    for i = 1, #recipe.outputs do
        if not recipe.outputs[i].fluid then
            return recipe.outputs[i]
        end
    end
    return nil
end

--- Stable key for machine locking: same recipe identity, different from siblings on same machine.
function recipes.recipeKey(recipe)
    if not recipe then
        return "unknown"
    end
    local out = recipes.primaryOutput(recipe)
    local outName = out and out.name or "-"
    return tostring(recipe.machine) .. "|" .. outName
end

return recipes
end

-- module: peripherals (craft/peripherals.lua)
package.preload["peripherals"] = function(...)
-- Resolve GT / TFG machine peripherals from recipe machine ids.
-- Yields while scanning; supports a per-request cache table.

local peripherals = {}

local function peripheralTypes(name)
    local ok, ptype = pcall(peripheral.getType, name)
    if not ok or not ptype then
        return {}
    end
    if type(ptype) == "table" then
        return ptype
    end
    return { ptype }
end

local function typeMatchesRecipe(ptype, recipe)
    if not ptype then
        return false
    end
    ptype = tostring(ptype)
    if ptype == recipe.machine or ptype == recipe.base then
        return true
    end
    local shortBase = recipe.base:match("([^:]+)$") or recipe.base
    if ptype:find(shortBase, 1, true) then
        return true
    end
    if recipe.flag == "grow" and ptype:lower():find("electric_greenhouse", 1, true) then
        return true
    end
    return false
end

local function nameMatchesRecipe(name, recipe)
    if name == recipe.machine or name == recipe.base then
        return true
    end
    local prefix = recipe.base .. "_"
    if name:sub(1, #prefix) == prefix then
        return true
    end
    local shortBase = recipe.base:match("([^:]+)$") or recipe.base
    if name:find(shortBase, 1, true) then
        return true
    end
    if recipe.flag == "grow" and name:lower():find("greenhouse", 1, true) then
        return true
    end
    return false
end

local function collectMatches(recipe)
    local names = peripheral.getNames()
    local matches = {}
    local seen = {}

    for i = 1, #names do
        local name = names[i]
        local matched = nameMatchesRecipe(name, recipe)
        if not matched then
            local types = peripheralTypes(name)
            for j = 1, #types do
                if typeMatchesRecipe(types[j], recipe) then
                    matched = true
                    break
                end
            end
        end
        if matched and not seen[name] then
            seen[name] = true
            matches[#matches + 1] = name
        end
        -- Yield every few peripherals — large TFG networks otherwise kill the computer.
        if i % 8 == 0 then
            sleep(0)
        end
    end
    return matches
end

--- Resolve a physical machine peripheral for a recipe.
-- Optional cache table: cache[recipe.machine] = name|false
function peripherals.resolveMachine(recipe, cache)
    if not recipe then
        return nil
    end
    local key = recipe.machine or "?"
    if cache then
        local hit = cache[key]
        if hit ~= nil then
            if hit == false then
                return nil
            end
            return hit
        end
    end

    local matches = collectMatches(recipe)
    local found = nil
    if #matches > 0 then
        for i = 1, #matches do
            if matches[i] == recipe.machine then
                found = matches[i]
                break
            end
        end
        if not found and recipe.circuit ~= nil then
            local suffix = "_" .. tostring(recipe.circuit)
            for i = 1, #matches do
                if matches[i]:sub(-#suffix) == suffix then
                    found = matches[i]
                    break
                end
            end
        end
        if not found then
            table.sort(matches)
            found = matches[1]
        end
    end

    if cache then
        cache[key] = found or false
    end
    return found
end

return peripherals
end

-- module: craft_stock (craft/craft_stock.lua)
package.preload["craft_stock"] = function(...)
-- Stock counting and recipe input availability (count == pull sources).
-- Snapshots scan each inventory once per tick (with yields) instead of per-item.

require("food")
local transfer = require("transfer")

local craft_stock = {}

local function extraInvOpts(opts)
    local extra = {}
    if opts then
        if opts.from then
            extra[#extra + 1] = opts.from
        end
        if opts.out and opts.out ~= opts.from then
            extra[#extra + 1] = opts.out
        end
    end
    return extra
end

function craft_stock.isCraftableName(name)
    return name and name:sub(1, 1) ~= "#"
end

function craft_stock.pullSourcesFor(store, itemName, opts)
    if store and store.pullSources then
        return store.pullSources(itemName, extraInvOpts(opts))
    end
    local list = {}
    local seen = {}
    local function add(inv)
        if inv and not seen[inv] and peripheral.isPresent(inv) then
            seen[inv] = true
            list[#list + 1] = inv
        end
    end
    if opts then
        add(opts.from)
        add(opts.out)
    end
    return list
end

function craft_stock.countAvailable(store, itemName, opts)
    return transfer.countFromMany(craft_stock.pullSourcesFor(store, itemName, opts), itemName)
end

function craft_stock.countFluidAvailable(store, fluidOrTag)
    if not store then
        return 0, nil
    end
    local info = store.fluidSourceOf(fluidOrTag)
    if not info or not info.peripheral or not info.fluid then
        return 0, nil
    end
    if not peripheral.isPresent(info.peripheral) then
        return 0, nil
    end
    return transfer.countFluid(info.peripheral, info.fluid), info
end

--- Build a stock snapshot by scanning each unique inventory once.
-- itemNames / fluidNames: optional lists to preload (others counted lazily with yield).
function craft_stock.snapshot(store, opts, itemNames, fluidNames)
    local snap = {
        store = store,
        opts = opts,
        items = {},
        fluids = {},
        _itemDone = {},
        _fluidDone = {},
        _invCache = {}, -- invName -> { itemName -> count }
    }

    local function scanInv(invName)
        if snap._invCache[invName] then
            return snap._invCache[invName]
        end
        local bag = {}
        if invName and peripheral.isPresent(invName) then
            local inv = peripheral.wrap(invName)
            if inv and inv.list then
                local ok, listed = pcall(inv.list)
                if ok and listed then
                    for _, item in pairs(listed) do
                        if item and item.name then
                            bag[item.name] = (bag[item.name] or 0) + (item.count or 0)
                        end
                    end
                end
            end
        end
        snap._invCache[invName] = bag
        sleep(0) -- yield after each peripheral scan
        return bag
    end

    local function countItemNow(name)
        local sources = craft_stock.pullSourcesFor(store, name, opts)
        -- Tags need getItemDetail (match + skip spoiled meats). Exact ids use list().
        if transfer.isTag(name) then
            return transfer.countFromMany(sources, name)
        end
        local total = 0
        for i = 1, #sources do
            local bag = scanInv(sources[i])
            total = total + (bag[name] or 0)
        end
        return total
    end

    function snap.item(name)
        if not name then
            return 0
        end
        if snap._itemDone[name] then
            return snap.items[name] or 0
        end
        snap._itemDone[name] = true
        local n = countItemNow(name)
        snap.items[name] = n
        return n
    end

    function snap.fluid(fluidOrTag)
        if not fluidOrTag then
            return 0, nil
        end
        if snap._fluidDone[fluidOrTag] then
            local slot = snap.fluids[fluidOrTag]
            if not slot then
                return 0, nil
            end
            return slot.have, slot.info
        end
        snap._fluidDone[fluidOrTag] = true
        local have, info = craft_stock.countFluidAvailable(store, fluidOrTag)
        snap.fluids[fluidOrTag] = { have = have, info = info }
        sleep(0)
        return have, info
    end

    --- Preload names with yields (call before heavy planning).
    function snap.preload(items, fluids)
        if items then
            for i = 1, #items do
                snap.item(items[i])
            end
        end
        if fluids then
            for i = 1, #fluids do
                snap.fluid(fluids[i])
            end
        end
    end

    if itemNames or fluidNames then
        snap.preload(itemNames, fluidNames)
    end

    return snap
end

--- List missing inputs for `times` craft runs (items + fluids). Does not recurse.
function craft_stock.findMissingInputs(recipe, store, opts, times)
    times = math.max(1, math.floor(tonumber(times) or 1))
    local fluids = {}
    local items = {}
    for i = 1, #recipe.inputs do
        local input = recipe.inputs[i]
        local need = input.count * times
        if input.fluid then
            local have, info = craft_stock.countFluidAvailable(store, input.name)
            if not info then
                fluids[#fluids + 1] = {
                    name = input.name,
                    count = need,
                    fluid = true,
                    error = "no_fluid_source",
                }
            elseif have < need then
                fluids[#fluids + 1] = {
                    name = input.name,
                    count = need - have,
                    fluid = true,
                }
            end
        else
            -- Exact id or #tag — transfer.count handles both.
            local have = craft_stock.countAvailable(store, input.name, opts)
            if have < need then
                items[#items + 1] = {
                    name = input.name,
                    count = need - have,
                    fluid = false,
                    tag = not craft_stock.isCraftableName(input.name) or nil,
                }
            end
        end
    end
    local missing = {}
    for i = 1, #fluids do
        missing[#missing + 1] = fluids[i]
    end
    for i = 1, #items do
        missing[#missing + 1] = items[i]
    end
    return missing
end

--- How many balanced recipe sets can be fed. Grow (no inputs) is always ready.
-- Optional `snap` uses cached counts.
function craft_stock.countCompleteSets(recipe, store, opts, snap)
    if not recipe or not recipe.inputs then
        return 0
    end
    if #recipe.inputs == 0 then
        return 1000000
    end
    local sets = nil
    for i = 1, #recipe.inputs do
        local input = recipe.inputs[i]
        local per = input.count
        if not per or per <= 0 then
            return 0
        end
        local have
        if input.fluid then
            if snap then
                have = snap.fluid(input.name)
            else
                have = craft_stock.countFluidAvailable(store, input.name)
            end
        else
            if snap then
                have = snap.item(input.name)
            else
                have = craft_stock.countAvailable(store, input.name, opts)
            end
        end
        local can = math.floor((have or 0) / per)
        if sets == nil or can < sets then
            sets = can
        end
    end
    return sets or 0
end

return craft_stock
end

-- module: craft_err (craft/craft_err.lua)
package.preload["craft_err"] = function(...)
-- Uniform craft error shape: always `false, { error = code, ... }`.

local craft_err = {}

--- @param code string
--- @param fields table|nil extra fields merged into the error table
function craft_err.fail(code, fields)
    local t = {}
    if type(fields) == "table" then
        for k, v in pairs(fields) do
            t[k] = v
        end
    end
    t.error = code or "error"
    return false, t
end

--- Normalize string-or-table detail into a table with .error.
function craft_err.asTable(detail)
    if type(detail) == "table" then
        if detail.error == nil and type(detail[1]) == "string" then
            detail.error = detail[1]
        end
        return detail
    end
    return { error = tostring(detail or "error") }
end

return craft_err
end

-- module: craft_io (craft/craft_io.lua)
package.preload["craft_io"] = function(...)
-- Feed / drain / craft.run for processing recipes.
-- Burst-pushes complete sets; short poll only while waiting on the machine.

require("food") -- register tag/spoil helpers into transfer
local transfer = require("transfer")
local craft_stock = require("craft_stock")
local craft_err = require("craft_err")

local craft_io = {}

local DEFAULT_CRAFT_WAIT = 300

function craft_io.outputDest(store, recipe, itemName, fallbackOut)
    if not store then
        return fallbackOut
    end
    if recipe and recipe.flag == "grow" then
        local seedItem = store.seedForCrop(itemName)
        if seedItem and seedItem == itemName and recipe.circuit ~= nil then
            return store.seedDest(recipe.circuit)
        end
    end
    return store.destFor(itemName) or fallbackOut
end

function craft_io.pullItemAmount(from, itemName, amount, store, fallbackOut, recipe)
    amount = tonumber(amount) or 0
    if amount <= 0 or not from then
        return 0
    end
    local dest = craft_io.outputDest(store, recipe, itemName, fallbackOut)
    if not dest or not peripheral.isPresent(dest) then
        dest = nil
    end
    local n = 0
    if dest and dest ~= from and peripheral.isPresent(from) then
        n = transfer(from, dest, itemName, amount)
    end
    -- No spill of fridge food into the room-temp overflow crate.
    -- Overflow is only used when destFor already points there (e.g. basil leaves).
    return n
end

function craft_io.pullOutputs(from, stacks, store, fallbackOut, recipe)
    local moved = {}
    for i = 1, #stacks do
        local stack = stacks[i]
        if not stack.fluid then
            local n = craft_io.pullItemAmount(from, stack.name, stack.count, store, fallbackOut, recipe)
            moved[stack.name] = (moved[stack.name] or 0) + n
        end
    end
    return moved
end

--- Rollback items from machine into storage pull-sources (as destinations).
function craft_io.rollbackItems(machine, movedItems, store, opts)
    for name, count in pairs(movedItems) do
        if count and count > 0 then
            local dests = craft_stock.pullSourcesFor(store, name, opts)
            local preferred = {}
            for i = #dests, 1, -1 do
                preferred[#preferred + 1] = dests[i]
            end
            if #preferred == 0 and opts and opts.out then
                preferred[1] = opts.out
            end
            transfer.toMany(machine, preferred, name, count)
        end
    end
end

--- Rollback fluids from machine into configured fluid_source tanks.
function craft_io.rollbackFluids(machine, movedFluids, store)
    if not store or not movedFluids then
        return
    end
    for name, count in pairs(movedFluids) do
        if count and count > 0 then
            local info = store.fluidSourceOf(name)
            if info and info.peripheral and info.fluid and peripheral.isPresent(info.peripheral) then
                transfer.fluid(machine, info.peripheral, info.fluid, count)
            end
        end
    end
end

--- Check that one full recipe set is available in storage (no moves).
function craft_io.setAvailable(recipe, store, opts)
    for i = 1, #recipe.inputs do
        local input = recipe.inputs[i]
        if input.fluid then
            local have, info = craft_stock.countFluidAvailable(store, input.name)
            if not info then
                return false, {
                    name = input.name,
                    count = input.count,
                    fluid = true,
                    error = "no_fluid_source",
                }
            end
            if have < input.count then
                return false, {
                    name = input.name,
                    count = input.count - have,
                    fluid = true,
                }
            end
        else
            local have = craft_stock.countAvailable(store, input.name, opts)
            if have < input.count then
                return false, {
                    name = input.name,
                    count = input.count - have,
                    fluid = false,
                }
            end
        end
    end
    return true, nil
end

local function rollbackAll(machine, movedItems, movedFluids, store, opts)
    craft_io.rollbackItems(machine, movedItems, store, opts)
    craft_io.rollbackFluids(machine, movedFluids, store)
end

--- Push exactly one recipe unit into the machine. Rolls back items+fluids on mid-set failure.
function craft_io.pushOneSet(recipe, machine, store, opts)
    local okAvail, missing = craft_io.setAvailable(recipe, store, opts)
    if not okAvail then
        return false, {}, missing
    end

    local movedItems = {}
    local movedFluids = {}

    for i = 1, #recipe.inputs do
        local input = recipe.inputs[i]
        if not input.fluid then
            local sources = craft_stock.pullSourcesFor(store, input.name, opts)
            local n = transfer.fromMany(sources, machine, input.name, input.count)
            movedItems[input.name] = (movedItems[input.name] or 0) + n
            if n < input.count then
                rollbackAll(machine, movedItems, movedFluids, store, opts)
                return false, movedItems, {
                    name = input.name,
                    count = input.count - n,
                    fluid = false,
                    error = "push_short",
                }
            end
        end
    end

    for i = 1, #recipe.inputs do
        local input = recipe.inputs[i]
        if input.fluid then
            local _, info = craft_stock.countFluidAvailable(store, input.name)
            if not info then
                rollbackAll(machine, movedItems, movedFluids, store, opts)
                return false, movedItems, {
                    name = input.name,
                    count = input.count,
                    fluid = true,
                    error = "no_fluid_source",
                }
            end
            local n = transfer.fluid(info.peripheral, machine, info.fluid, input.count)
            movedFluids[input.name] = (movedFluids[input.name] or 0) + n
            if n < input.count then
                rollbackAll(machine, movedItems, movedFluids, store, opts)
                local moved = {}
                for k, v in pairs(movedItems) do
                    moved[k] = v
                end
                for k, v in pairs(movedFluids) do
                    moved[k] = (moved[k] or 0) + v
                end
                return false, moved, {
                    name = input.name,
                    count = input.count - n,
                    fluid = true,
                    error = "push_short",
                }
            end
        end
    end

    local moved = {}
    for k, v in pairs(movedItems) do
        moved[k] = v
    end
    for k, v in pairs(movedFluids) do
        moved[k] = (moved[k] or 0) + v
    end
    return true, moved, nil
end

function craft_io.craftWaitTimeout(opts, times)
    times = math.max(1, math.floor(tonumber(times) or 1))
    local base = opts and opts.craftWaitTimeout
    if not base and opts and opts.waitTicks and opts.waitTicks > 0 then
        base = opts.waitTicks / 20
    end
    base = tonumber(base) or DEFAULT_CRAFT_WAIT
    return base * times
end

--- Pull fluid from machine into the fluid_source tank for this recipe fluid/tag.
function craft_io.pullFluidAmount(from, fluidOrTag, amount, store)
    amount = tonumber(amount) or 0
    if amount <= 0 or not from or not store then
        return 0
    end
    local info = store.fluidSourceOf(fluidOrTag)
    if not info or not info.peripheral or not info.fluid then
        return 0
    end
    if not peripheral.isPresent(from) or not peripheral.isPresent(info.peripheral) then
        return 0
    end
    return transfer.fluid(from, info.peripheral, info.fluid, amount)
end

function craft_io.drainToward(pullFrom, need, pulled, store, fallbackOut, recipe, fluidKeys)
    local complete = true
    for name, want in pairs(need) do
        local remaining = want - (pulled[name] or 0)
        if remaining > 0 then
            local n
            if fluidKeys and fluidKeys[name] then
                n = craft_io.pullFluidAmount(pullFrom, name, remaining, store)
            else
                n = craft_io.pullItemAmount(pullFrom, name, remaining, store, fallbackOut, recipe)
            end
            pulled[name] = (pulled[name] or 0) + n
            if pulled[name] < want then
                complete = false
            end
        end
    end
    return complete
end

--- Build item+fluid output need maps.
-- @return need, anyItem, fluidKeys, anyFluid
function craft_io.buildNeedMap(outputs, times)
    local need = {}
    local fluidKeys = {}
    local anyItem = false
    local anyFluid = false
    for i = 1, #outputs do
        local o = outputs[i]
        need[o.name] = (need[o.name] or 0) + o.count * times
        if o.fluid then
            anyFluid = true
            fluidKeys[o.name] = true
        else
            anyItem = true
        end
    end
    return need, anyItem, fluidKeys, anyFluid
end

--- Set-by-set feed + continuous drain. Does not take the machine lock.
function craft_io.run(recipe, opts)
    assert(recipe, "recipe required")
    assert(opts and opts.machine, "opts.machine required")
    local store = opts.store
    local from = opts.from or (store and store.main())
    local out = opts.out or (store and store.main())
    assert(from and out, "opts.from/opts.out or opts.store required")

    if recipe.flag == "grow" then
        return craft_err.fail("use_request", {
            message = "use craft.request for grow recipes",
        })
    end

    local times = math.max(1, math.floor(tonumber(opts.times) or 1))
    local missingList = craft_stock.findMissingInputs(recipe, store, opts, times)
    if #missingList > 0 then
        return false, {
            error = "missing_input",
            missing = missingList[1],
            missing_all = missingList,
        }
    end

    local oneshot = recipe.oneshot == true
    local targetSets = times
    local need, anyItem, fluidKeys, anyFluid = craft_io.buildNeedMap(recipe.outputs, targetSets)
    local anyOutput = anyItem or anyFluid
    local pulled = {}
    for name in pairs(need) do
        pulled[name] = 0
    end

    local pullFrom = opts.pullFrom or opts.machine
    local timeout = craft_io.craftWaitTimeout(opts, times)
    local deadline = os.clock() + timeout
    local setsPushed = 0
    local movedTotals = {}
    local lastMissing = nil
    local pushing = true
    local stallSince = nil -- os.clock when stock-short stall began
    local POLL = 0.05
    local STALL_STOP_PUSH = 6 -- seconds
    local STALL_FAIL = 10 -- seconds

    local function rebuildNeed(sets)
        need, anyItem, fluidKeys, anyFluid = craft_io.buildNeedMap(recipe.outputs, sets)
        anyOutput = anyItem or anyFluid
        for name in pairs(need) do
            if not pulled[name] then
                pulled[name] = 0
            end
        end
    end

    local function outputsComplete()
        if not anyOutput then
            return setsPushed >= targetSets
        end
        for name, want in pairs(need) do
            if (pulled[name] or 0) < want then
                return false
            end
        end
        return true
    end

    local function readyForNextSet()
        if not oneshot or setsPushed == 0 then
            return true
        end
        if not anyOutput then
            return true
        end
        local needSoFar = craft_io.buildNeedMap(recipe.outputs, setsPushed)
        for name, want in pairs(needSoFar) do
            if (pulled[name] or 0) < want then
                return false
            end
        end
        return true
    end

    local function successDetail()
        return {
            inputs = movedTotals,
            outputs = pulled,
            machine = recipe.machine,
            circuit = recipe.circuit,
            flag = recipe.flag,
            times = targetSets,
            sets_pushed = setsPushed,
        }
    end

    local function finishOk()
        local detail = successDetail()
        if targetSets < times then
            local shortName = nil
            local shortCount = 0
            for i = 1, #recipe.outputs do
                local o = recipe.outputs[i]
                if not o.fluid then
                    shortName = o.name
                    shortCount = shortCount + o.count * (times - targetSets)
                end
            end
            return false, {
                error = "craft_short",
                missing = {
                    name = shortName or (recipe.outputs[1] and recipe.outputs[1].name),
                    count = math.max(1, shortCount),
                },
                outputs = pulled,
                times = targetSets,
                sets_pushed = setsPushed,
                wanted_times = times,
            }
        end
        return true, detail
    end

    local function emitSetsProgress()
        if opts and type(opts.onSetsProgress) == "function" then
            pcall(opts.onSetsProgress, setsPushed, targetSets, pulled)
        end
    end

    while os.clock() < deadline do
        craft_io.drainToward(pullFrom, need, pulled, store, out, recipe, fluidKeys)
        emitSetsProgress()
        if outputsComplete() then
            return finishOk()
        end

        -- Burst: push as many sets as possible without sleeping between successes.
        while pushing and setsPushed < targetSets and readyForNextSet() and os.clock() < deadline do
            local ok, moved, missing = craft_io.pushOneSet(recipe, opts.machine, store, opts)
            if ok then
                setsPushed = setsPushed + 1
                stallSince = nil
                for k, v in pairs(moved) do
                    movedTotals[k] = (movedTotals[k] or 0) + v
                end
                emitSetsProgress()
                craft_io.drainToward(pullFrom, need, pulled, store, out, recipe, fluidKeys)
                if outputsComplete() then
                    return finishOk()
                end
                -- Yield so CC never hits "too long without yielding" on large batches.
                sleep(0)
                if oneshot then
                    break
                end
            else
                lastMissing = missing
                if missing and missing.error == "push_short" then
                    -- Machine input full: wait briefly for GT to consume.
                    stallSince = nil
                else
                    if not stallSince then
                        stallSince = os.clock()
                    end
                    local stalledFor = os.clock() - stallSince
                    if setsPushed > 0 and stalledFor > STALL_STOP_PUSH then
                        pushing = false
                        targetSets = setsPushed
                        rebuildNeed(targetSets)
                    elseif setsPushed == 0 and stalledFor > STALL_FAIL then
                        return false, {
                            error = "missing_input",
                            missing = missing,
                            moved = movedTotals,
                            times = times,
                            sets_pushed = setsPushed,
                        }
                    end
                end
                break
            end
        end

        if outputsComplete() then
            return finishOk()
        end
        -- Brief yield while waiting on GT / oneshot / stock.
        sleep(POLL)
    end

    craft_io.drainToward(pullFrom, need, pulled, store, out, recipe, fluidKeys)
    emitSetsProgress()
    if outputsComplete() then
        return finishOk()
    end

    local shortName, shortCount = nil, 0
    for name, want in pairs(need) do
        local left = want - (pulled[name] or 0)
        if left > shortCount then
            shortName = name
            shortCount = left
        end
    end
    return false, {
        error = "craft_timeout",
        missing = lastMissing or {
            name = shortName or (recipe.outputs[1] and recipe.outputs[1].name) or recipe.machine,
            count = shortCount > 0 and shortCount or 1,
        },
        outputs = pulled,
        hint = "machine stalled or timed out (output slots / power / circuit)",
        times = targetSets,
        sets_pushed = setsPushed,
    }
end

return craft_io
end

-- module: greenhouse (craft/greenhouse.lua)
package.preload["greenhouse"] = function(...)
-- Electric greenhouse control.
-- Greenhouses stay disabled by default. A short enable pulse is enough for
-- GregTech to finish one grow recipe after the machine is turned off again.

local Greenhouse = {}

local DEFAULT_PULSE = 3 -- seconds; enough to latch one grow cycle

local function wrapMachine(machineName)
    local machine = peripheral.wrap(machineName)
    if not machine then
        return nil, "greenhouse not found: " .. tostring(machineName)
    end
    if type(machine.setWorkingEnabled) ~= "function" then
        return nil, "no setWorkingEnabled: " .. tostring(machineName)
    end
    return machine
end

function Greenhouse.setEnabled(machineName, enabled)
    local machine, err = wrapMachine(machineName)
    if not machine then
        return false, err
    end
    machine.setWorkingEnabled(enabled and true or false)
    return true
end

--- Keep greenhouse off (default state).
function Greenhouse.disable(machineName)
    return Greenhouse.setEnabled(machineName, false)
end

function Greenhouse.enable(machineName)
    return Greenhouse.setEnabled(machineName, true)
end

--- Brief on-pulse, then force off. Recipe continues to completion on its own.
-- @return ok, err
function Greenhouse.pulse(machineName, pulseSeconds)
    local machine, err = wrapMachine(machineName)
    if not machine then
        return false, err
    end

    pulseSeconds = tonumber(pulseSeconds) or DEFAULT_PULSE
    if pulseSeconds < 1 then
        pulseSeconds = DEFAULT_PULSE
    end

    machine.setWorkingEnabled(true)
    sleep(pulseSeconds)
    machine.setWorkingEnabled(false)
    return true
end

--- Disable every resolved grow machine (call on cleaner/craft startup).
-- @param resolveFn function(recipe) -> peripheral name | nil
-- @param growRecipes list of grow recipes
function Greenhouse.disableAll(resolveFn, growRecipes)
    if type(resolveFn) ~= "function" or type(growRecipes) ~= "table" then
        return
    end
    local seen = {}
    for i = 1, #growRecipes do
        local name = resolveFn(growRecipes[i])
        if name and not seen[name] then
            seen[name] = true
            Greenhouse.disable(name)
        end
    end
end

-- Back-compat alias used by older callers
Greenhouse.runFor = Greenhouse.pulse

return Greenhouse
end

-- module: craft_grow (craft/craft_grow.lua)
package.preload["craft_grow"] = function(...)
-- Greenhouse grow: pulse machine, wait for output bus, pull products.

require("food")
local transfer = require("transfer")
local recipes = require("recipes")
local greenhouse = require("greenhouse")
local craft_io = require("craft_io")

local craft_grow = {}

local DEFAULT_GROW_PULSE = 3
local DEFAULT_GROW_WAIT = 600

craft_grow.DEFAULT_GROW_PULSE = DEFAULT_GROW_PULSE
craft_grow.DEFAULT_GROW_WAIT = DEFAULT_GROW_WAIT

local function growPullFrom(recipe, machine, opts)
    local store = opts.store
    if opts.pullFrom then
        return opts.pullFrom
    end
    if store then
        local bus = store.outputBus(recipe.circuit or 0)
        if bus and peripheral.isPresent(bus) then
            return bus
        end
    end
    return machine
end

function craft_grow.run(recipe, machine, opts)
    local pulse = opts.growPulse or DEFAULT_GROW_PULSE
    local waitTimeout = opts.growWaitTimeout or DEFAULT_GROW_WAIT
    local store = opts.store
    local pullFrom = growPullFrom(recipe, machine, opts)
    local outStack = recipes.primaryOutput(recipe)
    local before = outStack and transfer.countItem(pullFrom, outStack.name) or 0
    local need = outStack and outStack.count or 1

    local ok, err = greenhouse.pulse(machine, pulse)
    greenhouse.disable(machine)
    if not ok then
        return false, {
            error = "grow_failed",
            missing = { name = machine, count = 1 },
            detail = err,
        }
    end

    local deadline = os.clock() + waitTimeout
    local ready = false
    while os.clock() < deadline do
        greenhouse.disable(machine)
        if outStack and transfer.countItem(pullFrom, outStack.name) >= before + need then
            ready = true
            break
        end
        sleep(1)
    end

    greenhouse.disable(machine)

    if outStack and not ready then
        return false, {
            error = "grow_timeout",
            missing = { name = outStack.name, count = need },
            machine = machine,
        }
    end

    local out = opts.out or (store and store.main())
    local outputs = craft_io.pullOutputs(pullFrom, recipe.outputs, store, out, recipe)
    return true, {
        inputs = {},
        outputs = outputs,
        machine = recipe.machine,
        circuit = recipe.circuit,
        flag = "grow",
        pulse = pulse,
    }
end

return craft_grow
end

-- module: machine_lock (craft/machine_lock.lua)
package.preload["machine_lock"] = function(...)
-- Exclusive peripheral locks shared across craft / miller on the SAME computer.
-- Same recipeKey can queue (stack); different crafts wait for the machine to free.
--
-- CONTRACT: locks are in-process only. Scripts on other computers
-- (pizza_maintain, greenhouse_clean, craft_ui, wheat_grain, …) are NOT
-- coordinated. Run conflicting craft entrypoints on one CC computer, or
-- accept possible peripheral races across the wired network.

local machine_lock = {}

local locks = {} -- name -> { key = recipeKey }
local LOCK_POLL = 0.05

function machine_lock.isBusy(machine)
    return machine ~= nil and locks[machine] ~= nil
end

function machine_lock.keyOf(machine)
    local lock = machine and locks[machine]
    return lock and lock.key or nil
end

function machine_lock.busyAny()
    for _ in pairs(locks) do
        return true
    end
    return false
end

--- True if free, or held by the same recipe (caller may queue/stack).
function machine_lock.canStack(machine, recipeKey)
    if not machine then
        return false
    end
    local lock = locks[machine]
    if not lock then
        return true
    end
    return lock.key == (recipeKey or "unknown")
end

--- Wait until free, then run fn under lock.
function machine_lock.withLock(machine, recipeKey, fn)
    recipeKey = recipeKey or "unknown"
    while true do
        if not locks[machine] then
            locks[machine] = { key = recipeKey }
            break
        end
        sleep(LOCK_POLL)
    end

    local ok, a, b = pcall(fn)
    locks[machine] = nil
    if not ok then
        return false, {
            error = "exception",
            missing = { name = tostring(a), count = 1 },
        }
    end
    return a, b
end

--- Non-blocking: fail with error=busy if already held.
function machine_lock.tryLock(machine, recipeKey, fn)
    if not machine then
        return false, { error = "no_machine" }
    end
    if locks[machine] then
        return false, { error = "busy" }
    end
    locks[machine] = { key = recipeKey or "unknown" }
    local ok, a, b = pcall(fn)
    locks[machine] = nil
    if not ok then
        return false, {
            error = "exception",
            missing = { name = tostring(a), count = 1 },
        }
    end
    return a, b
end

--- If free → tryLock; if same recipe already running → withLock (stack/queue).
-- Different recipe holding the machine → busy (do not steal).
function machine_lock.runOrStack(machine, recipeKey, fn)
    recipeKey = recipeKey or "unknown"
    if not machine then
        return false, { error = "no_machine" }
    end
    local lock = locks[machine]
    if not lock then
        return machine_lock.tryLock(machine, recipeKey, fn)
    end
    if lock.key == recipeKey then
        return machine_lock.withLock(machine, recipeKey, fn)
    end
    return false, { error = "busy" }
end

return machine_lock
end

-- module: craft_plan (craft/craft_plan.lua)
package.preload["craft_plan"] = function(...)
-- Recipe index, depth, top-down demand, bottom-up ready jobs.

local recipes = require("recipes")
local craft_stock = require("craft_stock")
local machine_lock = require("machine_lock")

local craft_plan = {}

local function batchTimes(recipe, ready, runsWanted)
    if recipe.flag == "grow" or recipe.oneshot == true then
        return 1
    end
    return math.max(1, math.min(ready, runsWanted))
end

--- Build once per craft.request: recipeByOutput, depth.
function craft_plan.buildIndex(list, findByOutput)
    local byOutput = {}
    for i = 1, #list do
        local recipe = list[i]
        for j = 1, #recipe.outputs do
            local out = recipe.outputs[j]
            if not out.fluid and not byOutput[out.name] then
                byOutput[out.name] = {
                    recipe = recipe,
                    outStack = out,
                }
            end
        end
    end

    if findByOutput then
        for name in pairs(byOutput) do
            local recipe, outStack = findByOutput(list, name)
            if recipe and outStack then
                byOutput[name] = { recipe = recipe, outStack = outStack }
            end
        end
    end

    local depthMemo = {}
    local visiting = {}

    local function depthOf(itemId)
        if depthMemo[itemId] ~= nil then
            return depthMemo[itemId]
        end
        if visiting[itemId] then
            return 0
        end
        local entry = byOutput[itemId]
        if not entry then
            depthMemo[itemId] = 0
            return 0
        end
        visiting[itemId] = true
        local maxChild = 0
        local recipe = entry.recipe
        for i = 1, #recipe.inputs do
            local input = recipe.inputs[i]
            -- Recurse into producers for concrete items and item-tags alike.
            if not input.fluid and byOutput[input.name] then
                local d = depthOf(input.name)
                if d > maxChild then
                    maxChild = d
                end
            end
        end
        visiting[itemId] = nil
        depthMemo[itemId] = maxChild + 1
        return depthMemo[itemId]
    end

    for name in pairs(byOutput) do
        depthOf(name)
    end

    return {
        byOutput = byOutput,
        depth = depthMemo,
    }
end

function craft_plan.batchTimes(recipe, ready, runsWanted)
    return batchTimes(recipe, ready, runsWanted)
end

--- Collect item/fluid names reachable from root (for snapshot preload). Lightweight, no peripherals.
function craft_plan.collectNames(index, rootItemId)
    local items = {}
    local fluids = {}
    local seenItem = {}
    local seenFluid = {}
    local visiting = {}

    local function addItem(name)
        if name and not seenItem[name] then
            seenItem[name] = true
            items[#items + 1] = name
        end
    end

    local function addFluid(name)
        if name and not seenFluid[name] then
            seenFluid[name] = true
            fluids[#fluids + 1] = name
        end
    end

    local function walk(itemId)
        if not itemId or visiting[itemId] then
            return
        end
        visiting[itemId] = true
        addItem(itemId)
        local entry = index.byOutput[itemId]
        if not entry then
            visiting[itemId] = nil
            return
        end
        local recipe = entry.recipe
        for i = 1, #recipe.inputs do
            local input = recipe.inputs[i]
            if input.fluid then
                addFluid(input.name)
            else
                addItem(input.name)
                if index.byOutput[input.name] then
                    walk(input.name)
                end
            end
        end
        visiting[itemId] = nil
    end

    walk(rootItemId)
    return items, fluids
end

--- Top-down demand using snap only (no extra peripheral scans).
function craft_plan.computeDemand(index, rootItemId, rootStill, snap, inflight)
    local need = {}
    local deficit = {}
    local hard = nil
    local visiting = {}

    local function consider(itemId, wantUnits)
        if wantUnits <= 0 or visiting[itemId] then
            return
        end
        visiting[itemId] = true

        local entry = index.byOutput[itemId]
        if not entry then
            visiting[itemId] = nil
            return
        end

        local recipe = entry.recipe
        local outStack = entry.outStack
        local per = outStack.count
        if not per or per <= 0 then
            visiting[itemId] = nil
            return
        end
        local isRoot = itemId == rootItemId
        local have = snap.item(itemId)
        local inFlight = (inflight and inflight[itemId]) or 0

        local still
        if isRoot then
            still = math.max(0, rootStill - inFlight)
        else
            still = math.max(0, wantUnits - have - inFlight)
        end

        need[itemId] = math.max(need[itemId] or 0, wantUnits)
        if still <= 0 then
            deficit[itemId] = 0
            visiting[itemId] = nil
            return
        end
        deficit[itemId] = math.max(deficit[itemId] or 0, still)

        local runsWanted = math.ceil(still / per)

        for i = 1, #recipe.inputs do
            local input = recipe.inputs[i]
            local needAmt = input.count * runsWanted
            if input.fluid then
                local haveF, info = snap.fluid(input.name)
                if not info then
                    hard = {
                        error = "missing_input",
                        missing = {
                            name = input.name,
                            count = needAmt,
                            fluid = true,
                            error = "no_fluid_source",
                        },
                    }
                elseif haveF < input.count then
                    hard = hard or {
                        error = "missing_input",
                        missing = {
                            name = input.name,
                            count = input.count - haveF,
                            fluid = true,
                        },
                    }
                end
            elseif index.byOutput[input.name] then
                -- Concrete item or item-tag with a producing recipe (e.g. cook any meat).
                consider(input.name, needAmt)
            elseif craft_stock.isCraftableName(input.name) then
                local haveI = snap.item(input.name)
                if haveI < input.count then
                    hard = hard or {
                        error = "missing_input",
                        missing = {
                            name = input.name,
                            count = input.count - haveI,
                            fluid = false,
                        },
                    }
                end
            else
                -- Tag with no producer: must already be in storage.
                local haveI = snap.item(input.name)
                if haveI < input.count then
                    hard = hard or {
                        error = "missing_input",
                        missing = {
                            name = input.name,
                            count = input.count - haveI,
                            fluid = false,
                            tag = true,
                        },
                    }
                end
            end
        end

        visiting[itemId] = nil
    end

    consider(rootItemId, rootStill)
    return need, deficit, hard
end

--- Ready jobs sorted depth DESC, batch DESC, itemId ASC.
function craft_plan.readyJobs(index, deficit, snap, resolveMachine, reservedMachines, rootItemId)
    local candidates = {}

    for itemId, still in pairs(deficit) do
        sleep(0) -- yield while scanning candidates
        if not still or still <= 0 then
            -- skip
        else
            local entry = index.byOutput[itemId]
            local recipe = entry and entry.recipe
            local outStack = entry and entry.outStack
            local per = outStack and outStack.count
            if entry and per and per > 0 then
                local ready = craft_stock.countCompleteSets(recipe, snap.store, snap.opts, snap)
                if ready >= 1 then
                    local machine = resolveMachine(recipe)
                    sleep(0)
                    local recipeKey = recipes.recipeKey(recipe)
                    local reserved = reservedMachines and reservedMachines[machine]
                    local okMachine = machine
                        and machine_lock.canStack(machine, recipeKey)
                        and (not reserved or reserved == recipeKey)
                    if okMachine then
                        local runsWanted = math.ceil(still / per)
                        local times = batchTimes(recipe, ready, runsWanted)
                        local have = snap.item(itemId)
                        -- Absolute want for intermediates (deficit already subtracted have once).
                        local wantUnits = still
                        if itemId ~= rootItemId then
                            wantUnits = still + have
                        end
                        candidates[#candidates + 1] = {
                            itemId = itemId,
                            recipe = recipe,
                            outStack = outStack,
                            machine = machine,
                            recipeKey = recipeKey,
                            isRoot = itemId == rootItemId,
                            runsWanted = runsWanted,
                            times = times,
                            depth = index.depth[itemId] or 0,
                            deficit = still,
                            wantUnits = wantUnits,
                        }
                    end
                end
            end
        end
    end

    table.sort(candidates, function(a, b)
        if a.depth ~= b.depth then
            return a.depth > b.depth
        end
        if a.times ~= b.times then
            return a.times > b.times
        end
        return tostring(a.itemId) < tostring(b.itemId)
    end)

    local jobs = {}
    local seenMachine = {}
    for i = 1, #candidates do
        local job = candidates[i]
        if job.machine and not seenMachine[job.machine] then
            if not machine_lock.isBusy(job.machine) or machine_lock.keyOf(job.machine) == job.recipeKey then
                seenMachine[job.machine] = true
                jobs[#jobs + 1] = job
            end
        end
    end

    return jobs
end

return craft_plan
end

-- module: craft_log (craft/craft_log.lua)
package.preload["craft_log"] = function(...)
-- Tiny scrolling log for a side monitor (default: left).
-- Also mirrors to the computer terminal via print.

local craft_log = {}

local state = {
    mon = nil,
    lines = {},
    maxLines = 50,
    w = 10,
    h = 5,
}

local function redraw()
    local mon = state.mon
    if not mon then
        return
    end
    local ok = pcall(function()
        mon.setBackgroundColor(colors.black)
        mon.clear()
        mon.setTextColor(colors.lime)
        local start = math.max(1, #state.lines - state.h + 1)
        local row = 1
        for i = start, #state.lines do
            local line = state.lines[i]
            if #line > state.w then
                line = line:sub(1, state.w)
            end
            mon.setCursorPos(1, row)
            mon.write(line)
            row = row + 1
            if row > state.h then
                break
            end
        end
    end)
    if not ok then
        state.mon = nil
    end
end

--- Bind log monitor. sideOrName e.g. "left" or peripheral name. Optional textScale.
function craft_log.open(sideOrName, textScale)
    sideOrName = sideOrName or "left"
    local mon = peripheral.wrap(sideOrName)
    if not mon or not mon.clear then
        state.mon = nil
        print("craft_log: no monitor on " .. tostring(sideOrName))
        return false
    end
    pcall(function()
        mon.setTextScale(tonumber(textScale) or 0.5)
    end)
    local w, h = mon.getSize()
    state.mon = mon
    state.w = w
    state.h = h
    state.lines = {}
    state.maxLines = math.max(h * 4, 40)
    craft_log.write("log " .. tostring(w) .. "x" .. tostring(h))
    return true
end

function craft_log.write(msg)
    msg = tostring(msg or "")
    msg = msg:gsub("[\r\n]", " ")
    state.lines[#state.lines + 1] = msg
    while #state.lines > state.maxLines do
        table.remove(state.lines, 1)
    end
    -- Terminal always; monitor redraw is best-effort and must not throw.
    print("[craft] " .. msg)
    pcall(redraw)
    sleep(0)
end

function craft_log.step(label)
    craft_log.write(">" .. tostring(label))
end

return craft_log
end

-- module: craft_monitor (craft/craft_monitor.lua)
package.preload["craft_monitor"] = function(...)
-- Continuous craft monitor: top-down demand, bottom-up dispatch.
-- Parallel across different machines (e.g. assemble raw pizza while oven cooks).
-- Workers never touch the log/UI monitors — that was killing CC.

local recipes = require("recipes")
local craft_stock = require("craft_stock")
local craft_plan = require("craft_plan")
local machine_lock = require("machine_lock")
local craft_log = require("craft_log")

local craft_monitor = {}

local IDLE_SLEEP = 0.1
local SKIP_SLEEP = 0.25
local MAX_PARALLEL = 6

local function emitActivity(opts, text)
    if opts and type(opts.onActivity) == "function" then
        pcall(opts.onActivity, text)
    end
end

local function emitProgress(opts, done, total)
    if opts and type(opts.onProgress) == "function" then
        pcall(opts.onProgress, done, total)
    end
end

local function log(msg)
    pcall(craft_log.write, msg)
end

local function shortName(id)
    return (id and id:match("([^/]+)$")) or tostring(id)
end

local function activityText(recipe, itemId, times)
    times = math.max(1, math.floor(tonumber(times) or 1))
    local out = recipes.primaryOutput(recipe)
    local n = (out and out.count or 1) * times
    local name = shortName(itemId)
    if recipe.flag == "grow" then
        return "grow " .. name .. " x" .. tostring(n)
    end
    return name .. " x" .. tostring(n)
end

local function unitsFromDetail(job, detail, fallbackSets)
    local per = job.outStack.count
    if detail and detail.outputs then
        local n = detail.outputs[job.itemId]
        if type(n) == "number" and n > 0 then
            return n
        end
    end
    local sets = 0
    if detail and detail.sets_pushed and detail.sets_pushed > 0 then
        sets = detail.sets_pushed
    elseif detail and detail.times and detail.times > 0 then
        sets = detail.times
    elseif fallbackSets and fallbackSets > 0 then
        sets = fallbackSets
    end
    if sets < 1 then
        return 0
    end
    return per * sets
end

local function planTick(deps, index, store, opts, rootItemId, rootStill, inflight, preloadItems, preloadFluids, machineCache)
    local snap = craft_stock.snapshot(store, opts, preloadItems, preloadFluids)
    local _need, deficit, hard = craft_plan.computeDemand(
        index,
        rootItemId,
        rootStill,
        snap,
        inflight
    )
    local resolve = function(recipe)
        return deps.resolveMachine(recipe, machineCache)
    end
    local jobs = craft_plan.readyJobs(
        index,
        deficit,
        snap,
        resolve,
        nil,
        rootItemId
    )
    return {
        deficit = deficit,
        hard = hard,
        jobs = jobs,
    }
end

--- deps: findByOutput, resolveMachine, run, runGrow
function craft_monitor.request(deps, list, rootItemId, amount, opts, logSteps)
    local store = opts.store
    local rootWant = amount
    local rootCrafted = 0
    local hardSticky = nil
    local inflight = {}
    local machineCache = {}
    local skipStreak = 0
    local planFails = 0

    log("index build")
    local index = craft_plan.buildIndex(list, deps.findByOutput)
    local preloadItems, preloadFluids = craft_plan.collectNames(index, rootItemId)
    log("tree i" .. tostring(#preloadItems) .. " f" .. tostring(#preloadFluids))

    log("cache machines")
    for _, entry in pairs(index.byOutput) do
        deps.resolveMachine(entry.recipe, machineCache)
        sleep(0)
    end
    log("machines ok")

    local function rootDone()
        return rootCrafted >= rootWant
    end

    local function runsStillNeeded(job)
        local per = job.outStack.count
        if per <= 0 then
            return 0
        end
        if job.isRoot then
            return math.ceil(math.max(0, rootWant - rootCrafted) / per)
        end
        local have = craft_stock.countAvailable(store, job.itemId, opts)
        local want = job.wantUnits or job.deficit or 0
        local still = math.max(0, want - have)
        return math.ceil(still / per)
    end

    -- No log/UI inside workers (parallel-safe).
    local function executeJob(job)
        local ok, detail = machine_lock.tryLock(job.machine, job.recipeKey, function()
            if job.recipe.flag == "grow" then
                if not job.isRoot then
                    local have = craft_stock.countAvailable(store, job.itemId, opts)
                    -- wantUnits is absolute need; deficit is already (want-have) and must NOT be compared to have.
                    local want = job.wantUnits or 0
                    if want <= 0 or have >= want then
                        return false, { error = "skipped", skipped = true, reason = "have" }
                    end
                elseif rootCrafted >= rootWant then
                    return false, { error = "skipped", skipped = true, reason = "root_done" }
                end
                return deps.runGrow(job.recipe, job.machine, opts)
            end

            local runsLeft = runsStillNeeded(job)
            local ready = craft_stock.countCompleteSets(job.recipe, store, opts)
            if ready < 1 or runsLeft < 1 then
                return false, {
                    error = "skipped",
                    skipped = true,
                    reason = "ready=" .. tostring(ready) .. " left=" .. tostring(runsLeft),
                }
            end
            local batch = craft_plan.batchTimes(job.recipe, ready, runsLeft)
            job._batch = batch
            return deps.run(job.recipe, {
                from = opts.from,
                out = opts.out,
                store = store,
                machine = job.machine,
                pullFrom = opts.pullFrom,
                waitTicks = opts.waitTicks,
                craftWaitTimeout = opts.craftWaitTimeout,
                times = batch,
                -- Progress only after wave joins (avoid parallel UI draws).
            })
        end)

        if type(detail) == "table" and (detail.error == "busy" or detail.skipped) then
            return true, detail, 0
        end
        if not ok then
            return false, detail, 0
        end
        return true, detail, unitsFromDetail(job, detail, job._batch or job.times)
    end

    emitProgress(opts, 0, rootWant)
    emitActivity(opts, "planning...")
    log("req " .. shortName(rootItemId) .. " x" .. tostring(rootWant))

    while not rootDone() do
        sleep(0)

        local tickOk, tick = pcall(planTick,
            deps, index, store, opts, rootItemId, rootWant - rootCrafted,
            inflight, preloadItems, preloadFluids, machineCache
        )
        if not tickOk then
            planFails = planFails + 1
            local err = tostring(tick)
            log("PLAN FAIL " .. err:sub(1, 48))
            -- Transient TLYW / peripheral blip: retry instead of aborting the whole request.
            if planFails >= 8 then
                return false, {
                    error = "exception",
                    missing = { name = "planning: " .. err, count = 1 },
                }
            end
            sleep(0.2)
        else
            planFails = 0

            if tick.hard then
                hardSticky = tick.hard
            end

            -- One job per free machine, depth-first (cooked oven + raw assembler together).
            local wave = {}
            local claimed = {}
            for i = 1, #tick.jobs do
                if #wave >= MAX_PARALLEL then
                    break
                end
                local cand = tick.jobs[i]
                if cand.machine and not claimed[cand.machine] and not machine_lock.isBusy(cand.machine) then
                    claimed[cand.machine] = true
                    local reserved = cand.times * cand.outStack.count
                    cand.reserved = reserved
                    inflight[cand.itemId] = (inflight[cand.itemId] or 0) + reserved
                    wave[#wave + 1] = cand
                    hardSticky = nil
                end
            end

            if #wave == 0 then
                if hardSticky and not machine_lock.busyAny() then
                    local m = hardSticky.missing and hardSticky.missing.name
                    log("fail " .. shortName(m))
                    return false, hardSticky
                end
                emitActivity(opts, "waiting...")
                if skipStreak == 0 then
                    log("wait")
                end
                sleep(IDLE_SLEEP)
            else
                local names = {}
                for i = 1, #wave do
                    names[i] = shortName(wave[i].itemId)
                end
                log("wave " .. table.concat(names, "+"))
                emitActivity(opts, table.concat(names, " | "))

                local slots = {}
                local fns = {}
                for i = 1, #wave do
                    local job = wave[i]
                    local slot = { job = job, ok = true, detail = nil, gained = 0, err = nil }
                    slots[i] = slot
                    fns[i] = function()
                        local ran, ok, detail, gained = pcall(function()
                            return executeJob(job)
                        end)
                        if not ran then
                            slot.ok = false
                            slot.err = tostring(ok)
                            slot.detail = {
                                error = "exception",
                                missing = { name = tostring(ok), count = 1 },
                            }
                            slot.gained = 0
                        else
                            slot.ok = ok
                            slot.detail = detail
                            slot.gained = gained or 0
                        end
                    end
                end

                local parOk, parErr = pcall(function()
                    if #fns == 1 then
                        fns[1]()
                    else
                        parallel.waitForAll(table.unpack(fns))
                    end
                end)

                -- Always release inflight reservations.
                for i = 1, #wave do
                    local job = wave[i]
                    local reserved = job.reserved or 0
                    inflight[job.itemId] = math.max(0, (inflight[job.itemId] or 0) - reserved)
                end

                if not parOk then
                    log("PAR FAIL " .. tostring(parErr))
                    return false, {
                        error = "exception",
                        missing = { name = tostring(parErr), count = 1 },
                    }
                end

                local firstErr = nil
                local anyProgress = false
                local softFail = false

                for i = 1, #slots do
                    local slot = slots[i]
                    local job = slot.job
                    if slot.err then
                        -- Worker threw (often TLYW): soft-retry, do not kill whole request.
                        softFail = true
                        log("ERR " .. shortName(job.itemId) .. " " .. tostring(slot.err):sub(1, 40))
                    elseif type(slot.detail) == "table" and slot.detail.skipped then
                        log("skip " .. shortName(job.itemId) .. " " .. tostring(slot.detail.reason or ""))
                    elseif not slot.ok then
                        local m = (type(slot.detail) == "table" and slot.detail.missing and slot.detail.missing.name)
                            or (type(slot.detail) == "table" and slot.detail.error)
                            or "fail"
                        local msg = tostring(m)
                        -- Lua exceptions look like "/prog.lua:123: ..."; treat as soft.
                        if msg:find("%.lua:", 1, false) or msg:find("Too long", 1, true) then
                            softFail = true
                            log("ERR " .. shortName(job.itemId) .. " " .. msg:sub(1, 40))
                        else
                            log("fail " .. shortName(job.itemId) .. " " .. msg)
                            firstErr = firstErr or slot.detail
                        end
                    elseif slot.gained and slot.gained > 0 then
                        anyProgress = true
                        log("ok +" .. tostring(slot.gained) .. " " .. shortName(job.itemId))
                        if job.isRoot then
                            rootCrafted = rootCrafted + slot.gained
                            emitProgress(opts, math.min(rootWant, rootCrafted), rootWant)
                        end
                        logSteps[#logSteps + 1] = {
                            item = job.itemId,
                            machine = job.machine,
                            flag = job.recipe.flag,
                            detail = slot.detail,
                            times = (type(slot.detail) == "table" and slot.detail.sets_pushed) or job.times,
                        }
                    else
                        log("noop " .. shortName(job.itemId))
                    end
                end

                if firstErr then
                    return false, firstErr
                end

                if anyProgress then
                    skipStreak = 0
                else
                    skipStreak = skipStreak + 1
                    sleep(softFail and 0.15 or SKIP_SLEEP)
                end

                if skipStreak >= 30 then
                    log("stuck skips")
                    return false, {
                        error = "exception",
                        missing = { name = "stuck: jobs skip without progress", count = 1 },
                    }
                end

                if not rootDone() then
                    emitActivity(opts, "planning...")
                end
            end
        end
    end

    log("done " .. tostring(rootCrafted))
    return true, rootCrafted
end

return craft_monitor
end

-- module: storage (craft/storage.lua)
package.preload["storage"] = function(...)
-- Parse storage.cfg into named inventories, sources, seeds, routes, settings.

local util = require("util")

local storage = {}

local function emptyConfig()
    return {
        named = {},
        sources = {},
        fluids = {}, -- key -> { peripheral, fluid }
        seeds = {},
        routes = {},
        settings = {},
    }
end

local NAMED_KEYS = {
    main = true,
    flora = true,
    overflow = true,
    seed_chest_prefix = true,
    output_bus_prefix = true,
}

local function parseLine(cfg, line, lineNo)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return
    end

    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end

    local key = parts[1]
    if not key or key == "" then
        error(("storage.cfg line %s: empty key"):format(tostring(lineNo)))
    end

    if key == "source" then
        if #parts < 3 then
            error(("storage.cfg line %s: source | item | peripheral"):format(tostring(lineNo)))
        end
        cfg.sources[parts[2]] = parts[3]
        return
    end

    if key == "fluid_source" then
        if #parts < 4 then
            error(("storage.cfg line %s: fluid_source | tagOrFluid | tank | concreteFluid"):format(tostring(lineNo)))
        end
        cfg.fluids[parts[2]] = {
            peripheral = parts[3],
            fluid = parts[4],
        }
        return
    end

    if key == "seed" then
        if #parts < 3 then
            error(("storage.cfg line %s: seed | crop | seedItem"):format(tostring(lineNo)))
        end
        cfg.seeds[parts[2]] = parts[3]
        return
    end

    if key == "route" then
        if #parts < 3 then
            error(("storage.cfg line %s: route | item | dest"):format(tostring(lineNo)))
        end
        cfg.routes[parts[2]] = parts[3]
        return
    end

    if NAMED_KEYS[key] then
        if #parts < 2 then
            error(("storage.cfg line %s: %s | value"):format(tostring(lineNo), key))
        end
        cfg.named[key] = parts[2]
        return
    end

    if #parts >= 2 then
        cfg.settings[key] = parts[2]
        return
    end

    error(("storage.cfg line %s: bad directive %q"):format(tostring(lineNo), key))
end

local function resolveAlias(cfg, dest)
    if not dest then
        return nil
    end
    if dest == "main" or dest == "flora" or dest == "overflow" then
        return cfg.named[dest]
    end
    return dest
end

--- Load storage settings. Prefers <program>.cfg [storage], else storage.cfg.
function storage.load(path)
    local lines = util.openConfigLines(path, "storage", "storage.cfg")
    local cfg = emptyConfig()
    for n = 1, #lines do
        parseLine(cfg, lines[n], n)
    end

    function cfg.main()
        return cfg.named.main
    end

    function cfg.flora()
        return cfg.named.flora
    end

    function cfg.overflow()
        return cfg.named.overflow
    end

    function cfg.seedChestPrefix()
        return cfg.named.seed_chest_prefix or "gtceu:lv_super_chest_"
    end

    function cfg.outputBusPrefix()
        return cfg.named.output_bus_prefix or "gtceu:mv_output_bus_"
    end

    function cfg.sourceOf(itemId)
        return cfg.sources[itemId] or cfg.named.main
    end

    --- @return { peripheral, fluid } | nil
    function cfg.fluidSourceOf(fluidOrTag)
        return cfg.fluids[fluidOrTag]
    end

    function cfg.destFor(itemId)
        local route = cfg.routes[itemId]
        if route then
            return resolveAlias(cfg, route) or cfg.named.main
        end
        return cfg.named.main
    end

    --- Ordered unique inventories used for both counting and pulling an item.
    -- Order: explicit source → dest/route → main.
    -- Overflow crate is included ONLY when it is that item's home (route/source),
    -- never as a dump for fridge food (pizza etc. rot at room temp).
    function cfg.pullSources(itemId, extra)
        local seen = {}
        local list = {}
        local function add(inv)
            if inv and not seen[inv] and peripheral.isPresent(inv) then
                seen[inv] = true
                list[#list + 1] = inv
            end
        end

        add(cfg.sources[itemId]) -- explicit source only (not default main yet)
        add(cfg.destFor(itemId))
        add(cfg.named.main)
        local overflow = cfg.named.overflow
        if overflow and (cfg.sources[itemId] == overflow or cfg.destFor(itemId) == overflow) then
            add(overflow)
        end
        if extra then
            if type(extra) == "string" then
                add(extra)
            elseif type(extra) == "table" then
                for i = 1, #extra do
                    add(extra[i])
                end
            end
        end
        -- Fallback: if nothing present, still return default source name for errors.
        if #list == 0 then
            local fallback = cfg.sourceOf(itemId)
            if fallback then
                list[1] = fallback
            end
        end
        return list
    end

    function cfg.seedDest(index)
        index = tonumber(index) or 0
        return cfg.seedChestPrefix() .. tostring(index)
    end

    function cfg.outputBus(index)
        index = tonumber(index) or 0
        return cfg.outputBusPrefix() .. tostring(index)
    end

    function cfg.seedForCrop(cropId)
        return cfg.seeds[cropId]
    end

    function cfg.get(key, default)
        local v = cfg.settings[key]
        if v == nil then
            return default
        end
        return v
    end

    function cfg.getNumber(key, default)
        local v = tonumber(cfg.settings[key])
        if v == nil then
            return default
        end
        return v
    end

    return cfg
end

return storage
end

-- module: craft (craft/craft.lua)
package.preload["craft"] = function(...)
-- Public craft API: load/find recipes, run processing, request with realtime monitor.
-- Internals: craft_plan, craft_monitor, craft_stock, craft_io, craft_grow, machine_lock.

require("food") -- tag/spoil registration for transfer
local recipes = require("recipes")
local peripherals = require("peripherals")
local craft_io = require("craft_io")
local craft_grow = require("craft_grow")
local craft_monitor = require("craft_monitor")
local machine_lock = require("machine_lock")
local craft_err = require("craft_err")

local craft = {}

local DEFAULT_CRAFT_WAIT = 300

craft.resolveMachine = peripherals.resolveMachine
craft.withMachineLock = machine_lock.withLock
craft.tryMachineLock = machine_lock.tryLock

---------------------------------------------------------------------------
-- Recipe helpers
---------------------------------------------------------------------------

--- Load processing/craft recipes. path nil → <program>.cfg [recipes] / recipes.cfg
function craft.load(path)
    local all = recipes.load(path)
    return recipes.filter(all, function(r)
        return r.flag == "processing" or r.flag == "craft"
    end)
end

--- Like craft.load, plus grow recipes. path nil → sectioned program cfg.
function craft.loadRequest(path)
    local all = recipes.load(path)
    return recipes.filter(all, function(r)
        return r.flag == "processing" or r.flag == "craft" or r.flag == "grow"
    end)
end

function craft.findAll(list, machine)
    return recipes.byMachine(list, machine)
end

function craft.find(list, machine, wantOutput)
    local matches = recipes.byMachine(list, machine)
    if #matches == 0 then
        return nil
    end
    if not wantOutput then
        return matches[1]
    end
    for i = 1, #matches do
        local outs = matches[i].outputs
        for j = 1, #outs do
            if outs[j].name == wantOutput then
                return matches[i]
            end
        end
    end
    return nil
end

function craft.findByOutput(list, itemId)
    for i = 1, #list do
        local outs = list[i].outputs
        for j = 1, #outs do
            if not outs[j].fluid and outs[j].name == itemId then
                return list[i], outs[j]
            end
        end
    end
    return nil, nil
end

function craft.catalog(list)
    local seen = {}
    local catalog = {}
    for i = 1, #list do
        local recipe = list[i]
        for j = 1, #recipe.outputs do
            local out = recipe.outputs[j]
            if not out.fluid and not seen[out.name] then
                seen[out.name] = true
                local label = out.name:match("([^/]+)$") or out.name
                catalog[#catalog + 1] = {
                    id = out.name,
                    label = label,
                    recipe = recipe,
                    perCraft = out.count,
                }
            end
        end
    end
    table.sort(catalog, function(a, b) return a.label < b.label end)
    return catalog
end

---------------------------------------------------------------------------
-- Processing run / once
---------------------------------------------------------------------------

function craft.run(recipe, opts)
    return craft_io.run(recipe, opts)
end

function craft.once(machine, opts)
    local list = craft.load(opts and opts.cfg)
    local recipe = craft.find(list, machine, opts and opts.wantOutput)
    if not recipe then
        return craft_err.fail("no_recipe", {
            missing = { name = tostring(machine), count = 1 },
            message = "no recipe for " .. tostring(machine),
        })
    end
    return craft.run(recipe, opts)
end

---------------------------------------------------------------------------
-- request: monitor until crafted counter hits amount
---------------------------------------------------------------------------

--- Craft/grow until `amount` of the target has been produced (craft counter).
-- opts.onActivity(text), opts.onProgress(done, total) for UI.
function craft.request(itemId, amount, opts)
    opts = opts or {}
    amount = math.max(1, math.floor(tonumber(amount) or 1))

    local store = opts.store
    if not store and opts.from and opts.out then
        -- legacy single-inventory mode
    elseif not store then
        local storageMod = require("storage")
        store = storageMod.load(opts.storageCfg)
        opts.store = store
    end

    if store then
        opts.from = opts.from or store.main()
        opts.out = opts.out or store.main()
        opts.growPulse = opts.growPulse or store.getNumber("grow_pulse", craft_grow.DEFAULT_GROW_PULSE)
        opts.growWaitTimeout = opts.growWaitTimeout or store.getNumber("grow_wait_timeout", craft_grow.DEFAULT_GROW_WAIT)
        opts.craftWaitTimeout = opts.craftWaitTimeout or store.getNumber("craft_wait_timeout", DEFAULT_CRAFT_WAIT)
        opts.waitTicks = opts.waitTicks or store.getNumber("wait_ticks", nil)
    end

    assert(opts.from and opts.out, "opts.from and opts.out (or opts.store) required")

    local list = craft.loadRequest(opts.cfg)
    local foundRecipe, foundOut = craft.findByOutput(list, itemId)
    if not foundRecipe then
        return false, {
            error = {
                error = "missing_input",
                missing = { name = itemId, count = amount },
            },
            produced = 0,
            steps = {},
        }
    end

    local log = {}
    local ok, result = craft_monitor.request({
        findByOutput = craft.findByOutput,
        resolveMachine = craft.resolveMachine,
        run = craft.run,
        runGrow = craft_grow.run,
    }, list, itemId, amount, opts, log)

    if not ok then
        local produced = 0
        local per = foundOut and foundOut.count or 1
        for i = 1, #log do
            if log[i].item == itemId then
                local d = log[i].detail
                if d and d.sets_pushed then
                    produced = produced + d.sets_pushed * per
                else
                    produced = produced + per
                end
            end
        end
        return false, {
            error = result,
            produced = produced,
            steps = log,
        }
    end

    return true, {
        item = itemId,
        produced = result,
        steps = log,
    }
end

return craft
end

-- entry: craft/craft_ui.lua
-- Craft UI: pick output item + amount on a monitor.
-- Inventory / monitor settings come from craft_ui.cfg [storage] (no hard-coded fridge).
--
-- Modular: run from craft/ with shared/ on the computer (or repo root layout).
-- Bundle:  python tools/bundle_project.py craft craft_ui
-- Deploy:  dist/craft_ui.lua + craft_ui.cfg

local craft = require("craft")
local storage = require("storage")
local util = require("util")
local craft_log = require("craft_log")

local store = storage.load()

local CONFIG = {
    monitor = store.get("monitor", "right"),
    logMonitor = store.get("log_monitor", "left"),
    textScale = store.getNumber("text_scale", 0.5),
    logTextScale = store.getNumber("log_text_scale", 0.5),
    craftWaitTimeout = store.getNumber("craft_wait_timeout", 300),
    growPulse = store.getNumber("grow_pulse", 3),
    growWaitTimeout = store.getNumber("grow_wait_timeout", 600),
    maxAmount = store.getNumber("max_amount", 100),
}

craft_log.open(CONFIG.logMonitor, CONFIG.logTextScale)

local mon = assert(peripheral.wrap(CONFIG.monitor), "No monitor on " .. CONFIG.monitor)
mon.setTextScale(CONFIG.textScale)

local W, H = mon.getSize()

local state = {
    catalog = {},
    selected = 1,
    scroll = 0,
    amount = 1,
    storageLabel = "",
    status = "Ready",
    statusKind = "info", -- info | ok | error | busy
    activity = "",
    progressDone = 0,
    progressTotal = 0,
    busy = false,
}

local buttons = {}

local function fill(x, y, w, h, color)
    mon.setBackgroundColor(color)
    for row = y, y + h - 1 do
        mon.setCursorPos(x, row)
        mon.write((" "):rep(w))
    end
end

local function writeAt(x, y, text, fg, bg)
    mon.setCursorPos(x, y)
    if bg then mon.setBackgroundColor(bg) end
    if fg then mon.setTextColor(fg) end
    mon.write(text)
end

local function addButton(id, x, y, w, h, label, fg, bg)
    buttons[#buttons + 1] = {
        id = id,
        x = x,
        y = y,
        w = w,
        h = h,
        label = label,
        fg = fg or colors.white,
        bg = bg or colors.gray,
    }
end

local function hitButton(x, y)
    for i = 1, #buttons do
        local b = buttons[i]
        if x >= b.x and x < b.x + b.w and y >= b.y and y < b.y + b.h then
            return b
        end
    end
    return nil
end

local function statusLines()
    if state.statusKind == "error" then
        return 2
    end
    if state.statusKind == "busy" then
        return 2
    end
    return 1
end

local function listWindow()
    local listTop = 3 + statusLines()
    local listBottom = H - 2
    local listH = math.max(1, listBottom - listTop + 1)
    return listTop, listH
end

local function setStatus(text, kind)
    state.status = tostring(text or "")
    state.statusKind = kind or "info"
    if kind ~= "busy" then
        state.activity = ""
        state.progressDone = 0
        state.progressTotal = 0
    end
end

local function formatError(detail)
    local function prettyName(name)
        if not name then
            return "?"
        end
        name = name:gsub("^#", "")
        return util.short(name)
    end

    local function fromMissing(missing)
        if not missing or not missing.name then
            return nil
        end
        local name = prettyName(missing.name)
        if missing.fluid then
            if missing.error == "no_fluid_source" then
                return "NO TANK " .. name
            end
            local count = missing.count
            if count and count > 0 then
                return "NEED " .. name .. " " .. tostring(count) .. "mb"
            end
            return "NEED " .. name
        end
        local count = missing.count
        if count and count > 1 then
            return "NEED " .. name .. " x" .. tostring(count)
        end
        return "NEED " .. name
    end

    if type(detail) ~= "table" then
        return tostring(detail)
    end

    local err = detail.error or detail
    for _ = 1, 4 do
        if type(err) ~= "table" then
            break
        end
        if err.error == "no_machine" then
            return "NO MACHINE " .. prettyName(err.missing and err.missing.name or err.item or "?")
        end
        if err.error == "grow_failed" then
            return "GROW FAIL " .. prettyName(err.missing and err.missing.name or "?")
        end
        if err.error == "grow_timeout" then
            return "GROW WAIT " .. prettyName(err.missing and err.missing.name or "?")
        end
        if err.error == "craft_no_output" then
            return "NO OUT " .. prettyName(err.missing and err.missing.name or "?")
        end
        if err.error == "craft_timeout" then
            return "WAIT " .. prettyName(err.missing and err.missing.name or "?")
        end
        if err.error == "craft_short" then
            return "SHORT " .. prettyName(err.missing and err.missing.name or "?")
        end
        if err.error == "cycle" then
            return "CYCLE " .. prettyName(err.missing and err.missing.name or "?")
        end
        if err.error == "exception" then
            return "ERR " .. prettyName(err.missing and err.missing.name or "?")
        end
        if type(err.missing_all) == "table" then
            for i = 1, #err.missing_all do
                if err.missing_all[i].fluid then
                    local msg = fromMissing(err.missing_all[i])
                    if msg then
                        return msg
                    end
                end
            end
            if err.missing_all[1] then
                local msg = fromMissing(err.missing_all[1])
                if msg then
                    local extra = #err.missing_all - 1
                    if extra > 0 then
                        return msg .. " +" .. tostring(extra)
                    end
                    return msg
                end
            end
        end
        local msg = fromMissing(err.missing)
        if msg then
            return msg
        end
        if type(err.error) == "string" and not err.missing then
            return err.error
        end
        err = err.error
    end

    return "CRAFT FAIL"
end

local function ensureVisible()
    local _, listH = listWindow()
    if state.selected < state.scroll + 1 then
        state.scroll = state.selected - 1
    elseif state.selected > state.scroll + listH then
        state.scroll = state.selected - listH
    end
    state.scroll = util.clamp(state.scroll, 0, math.max(0, #state.catalog - listH))
end

local function drawBusyStatus(statusY, fg, bg)
    -- Line 1: left label + right-aligned progress N/M
    local left = state.status or ""
    local prog = ""
    if state.progressTotal and state.progressTotal > 0 then
        prog = tostring(state.progressDone or 0) .. "/" .. tostring(state.progressTotal)
    end
    fill(1, statusY, W, 1, bg)
    local leftMax = W - #prog
    if leftMax < 1 then
        leftMax = W
        prog = ""
    end
    if #left > leftMax then
        left = left:sub(1, leftMax)
    end
    writeAt(1, statusY, left, fg, bg)
    if #prog > 0 then
        writeAt(W - #prog + 1, statusY, prog, fg, bg)
    end

    -- Line 2: live activity
    local act = state.activity or ""
    fill(1, statusY + 1, W, 1, bg)
    if #act > W then
        act = act:sub(1, W)
    end
    writeAt(1, statusY + 1, act, fg, bg)
end

local function draw()
    buttons = {}
    mon.setBackgroundColor(colors.black)
    mon.clear()

    writeAt(1, 1, "CRAFT", colors.yellow, colors.black)
    local amtText = "x" .. tostring(state.amount)
    writeAt(W - #amtText + 1, 1, amtText, colors.white, colors.black)

    local storeLine = state.storageLabel
    if #storeLine > W then
        storeLine = storeLine:sub(1, W)
    end
    fill(1, 2, W, 1, colors.gray)
    writeAt(1, 2, storeLine, colors.white, colors.gray)

    local lines = statusLines()
    local status = state.status or ""
    local fg, bg = colors.lightGray, colors.black
    if state.statusKind == "error" then
        fg, bg = colors.white, colors.red
    elseif state.statusKind == "ok" then
        fg, bg = colors.black, colors.lime
    elseif state.statusKind == "busy" then
        fg, bg = colors.black, colors.yellow
    end

    local statusY = 3
    if state.statusKind == "busy" then
        drawBusyStatus(statusY, fg, bg)
    else
        fill(1, statusY, W, lines, bg)
        if lines == 1 then
            if #status > W then
                status = status:sub(1, W)
            end
            writeAt(1, statusY, status, fg, bg)
        else
            local line1, line2 = status, ""
            if #status > W then
                line1 = status:sub(1, W)
                line2 = status:sub(W + 1)
                if #line2 > W then
                    line2 = line2:sub(1, W)
                end
            end
            writeAt(1, statusY, line1, fg, bg)
            writeAt(1, statusY + 1, line2, fg, bg)
        end
    end

    local listTop, listH = listWindow()
    ensureVisible()

    for row = 0, listH - 1 do
        local idx = state.scroll + row + 1
        local y = listTop + row
        local entry = state.catalog[idx]
        if entry then
            local selected = idx == state.selected
            local rowBg = selected and colors.blue or colors.black
            local rowFg = selected and colors.white or colors.lightGray
            fill(1, y, W, 1, rowBg)
            local mark = selected and ">" or " "
            local label = mark .. util.short(entry.id)
            if #label > W then
                label = label:sub(1, W)
            end
            writeAt(1, y, label, rowFg, rowBg)
            addButton("pick:" .. idx, 1, y, W, 1, label, rowFg, rowBg)
        else
            fill(1, y, W, 1, colors.black)
        end
    end

    local y = H - 1
    local nBtn = 5
    local baseW = math.max(2, math.floor(W / nBtn))
    local specs = {
        { id = "minus10", label = "-10", bg = colors.red, fg = colors.white },
        { id = "minus", label = "-1", bg = colors.red, fg = colors.white },
        { id = "craft", label = state.busy and ".." or "GO", bg = colors.orange, fg = colors.black },
        { id = "plus", label = "+1", bg = colors.green, fg = colors.white },
        { id = "plus10", label = "+10", bg = colors.green, fg = colors.white },
    }
    for i = 1, #specs do
        local s = specs[i]
        local x = 1 + (i - 1) * baseW
        local w = (i == #specs) and (W - x + 1) or baseW
        fill(x, y, w, 2, s.bg)
        local label = s.label
        if #label > w then
            label = label:sub(1, w)
        end
        writeAt(x + math.floor((w - #label) / 2), y, label, s.fg, s.bg)
        addButton(s.id, x, y, w, 2, label, s.fg, s.bg)
    end
end

local function doCraft()
    if state.busy then
        return
    end
    local entry = state.catalog[state.selected]
    if not entry then
        setStatus("Nothing selected", "error")
        draw()
        return
    end

    local mainInv = store.main()
    if not mainInv or not peripheral.isPresent(mainInv) then
        setStatus("main missing in storage.cfg", "error")
        draw()
        return
    end

    state.busy = true
    state.progressDone = 0
    state.progressTotal = state.amount
    state.activity = "planning..."
    setStatus("Crafting " .. util.short(entry.id), "busy")
    draw()

    local ok, detail
    local ran, err = pcall(function()
        ok, detail = craft.request(entry.id, state.amount, {
            store = store,
            craftWaitTimeout = CONFIG.craftWaitTimeout,
            growPulse = CONFIG.growPulse,
            growWaitTimeout = CONFIG.growWaitTimeout,
            onActivity = function(text)
                state.activity = tostring(text or "")
                draw()
            end,
            onProgress = function(done, total)
                state.progressDone = tonumber(done) or 0
                state.progressTotal = tonumber(total) or state.amount
                draw()
            end,
        })
    end)

    state.busy = false
    state.activity = ""
    if not ran then
        print("craft error: " .. tostring(err))
        pcall(craft_log.write, "DIE " .. tostring(err))
        setStatus("ERR " .. tostring(err):sub(1, math.max(1, W - 4)), "error")
    elseif ok then
        setStatus("OK +" .. tostring(detail.produced), "ok")
    else
        local msg = formatError(detail)
        print("craft fail: " .. tostring(msg))
        pcall(craft_log.write, "FAIL " .. tostring(msg))
        setStatus(msg, "error")
    end
    draw()
end

local function onTouch(x, y)
    if state.busy then
        return
    end

    local btn = hitButton(x, y)
    if not btn then
        return
    end

    if btn.id:sub(1, 5) == "pick:" then
        state.selected = tonumber(btn.id:sub(6))
        draw()
        return
    end

    if btn.id == "minus10" then
        state.amount = util.clamp(state.amount - 10, 1, CONFIG.maxAmount)
        draw()
        return
    end

    if btn.id == "minus" then
        state.amount = util.clamp(state.amount - 1, 1, CONFIG.maxAmount)
        draw()
        return
    end

    if btn.id == "plus" then
        state.amount = util.clamp(state.amount + 1, 1, CONFIG.maxAmount)
        draw()
        return
    end

    if btn.id == "plus10" then
        state.amount = util.clamp(state.amount + 10, 1, CONFIG.maxAmount)
        draw()
        return
    end

    if btn.id == "craft" then
        doCraft()
    end
end

local function main()
    state.catalog = craft.catalog(craft.load())
    if #state.catalog == 0 then
        mon.setBackgroundColor(colors.black)
        mon.clear()
        writeAt(1, 1, "No recipes", colors.red, colors.black)
        return
    end

    local mainInv = store.main()
    if mainInv and peripheral.isPresent(mainInv) then
        state.storageLabel = "Store: " .. util.short(mainInv)
        setStatus("Ready", "info")
    else
        state.storageLabel = "Store: NONE"
        setStatus("main missing in storage.cfg", "error")
    end

    draw()

    while true do
        local ev, a, b, c = os.pullEvent()
        if ev == "monitor_touch" and a == CONFIG.monitor then
            onTouch(b, c)
        elseif ev == "monitor_resize" and a == CONFIG.monitor then
            W, H = mon.getSize()
            draw()
        elseif ev == "key" and a == keys.q then
            break
        end
    end
end

main()
