-- Bundled from ae2_feed/main.lua — do not edit by hand; rebuild with tools/bundle_project.py
-- Also copy ae2_feed.cfg next to this file on the computer.
-- Generated package.preload modules + entrypoint.

-- module: util (shared/util.lua)
package.preload["util"] = function(...)
-- Shared string / path helpers for CC:Tweaked scripts.

local util = {}

function util.trim(s)
    return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

function util.split(s, sep)
    local out = {}
    s = tostring(s or "")
    for part in (s .. sep):gmatch("(.-)" .. sep) do
        out[#out + 1] = part
    end
    return out
end

--- Resolve a config path relative to the running program directory.
function util.resolvePath(path, defaultName)
    path = path or defaultName
    if not path then
        error("resolvePath: path required", 2)
    end
    if path:sub(1, 1) == "/" then
        return path
    end
    local base = ""
    if shell and shell.getRunningProgram then
        local prog = shell.getRunningProgram()
        if prog then
            base = fs.getDir(prog)
        end
    end
    return fs.combine(base, path)
end

--- Read entire file as string, or nil if missing.
function util.readAll(path)
    if not path or not fs.exists(path) then
        return nil
    end
    local file = fs.open(path, "r")
    if not file then
        return nil
    end
    local text = file.readAll()
    file.close()
    return text
end

--- Basename of the running program without .lua (e.g. pizza_maintain).
function util.programStem()
    if not (shell and shell.getRunningProgram) then
        return nil
    end
    local prog = shell.getRunningProgram()
    if not prog then
        return nil
    end
    local name = fs.getName(prog)
    return (name:gsub("%.lua$", ""))
end

--- Lines of `[section]` from a sectioned cfg. Nil if file/section missing.
function util.cfgSectionLines(path, section)
    local text = util.readAll(path)
    if not text or not section then
        return nil
    end
    local current = nil
    local buf = {}
    local found = false
    for line in (text .. "\n"):gmatch("(.-)\n") do
        local sec = line:match("^%s*%[([%w_]+)%]%s*$")
        if sec then
            if found then
                break
            end
            if sec == section then
                found = true
                current = sec
                buf = {}
            else
                current = nil
            end
        elseif found and current == section then
            buf[#buf + 1] = line
        end
    end
    if not found then
        return nil
    end
    return buf
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Try sectioned cfg at path; return lines, label or nil.
local function trySectioned(path, section)
    if not path or not fs.exists(path) then
        return nil
    end
    local sectionLines = util.cfgSectionLines(path, section)
    if not sectionLines then
        return nil
    end
    return sectionLines, path .. "[" .. section .. "]"
end

--- Config lines for a logical section.
-- Order: explicit path → <program>.cfg [section] → craft.cfg [section] → fallbackName.
-- Returns lines, label (for errors).
function util.openConfigLines(explicitPath, section, fallbackName)
    if explicitPath then
        local path = util.resolvePath(explicitPath)
        local text = util.readAll(path)
        if not text then
            error("Cannot open " .. path, 2)
        end
        return linesFromText(text), path
    end

    local stem = util.programStem()
    if stem then
        local lines, label = trySectioned(util.resolvePath(nil, stem .. ".cfg"), section)
        if lines then
            return lines, label
        end
    end

    local lines, label = trySectioned(util.resolvePath(nil, "craft.cfg"), section)
    if lines then
        return lines, label
    end

    local path = util.resolvePath(nil, fallbackName)
    local text = util.readAll(path)
    if not text then
        local hint = stem and (stem .. ".cfg") or "program.cfg"
        error(
            "Cannot open " .. path
                .. " (deploy "
                .. hint
                .. " next to the program, or "
                .. tostring(fallbackName)
                .. ")",
            2
        )
    end
    return linesFromText(text), path
end

--- Short display name: last path segment after `/`.
function util.short(id)
    id = tostring(id or "")
    return id:match("([^/]+)$") or id
end

function util.clamp(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

return util
end

-- module: cfg_pipe (shared/cfg_pipe.lua)
package.preload["cfg_pipe"] = function(...)
-- Shared pipe-delimited cfg helpers (key | value [| ...]).

local util = require("util")

local cfg_pipe = {}

cfg_pipe.trim = util.trim
cfg_pipe.split = util.split
cfg_pipe.resolvePath = util.resolvePath

function cfg_pipe.parseScale(raw)
    raw = util.trim(tostring(raw or "")):lower()
    if raw == "" or raw == "auto" then
        return "auto"
    end
    local n = tonumber(raw)
    if not n then
        return "auto"
    end
    n = math.floor(n * 2 + 0.5) / 2
    return util.clamp(n, 0.5, 5)
end

--- Split a cfg line into key, value, parts (or nil, errHint).
function cfg_pipe.splitLine(line)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return nil
    end
    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end
    local key = (parts[1] or ""):lower()
    if key == "" then
        return nil, "empty key"
    end
    if parts[2] == nil or parts[2] == "" then
        return nil, key .. " | value"
    end
    return key, parts[2], parts
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Load all lines from a cfg file.
-- @return lines, path, ok
function cfg_pipe.loadLines(path, defaultName)
    path = util.resolvePath(path, defaultName)
    if not fs.exists(path) then
        return nil, path, false
    end
    local text = util.readAll(path)
    if not text then
        error("Cannot open " .. path, 2)
    end
    return linesFromText(text), path, true
end

return cfg_pipe
end

-- module: config (ae2_feed/config.lua)
package.preload["config"] = function(...)
-- Load ae2_feed.cfg into the table discover/main expect.
-- `config` is project-local (ae2_feed/); deploy one bundle per computer.

local util = require("util")
local cfg_pipe = require("cfg_pipe")

local config = {}

local function empty()
    return {
        N = 0,
        STORAGES = nil,
        MACHINES = nil,
        STORAGE_SUBSTR = nil,
        MACHINE_SUBSTR = nil,
    }
end

local function appendList(cfg, key, value)
    if not cfg[key] then
        cfg[key] = {}
    end
    cfg[key][#cfg[key] + 1] = value
end

local function parseLine(cfg, line, lineNo)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return
    end

    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end

    local key = parts[1] and parts[1]:lower() or ""
    if key == "" then
        error(("ae2_feed.cfg line %s: empty key"):format(tostring(lineNo)))
    end

    if key == "n" then
        if #parts < 2 then
            error(("ae2_feed.cfg line %s: N | amount"):format(tostring(lineNo)))
        end
        cfg.N = tonumber(parts[2]) or 0
        return
    end

    if key == "storage" or key == "storages" then
        if #parts < 2 then
            error(("ae2_feed.cfg line %s: storage | peripheral"):format(tostring(lineNo)))
        end
        appendList(cfg, "STORAGES", parts[2])
        return
    end

    if key == "machine" or key == "machines" then
        if #parts < 2 then
            error(("ae2_feed.cfg line %s: machine | peripheral"):format(tostring(lineNo)))
        end
        appendList(cfg, "MACHINES", parts[2])
        return
    end

    if key == "storage_substr" then
        if #parts < 2 then
            error(("ae2_feed.cfg line %s: storage_substr | needle"):format(tostring(lineNo)))
        end
        appendList(cfg, "STORAGE_SUBSTR", parts[2])
        return
    end

    if key == "machine_substr" then
        if #parts < 2 then
            error(("ae2_feed.cfg line %s: machine_substr | needle"):format(tostring(lineNo)))
        end
        appendList(cfg, "MACHINE_SUBSTR", parts[2])
        return
    end

    error(("ae2_feed.cfg line %s: unknown key %q"):format(tostring(lineNo), key))
end

--- Load ae2_feed.cfg (next to the running program by default).
function config.load(path)
    local lines, resolved, ok = cfg_pipe.loadLines(path, "ae2_feed.cfg")
    if not ok then
        error("Cannot open " .. tostring(resolved), 2)
    end

    local cfg = empty()
    for n = 1, #lines do
        parseLine(cfg, lines[n], n)
    end

    -- Single needle → string (discover accepts string or list).
    if cfg.STORAGE_SUBSTR and #cfg.STORAGE_SUBSTR == 1 then
        cfg.STORAGE_SUBSTR = cfg.STORAGE_SUBSTR[1]
    end
    if cfg.MACHINE_SUBSTR and #cfg.MACHINE_SUBSTR == 1 then
        cfg.MACHINE_SUBSTR = cfg.MACHINE_SUBSTR[1]
    end

    return cfg
end

return config
end

-- module: discover (ae2_feed/discover.lua)
package.preload["discover"] = function(...)
-- Classify wired-network inventories into storages vs machines.

local discover = {}

local SKIP_TYPES = {
    modem = true,
    wired_modem = true,
    wireless_modem = true,
    monitor = true,
    computer = true,
    turtle = true,
    speaker = true,
    drive = true,
    printer = true,
    command = true,
    redstone = true,
}

local LOCAL_SIDES = {
    left = true,
    right = true,
    top = true,
    bottom = true,
    front = true,
    back = true,
}

local DEFAULT_STORAGE_NEEDLES = {
    "crate",
    "barrel",
    "chest",
    "drawer",
    "shulker",
    "drum",
    "toolbox",
    "locker",
    "cabinet",
}

local function peripheralTypes(name)
    local ok, ptype = pcall(peripheral.getType, name)
    if not ok or not ptype then
        return {}
    end
    if type(ptype) == "table" then
        return ptype
    end
    return { ptype }
end

local function shouldSkip(name, types)
    local lowerName = tostring(name):lower()
    if LOCAL_SIDES[lowerName] then
        return true
    end
    for i = 1, #types do
        local t = tostring(types[i]):lower()
        if SKIP_TYPES[t] then
            return true
        end
    end
    if lowerName:find("modem", 1, true) or lowerName:find("monitor", 1, true) then
        return true
    end
    return false
end

local function isInventory(name)
    if not peripheral.isPresent(name) then
        return false
    end
    local inv = peripheral.wrap(name)
    return inv and type(inv.list) == "function" and type(inv.pushItems) == "function"
end

local function matchesNeedle(name, types, needle)
    if not needle or needle == "" then
        return false
    end
    local n = tostring(needle):lower()
    if tostring(name):lower():find(n, 1, true) then
        return true
    end
    for i = 1, #types do
        if tostring(types[i]):lower():find(n, 1, true) then
            return true
        end
    end
    return false
end

local function matchesAny(name, types, needles)
    if not needles then
        return false
    end
    if type(needles) == "string" then
        return matchesNeedle(name, types, needles)
    end
    for i = 1, #needles do
        if matchesNeedle(name, types, needles[i]) then
            return true
        end
    end
    return false
end

local function sortNames(list)
    table.sort(list)
    return list
end

local function explicitList(cfgValue)
    if type(cfgValue) ~= "table" or #cfgValue == 0 then
        return nil
    end
    return cfgValue
end

local function resolveExplicit(names, label)
    local out = {}
    for i = 1, #names do
        local name = names[i]
        if peripheral.isPresent(name) and isInventory(name) then
            out[#out + 1] = name
        else
            print(("ae2_feed: missing %s %s"):format(label, tostring(name)))
        end
    end
    return sortNames(out)
end

local function nameSet(list)
    local set = {}
    for i = 1, #list do
        set[list[i]] = true
    end
    return set
end

--- Returns { machines = {...}, storages = {...} }.
function discover.scan(cfg)
    cfg = cfg or {}

    local explicitStorages = explicitList(cfg.STORAGES)
    local explicitMachines = explicitList(cfg.MACHINES)

    local storageNeedles = cfg.STORAGE_SUBSTR
    if storageNeedles == nil then
        storageNeedles = DEFAULT_STORAGE_NEEDLES
    end
    local machineNeedles = cfg.MACHINE_SUBSTR

    local storages = explicitStorages and resolveExplicit(explicitStorages, "storage") or {}
    local machines = explicitMachines and resolveExplicit(explicitMachines, "machine") or {}

    local taken = nameSet(storages)
    for i = 1, #machines do
        taken[machines[i]] = true
    end

    local names = peripheral.getNames()
    for i = 1, #names do
        local name = names[i]
        if not taken[name] then
            local types = peripheralTypes(name)
            if not shouldSkip(name, types) and isInventory(name) then
                if not explicitStorages and matchesAny(name, types, storageNeedles) then
                    storages[#storages + 1] = name
                    taken[name] = true
                elseif not explicitMachines then
                    if machineNeedles == nil or machineNeedles == "" or matchesAny(name, types, machineNeedles) then
                        machines[#machines + 1] = name
                        taken[name] = true
                    end
                end
            end
        end
        if i % 8 == 0 then
            sleep(0)
        end
    end

    return {
        machines = sortNames(machines),
        storages = sortNames(storages),
    }
end

function discover.printSummary(net)
    local m = net and net.machines or {}
    local s = net and net.storages or {}
    print(("ae2_feed: %d machine(s), %d storage(s)"):format(#m, #s))
    for i = 1, #s do
        print("  storage: " .. s[i])
    end
    for i = 1, #m do
        print("  machine: " .. m[i])
    end
end

return discover
end

-- module: transfer (shared/transfer.lua)
package.preload["transfer"] = function(...)
-- Item and fluid transfers between peripherals.
-- Item queries: exact id, or #namespace:path (item tag via getItemDetail / fallbacks).
-- Domain food/spoil/tag fallbacks are registered by craft/food.lua (optional).

local transfer = {}

local tagFallbacks = {} -- tagId -> predicate(itemName) -> bool
local spoilCheck = nil -- function(detail) -> bool
local foodItemCheck = nil -- function(name) -> bool

function transfer.registerTagFallback(tagId, fn)
    if type(tagId) == "string" and type(fn) == "function" then
        tagFallbacks[tagId] = fn
    end
end

function transfer.setSpoilCheck(fn)
    spoilCheck = fn
end

function transfer.setFoodItemCheck(fn)
    foodItemCheck = fn
end

function transfer.isTag(query)
    return type(query) == "string" and query:sub(1, 1) == "#"
end

function transfer.tagId(query)
    if not transfer.isTag(query) then
        return query
    end
    return query:sub(2)
end

--- Does inventory item (name + optional tags list) match query (exact or #tag)?
function transfer.matches(itemName, tags, query)
    if not query or query == "" then
        return true
    end
    if not transfer.isTag(query) then
        return itemName == query
    end
    local tagId = transfer.tagId(query)
    if type(tags) == "table" then
        for i = 1, #tags do
            if tags[i] == tagId then
                return true
            end
        end
        if tags[tagId] then
            return true
        end
    end
    local fb = tagFallbacks[tagId]
    if fb then
        return fb(itemName) == true
    end
    return false
end

--- TFC/Firmalife food we should inspect for spoil (when food module registered).
function transfer.isFoodItem(name)
    if foodItemCheck then
        return foodItemCheck(name) == true
    end
    return false
end

--- Best-effort spoil detect (delegates to registered check).
function transfer.isSpoiled(detail)
    if spoilCheck then
        return spoilCheck(detail) == true
    end
    return false
end

local function itemTagsFromDetail(detail)
    if not detail then
        return nil
    end
    if type(detail.tags) == "table" then
        return detail.tags
    end
    return nil
end

--- Detail for #tags, or exact food ids when food module registered (spoil filter).
local function slotDetail(inv, slot, itemQuery, itemName)
    if not inv.getItemDetail then
        return nil
    end
    local need = transfer.isTag(itemQuery)
        or (itemName and transfer.isFoodItem(itemName))
    if not need then
        return nil
    end
    local ok, detail = pcall(inv.getItemDetail, slot)
    if ok then
        return detail
    end
    return nil
end

local function slotUsable(itemName, detail, itemQuery)
    if transfer.isSpoiled(detail) then
        return false
    end
    return transfer.matches(itemName, itemTagsFromDetail(detail), itemQuery)
end

local function transferItems(from, to, itemQuery, amount)
    if not from or not to or from == to then
        return 0
    end
    if not peripheral.isPresent(from) or not peripheral.isPresent(to) then
        return 0
    end
    local source = peripheral.wrap(from)
    if not source or not source.list or not source.pushItems then
        return 0
    end
    local movedTotal = 0
    local moveAll = amount == -1
    amount = tonumber(amount) or 0
    if not moveAll and amount <= 0 then
        return 0
    end

    local listed = source.list()
    if not listed then
        return 0
    end

    local n = 0
    for slot, item in pairs(listed) do
        if moveAll or movedTotal < amount then
            local detail = slotDetail(source, slot, itemQuery, item.name)
            if slotUsable(item.name, detail, itemQuery) then
                local limit = moveAll and item.count or (amount - movedTotal)
                local moved = source.pushItems(to, slot, limit) or 0
                movedTotal = movedTotal + moved
            end
        end
        n = n + 1
        if n % 8 == 0 then
            sleep(0)
        end
    end

    return movedTotal
end

setmetatable(transfer, {
    __call = function(_, from, to, itemName, amount)
        return transferItems(from, to, itemName, amount)
    end,
})

function transfer.countItem(invName, itemQuery)
    if not invName or not peripheral.isPresent(invName) then
        return 0
    end
    local inv = peripheral.wrap(invName)
    if not inv or not inv.list then
        return 0
    end
    local total = 0
    local listed = inv.list()
    if not listed then
        return 0
    end
    local n = 0
    for slot, item in pairs(listed) do
        local detail = slotDetail(inv, slot, itemQuery, item.name)
        if slotUsable(item.name, detail, itemQuery) then
            total = total + (item.count or 0)
        end
        n = n + 1
        if n % 8 == 0 then
            sleep(0)
        end
    end
    return total
end

function transfer.countFromMany(sources, itemQuery)
    local total = 0
    if not sources then
        return 0
    end
    for i = 1, #sources do
        total = total + transfer.countItem(sources[i], itemQuery)
    end
    return total
end

function transfer.fromMany(sources, to, itemQuery, amount)
    if not sources or not to then
        return 0
    end
    local movedTotal = 0
    local moveAll = amount == -1
    for i = 1, #sources do
        local from = sources[i]
        if from and from ~= to and peripheral.isPresent(from) then
            if moveAll then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, -1)
            elseif movedTotal < amount then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, amount - movedTotal)
            end
            if not moveAll and movedTotal >= amount then
                break
            end
        end
    end
    return movedTotal
end

function transfer.toMany(from, destinations, itemQuery, amount)
    if not from or not destinations then
        return 0
    end
    local movedTotal = 0
    local moveAll = amount == -1
    for i = 1, #destinations do
        local to = destinations[i]
        if to and to ~= from and peripheral.isPresent(to) then
            if moveAll then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, -1)
            elseif movedTotal < amount then
                movedTotal = movedTotal + transferItems(from, to, itemQuery, amount - movedTotal)
            end
            if not moveAll and movedTotal >= amount then
                break
            end
        end
    end
    return movedTotal
end

function transfer.countFluid(tankName, fluidName)
    local tank = peripheral.wrap(tankName)
    if not tank or type(tank.tanks) ~= "function" then
        return 0
    end
    local total = 0
    for _, t in pairs(tank.tanks()) do
        if t and t.name == fluidName then
            total = total + (t.amount or 0)
        end
    end
    return total
end

function transfer.fluid(from, to, fluidName, amount)
    if not from or not to then
        return 0
    end
    local source = peripheral.wrap(from)
    if not source or type(source.pushFluid) ~= "function" then
        return 0
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then
        return 0
    end
    local moved = source.pushFluid(to, amount, fluidName)
    return tonumber(moved) or 0
end

return transfer
end

-- module: move (ae2_feed/move.lua)
package.preload["move"] = function(...)
-- Storage → machine feed helpers (wraps shared transfer.lua).

local transfer = require("transfer")

local move = {}

function move.firstItem(invNames)
    if not invNames then
        return nil
    end
    for i = 1, #invNames do
        local name = invNames[i]
        if peripheral.isPresent(name) then
            local inv = peripheral.wrap(name)
            if inv and inv.list then
                for _, item in pairs(inv.list()) do
                    if item and item.name then
                        return item.name
                    end
                end
            end
        end
    end
    return nil
end

function move.countInMany(invNames, itemName)
    return transfer.countFromMany(invNames, itemName)
end

--- Machines with zero of inputItem (ready for a fresh N-set).
function move.freeMachines(machines, inputItem)
    local free = {}
    if not machines or not inputItem then
        return free
    end
    for i = 1, #machines do
        local m = machines[i]
        if peripheral.isPresent(m) and transfer.countItem(m, inputItem) == 0 then
            free[#free + 1] = m
        end
    end
    return free
end

--- Push exactly N of item into each machine from storages (sequential, no stock races).
-- Returns how many machines received a full N.
function move.distribute(storages, machines, itemName, n)
    n = tonumber(n) or 0
    if n <= 0 or not storages or not machines or not itemName or #machines == 0 then
        return 0
    end

    local okCount = 0
    for i = 1, #machines do
        local moved = transfer.fromMany(storages, machines[i], itemName, n)
        if moved >= n then
            okCount = okCount + 1
        end
        sleep(0)
    end
    return okCount
end

return move
end

-- module: net_watch (shared/net_watch.lua)
package.preload["net_watch"] = function(...)
-- Shared peripheral hotplug / sleep helpers for long-running controllers.

local net_watch = {}

function net_watch.flushEvents(tag)
    tag = tag or "net_watch_flush"
    os.queueEvent(tag)
    while true do
        local ev = os.pullEvent()
        if ev == tag then
            return
        end
    end
end

--- Sleep seconds; return true if a peripheral attach/detach arrived (wakes early).
function net_watch.sleepWatch(seconds)
    local timer = os.startTimer(seconds)
    while true do
        local ev, p1 = os.pullEvent()
        if ev == "timer" and p1 == timer then
            return false
        elseif ev == "peripheral" or ev == "peripheral_detach" then
            return true
        end
    end
end

--- Sleep full duration; call onHotplug() on attach/detach but do not wake early.
function net_watch.sleepDrain(seconds, onHotplug)
    local timer = os.startTimer(seconds)
    while true do
        local ev, p1 = os.pullEvent()
        if ev == "timer" and p1 == timer then
            return
        elseif ev == "peripheral" or ev == "peripheral_detach" then
            if type(onHotplug) == "function" then
                onHotplug()
            end
        end
    end
end

function net_watch.safeCall(name, method, ...)
    local ok, a, b, c = pcall(peripheral.call, name, method, ...)
    if not ok then
        return nil
    end
    return a, b, c
end

function net_watch.safeMethod(obj, method, ...)
    if not obj or type(obj[method]) ~= "function" then
        return nil
    end
    local ok, a, b, c = pcall(obj[method], obj, ...)
    if not ok then
        return nil
    end
    return a, b, c
end

return net_watch
end

-- entry: ae2_feed/main.lua
-- Even N-per-machine feed from storages. No drain, no pattern providers.
--
-- Bundle:  python tools/bundle_project.py ae2_feed
-- Deploy:  dist/ae2_feed.lua + ae2_feed.cfg  (startup: shell.run("ae2_feed"))

local configMod = require("config")
local discover = require("discover")
local move = require("move")
local net_watch = require("net_watch")

local config = configMod.load()
local N = tonumber(config.N) or 0
if N <= 0 then
    error("ae2_feed.cfg: set N | <amount> (> 0)")
end

local net = { machines = {}, storages = {} }
local dirty = false
local lastStatus = ""
local lastStatusAt = 0

local function setStatus(msg)
    local now = os.clock()
    if msg == lastStatus and (now - lastStatusAt) < 2 then
        return
    end
    lastStatus = msg
    lastStatusAt = now
    print("ae2_feed: " .. msg)
end

local function rescan(reason)
    net = discover.scan(config)
    dirty = false
    if reason then
        print("ae2_feed: rescan (" .. tostring(reason) .. ")")
    end
    discover.printSummary(net)
    if #net.storages == 0 then
        setStatus("no storages — auto crate/barrel/chest… or storage | name in ae2_feed.cfg")
    elseif #net.machines == 0 then
        setStatus("no machines found")
    end
end

local function ensureNet()
    if dirty or #net.machines == 0 or #net.storages == 0 then
        rescan(dirty and "hotplug" or "init")
    end
    return #net.machines > 0 and #net.storages > 0
end

--- Drop everything currently queued (boot peripheral attaches, etc.).
local function flushEvents()
    net_watch.flushEvents("ae2_feed_flush")
end

--- Yield one tick and note any hotplug that arrived.
local function yieldAndWatch()
    if net_watch.sleepWatch(0) then
        dirty = true
    end
end

local function tick()
    if not ensureNet() then
        return
    end

    local storages = net.storages
    local machines = net.machines
    local inputItem = move.firstItem(storages)
    if not inputItem then
        return
    end

    local free = move.freeMachines(machines, inputItem)
    if #free == 0 then
        setStatus("wait — no free machine for " .. inputItem)
        return
    end

    local stock = move.countInMany(storages, inputItem)
    local feeds = math.min(math.floor(stock / N), #free)
    if feeds <= 0 then
        setStatus(("wait — need %d x %s (have %d)"):format(N, inputItem, stock))
        return
    end

    local targets = {}
    for i = 1, feeds do
        targets[i] = free[i]
    end

    local fed = move.distribute(storages, targets, inputItem, N)
    if fed > 0 then
        setStatus(("fed %d x%d %s"):format(fed, N, inputItem))
    else
        setStatus("push failed — machine rejected items")
    end
end

print(("ae2_feed: N=%d"):format(N))
rescan("start")
flushEvents()
dirty = false

while true do
    tick()
    yieldAndWatch()
end
