-- Bundled from ae_stats/display.lua — do not edit by hand; rebuild with tools/bundle_project.py
-- Also copy the matching .cfg next to this file (sampler.cfg / display.cfg / graphview.cfg; display+graphview also need labels.cfg).
-- Generated package.preload modules + entrypoint.

-- module: util (shared/util.lua)
package.preload["util"] = function(...)
-- Shared string / path helpers for CC:Tweaked scripts.

local util = {}

function util.trim(s)
    return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

function util.split(s, sep)
    local out = {}
    s = tostring(s or "")
    for part in (s .. sep):gmatch("(.-)" .. sep) do
        out[#out + 1] = part
    end
    return out
end

--- Resolve a config path relative to the running program directory.
function util.resolvePath(path, defaultName)
    path = path or defaultName
    if not path then
        error("resolvePath: path required", 2)
    end
    if path:sub(1, 1) == "/" then
        return path
    end
    local base = ""
    if shell and shell.getRunningProgram then
        local prog = shell.getRunningProgram()
        if prog then
            base = fs.getDir(prog)
        end
    end
    return fs.combine(base, path)
end

--- Read entire file as string, or nil if missing.
function util.readAll(path)
    if not path or not fs.exists(path) then
        return nil
    end
    local file = fs.open(path, "r")
    if not file then
        return nil
    end
    local text = file.readAll()
    file.close()
    return text
end

--- Basename of the running program without .lua (e.g. pizza_maintain).
function util.programStem()
    if not (shell and shell.getRunningProgram) then
        return nil
    end
    local prog = shell.getRunningProgram()
    if not prog then
        return nil
    end
    local name = fs.getName(prog)
    return (name:gsub("%.lua$", ""))
end

--- Lines of `[section]` from a sectioned cfg. Nil if file/section missing.
function util.cfgSectionLines(path, section)
    local text = util.readAll(path)
    if not text or not section then
        return nil
    end
    local current = nil
    local buf = {}
    local found = false
    for line in (text .. "\n"):gmatch("(.-)\n") do
        local sec = line:match("^%s*%[([%w_]+)%]%s*$")
        if sec then
            if found then
                break
            end
            if sec == section then
                found = true
                current = sec
                buf = {}
            else
                current = nil
            end
        elseif found and current == section then
            buf[#buf + 1] = line
        end
    end
    if not found then
        return nil
    end
    return buf
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Try sectioned cfg at path; return lines, label or nil.
local function trySectioned(path, section)
    if not path or not fs.exists(path) then
        return nil
    end
    local sectionLines = util.cfgSectionLines(path, section)
    if not sectionLines then
        return nil
    end
    return sectionLines, path .. "[" .. section .. "]"
end

--- Config lines for a logical section.
-- Order: explicit path → <program>.cfg [section] → craft.cfg [section] → fallbackName.
-- Returns lines, label (for errors).
function util.openConfigLines(explicitPath, section, fallbackName)
    if explicitPath then
        local path = util.resolvePath(explicitPath)
        local text = util.readAll(path)
        if not text then
            error("Cannot open " .. path, 2)
        end
        return linesFromText(text), path
    end

    local stem = util.programStem()
    if stem then
        local lines, label = trySectioned(util.resolvePath(nil, stem .. ".cfg"), section)
        if lines then
            return lines, label
        end
    end

    local lines, label = trySectioned(util.resolvePath(nil, "craft.cfg"), section)
    if lines then
        return lines, label
    end

    local path = util.resolvePath(nil, fallbackName)
    local text = util.readAll(path)
    if not text then
        local hint = stem and (stem .. ".cfg") or "program.cfg"
        error(
            "Cannot open " .. path
                .. " (deploy "
                .. hint
                .. " next to the program, or "
                .. tostring(fallbackName)
                .. ")",
            2
        )
    end
    return linesFromText(text), path
end

--- Short display name: last path segment after `/`.
function util.short(id)
    id = tostring(id or "")
    return id:match("([^/]+)$") or id
end

function util.clamp(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

return util
end

-- module: protocol (ae_stats/protocol.lua)
package.preload["protocol"] = function(...)
-- Rednet protocol for ae_stats sampler <-> display <-> graphview.

local protocol = {}

protocol.NAME = "tfg_ae_stats"
protocol.HOST = "ae_stats_sampler"
protocol.GRAPH_HOST = "ae_stats_graph"

-- Message kinds:
--   hello      { kind, role }                    sampler announce / display ping
--   list_req   { kind, q, offset, limit, reply }
--   list_res   { kind, items, total, q }
--   track_set  { kind, items }                   legacy no-op on sampler
--   track_ack  { kind, items }
--   history_req{ kind, item, since, reply }
--   history_res{ kind, item, points, amount }
--   sample     { kind, item, t, amount }         broadcast from sampler
--   focus_set  { kind, item, window?, step?, interp? }  display → graphview


function protocol.encode(msg)
    return textutils.serialize(msg)
end

function protocol.decode(payload)
    if type(payload) ~= "string" then
        return nil
    end
    local ok, msg = pcall(textutils.unserialize, payload)
    if not ok or type(msg) ~= "table" or type(msg.kind) ~= "string" then
        return nil
    end
    return msg
end

function protocol.send(id, msg)
    return rednet.send(id, protocol.encode(msg), protocol.NAME)
end

function protocol.broadcast(msg)
    return rednet.broadcast(protocol.encode(msg), protocol.NAME)
end

--- Wait for a message matching kind (and optional from id). Timeout in seconds.
function protocol.receive(timeout, wantKind, fromId)
    local deadline = timeout and (os.clock() + timeout) or nil
    while true do
        local left = nil
        if deadline then
            left = deadline - os.clock()
            if left <= 0 then
                return nil
            end
        end
        local id, payload, proto = rednet.receive(protocol.NAME, left)
        if not id then
            return nil
        end
        if fromId and id ~= fromId then
            -- keep waiting
        else
            local msg = protocol.decode(payload)
            if msg and (not wantKind or msg.kind == wantKind) then
                return id, msg
            end
        end
    end
end

return protocol
end

-- module: graph (ae_stats/graph.lua)
package.preload["graph"] = function(...)
-- Bucket + interpolate AE amount series for monitor plotting.

local util = require("util")

local graph = {}

graph.WINDOWS = {
    { id = "5m", label = "5m", sec = 5 * 60 },
    { id = "10m", label = "10m", sec = 10 * 60 },
    { id = "30m", label = "30m", sec = 30 * 60 },
    { id = "1h", label = "1h", sec = 60 * 60 },
    { id = "2h", label = "2h", sec = 2 * 60 * 60 },
}

graph.STEPS = {
    { id = "1m", label = "1m", sec = 60 },
    { id = "5m", label = "5m", sec = 5 * 60 },
    { id = "10m", label = "10m", sec = 10 * 60 },
    { id = "30m", label = "30m", sec = 30 * 60 },
}

graph.INTERPS = {
    { id = "off", label = "off" },
    { id = "i1", label = "i1" },
    { id = "i2", label = "i2" },
}

function graph.findWindow(id)
    for i = 1, #graph.WINDOWS do
        if graph.WINDOWS[i].id == id then
            return graph.WINDOWS[i]
        end
    end
    return graph.WINDOWS[1]
end

function graph.findStep(id)
    for i = 1, #graph.STEPS do
        if graph.STEPS[i].id == id then
            return graph.STEPS[i]
        end
    end
    return graph.STEPS[2]
end

--- Steps with sec <= window (s must not exceed w).
function graph.stepsForWindow(windowId)
    local win = graph.findWindow(windowId)
    local out = {}
    for i = 1, #graph.STEPS do
        if graph.STEPS[i].sec <= win.sec then
            out[#out + 1] = graph.STEPS[i]
        end
    end
    if #out == 0 then
        out[1] = graph.STEPS[1]
    end
    return out
end

function graph.clampStep(windowId, stepId)
    local steps = graph.stepsForWindow(windowId)
    for i = 1, #steps do
        if steps[i].id == stepId then
            return stepId
        end
    end
    return steps[1].id
end

--- Bucket raw points into step-sized bins (last sample wins).
function graph.bucket(points, windowSec, stepSec, nowT)
    nowT = nowT or (os.epoch("utc") / 1000)
    stepSec = math.max(1, tonumber(stepSec) or 1)
    if stepSec > windowSec then
        stepSec = windowSec
    end
    local startT = nowT - windowSec
    local n = math.max(1, math.floor(windowSec / stepSec + 1e-9))
    local buckets = {}
    for i = 1, n do
        buckets[i] = { t = startT + (i - 0.5) * stepSec, amount = nil }
    end
    for i = 1, #(points or {}) do
        local p = points[i]
        local t = tonumber(p.t)
        local amount = tonumber(p.amount)
        if t and amount ~= nil and t >= startT and t <= nowT + 1 then
            local idx = math.floor((t - startT) / stepSec) + 1
            idx = util.clamp(idx, 1, n)
            buckets[idx].amount = amount
            buckets[idx].t = t
        end
    end
    return buckets
end

local function lerp(a, b, t)
    return a + (b - a) * t
end

--- Catmull-Rom between p1-p2 with neighbors p0,p3; t in [0,1].
local function catmull(p0, p1, p2, p3, t)
    local t2 = t * t
    local t3 = t2 * t
    return 0.5 * (
        (2 * p1)
        + (-p0 + p2) * t
        + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2
        + (-p0 + 3 * p1 - 3 * p2 + p3) * t3
    )
end

--- Build dense Y values for width columns. Returns ys[1..width], ymin, ymax.
function graph.resample(buckets, width, interp)
    width = math.max(2, math.floor(width))
    local known = {}
    for i = 1, #buckets do
        if buckets[i].amount ~= nil then
            known[#known + 1] = { i = i, amount = buckets[i].amount }
        end
    end
    if #known == 0 then
        local ys = {}
        for x = 1, width do
            ys[x] = nil
        end
        return ys, 0, 1
    end

    local function bucketToX(bi)
        if #buckets <= 1 then
            return 1
        end
        return 1 + (bi - 1) * (width - 1) / (#buckets - 1)
    end

    local ys = {}
    for x = 1, width do
        ys[x] = nil
    end

    if interp == "off" then
        for k = 1, #known do
            local x = math.floor(bucketToX(known[k].i) + 0.5)
            x = util.clamp(x, 1, width)
            ys[x] = known[k].amount
        end
    elseif interp == "i2" and #known >= 2 then
        for x = 1, width do
            local pos = 1 + (x - 1) * (#buckets - 1) / (width - 1)
            -- find segment in known by bucket index
            local bi = pos
            local k = 1
            while k < #known and known[k + 1].i < bi do
                k = k + 1
            end
            local k0 = util.clamp(k - 1, 1, #known)
            local k1 = k
            local k2 = util.clamp(k + 1, 1, #known)
            local k3 = util.clamp(k + 2, 1, #known)
            local i1, i2 = known[k1].i, known[k2].i
            local t = 0
            if i2 ~= i1 then
                t = util.clamp((bi - i1) / (i2 - i1), 0, 1)
            end
            ys[x] = catmull(known[k0].amount, known[k1].amount, known[k2].amount, known[k3].amount, t)
        end
    else
        -- i1 linear (also fallback)
        for x = 1, width do
            local pos = 1 + (x - 1) * (#buckets - 1) / (width - 1)
            local k = 1
            while k < #known and known[k + 1].i < pos do
                k = k + 1
            end
            if k >= #known then
                ys[x] = known[#known].amount
            elseif known[k].i >= pos then
                ys[x] = known[k].amount
            else
                local a, b = known[k], known[k + 1]
                local t = (pos - a.i) / (b.i - a.i)
                ys[x] = lerp(a.amount, b.amount, t)
            end
        end
    end

    local ymin, ymax = nil, nil
    for x = 1, width do
        local v = ys[x]
        if v ~= nil then
            if not ymin or v < ymin then
                ymin = v
            end
            if not ymax or v > ymax then
                ymax = v
            end
        end
    end
    if not ymin then
        ymin, ymax = 0, 1
    end
    if ymax <= ymin then
        ymax = ymin + 1
    end
    local pad = (ymax - ymin) * 0.05
    return ys, ymin - pad, ymax + pad
end

--- Compact number with spaced unit: "2.3 k", "7.09 M", "130".
local function fmtNum(n)
    n = tonumber(n) or 0
    local a = math.abs(n)
    if a >= 1e9 then
        return string.format("%.2f G", n / 1e9)
    elseif a >= 1e6 then
        return string.format("%.2f M", n / 1e6)
    elseif a >= 1e3 then
        return string.format("%.1f k", n / 1e3)
    end
    return string.format("%.0f", n)
end

--- Item/fluid amount for lists: "2.3 k", "7.09 MmB", "371.5 kmB", "64 mB".
local function fmtAmount(n, isFluid)
    n = tonumber(n) or 0
    local a = math.abs(n)
    local num, pref
    if a >= 1e9 then
        num, pref = string.format("%.2f", n / 1e9), "G"
    elseif a >= 1e6 then
        num, pref = string.format("%.2f", n / 1e6), "M"
    elseif a >= 1e3 then
        num, pref = string.format("%.1f", n / 1e3), "k"
    else
        num, pref = string.format("%.0f", n), ""
    end
    if isFluid then
        if pref == "" then
            return num .. " mB"
        end
        return num .. " " .. pref .. "mB"
    end
    if pref == "" then
        return num
    end
    return num .. " " .. pref
end

--- Axis label: pick unit/decimals from (ymin..ymax) so top/mid/bot stay distinct.
local function fmtAmountAxis(n, isFluid, ymin, ymax)
    n = tonumber(n) or 0
    ymin = tonumber(ymin) or n
    ymax = tonumber(ymax) or n
    local span = math.abs(ymax - ymin)
    if span < 1e-9 then
        span = math.max(math.abs(n) * 0.01, 1)
    end
    local mag = math.max(math.abs(ymin), math.abs(ymax), math.abs(n))

    local div, pref
    if mag >= 1e9 then
        div, pref = 1e9, "G"
    elseif mag >= 1e6 then
        div, pref = 1e6, "M"
    elseif mag >= 1e3 then
        div, pref = 1e3, "k"
    else
        div, pref = 1, ""
    end

    -- decimals so one step of the axis (~span/2) changes the printed number
    local step = (span / div) / 2
    local decimals = 0
    if step > 0 and step < 1 then
        decimals = math.ceil(-math.log10(step)) + 1
    end
    decimals = util.clamp(decimals, 0, 3)
    -- tight zoom on large totals: need more digits (2.80 k vs 2.81 k)
    if pref ~= "" and span / mag < 0.05 then
        decimals = math.max(decimals, 2)
    end

    local num = string.format("%." .. tostring(decimals) .. "f", n / div)
    if isFluid then
        if pref == "" then
            return num .. " mB"
        end
        return num .. " " .. pref .. "mB"
    end
    if pref == "" then
        return num
    end
    return num .. " " .. pref
end

graph.fmtNum = fmtNum
graph.fmtAmount = fmtAmount
graph.fmtAmountAxis = fmtAmountAxis

local function toBlit(color)
    -- CC color bit -> blit hex digit
    local n = 0
    local c = color or 1
    while c > 1 do
        c = math.floor(c / 2)
        n = n + 1
    end
    return ("0123456789abcdef"):sub(n + 1, n + 1)
end

local BLIT_BLACK = toBlit(colors.black)
local BLIT_GRAY = toBlit(colors.gray)
local BLIT_LGRAY = toBlit(colors.lightGray)
local BLIT_LINE = toBlit(colors.lime)
local BLIT_LINE2 = toBlit(colors.cyan)
local BLIT_FILL = toBlit(colors.green)
local BLIT_WHITE = toBlit(colors.white)

--- Area + thin top-edge chart (no thick paintutils stairs).
-- Left gutter = Y labels; plot = fill under curve + ▀ edge.
-- isFluid selects mB axis units.
function graph.draw(mon, x0, y0, w, h, ys, ymin, ymax, interp, isFluid)
    if w < 8 or h < 3 then
        return
    end
    local span = ymax - ymin
    if span <= 0 then
        span = 1
    end

    local function axisLabel(v)
        return fmtAmountAxis(v, isFluid, ymin, ymax)
    end
    local topL = axisLabel(ymax)
    local midL = axisLabel((ymin + ymax) * 0.5)
    local botL = axisLabel(ymin)
    local labelW = math.max(#topL, #midL, #botL)

    local gutter = util.clamp(labelW + 1, 8, 14)
    local plotX = x0 + gutter
    local plotW = w - gutter
    local plotH = h
    if plotW < 4 then
        gutter = 6
        plotX = x0 + gutter
        plotW = w - gutter
    end

    -- ys may be sized to an earlier plotW estimate; remap by index
    local ysLen = #ys
    local function yAt(x)
        if ysLen <= 0 then
            return nil
        end
        if ysLen == plotW then
            return ys[x]
        end
        local idx = math.floor((x - 1) * (ysLen - 1) / math.max(1, plotW - 1) + 0.5) + 1
        return ys[util.clamp(idx, 1, ysLen)]
    end

    local lineBlit = (interp == "i2") and BLIT_LINE2 or BLIT_LINE
    local midRow = math.floor((plotH - 1) * 0.5)
    local q1 = math.floor((plotH - 1) * 0.25)
    local q3 = math.floor((plotH - 1) * 0.75)

    local cols = {}
    for x = 1, plotW do
        local v = yAt(x)
        if v ~= nil then
            local norm = (v - ymin) / span
            cols[x] = util.clamp((1 - norm) * (plotH - 1), 0, plotH - 1)
        end
    end

    for row = 0, plotH - 1 do
        local chars, fg, bg = {}, {}, {}
        local grid = (row == midRow or row == q1 or row == q3)
        for x = 1, plotW do
            local yv = cols[x]
            local ch, f, b = " ", BLIT_WHITE, BLIT_BLACK
            if grid and yv == nil then
                ch, f, b = "-", BLIT_GRAY, BLIT_BLACK
            elseif yv ~= nil then
                local yi = math.floor(yv + 1e-9)
                if interp == "off" then
                    if row == yi then
                        ch, f, b = "o", lineBlit, BLIT_BLACK
                    elseif grid and row < yi then
                        ch, f, b = "-", BLIT_GRAY, BLIT_BLACK
                    end
                else
                    if row > yi then
                        ch, f, b = " ", BLIT_WHITE, BLIT_FILL
                    elseif row == yi then
                        ch, f, b = "\143", lineBlit, BLIT_FILL
                    elseif grid then
                        ch, f, b = "-", BLIT_LGRAY, BLIT_BLACK
                    end
                end
            end
            chars[x], fg[x], bg[x] = ch, f, b
        end
        mon.setCursorPos(plotX, y0 + row)
        mon.blit(table.concat(chars), table.concat(fg), table.concat(bg))
    end

    local function fit(s)
        if #s > gutter - 1 then
            return s:sub(1, gutter - 1)
        end
        return s
    end
    mon.setBackgroundColor(colors.black)
    mon.setTextColor(colors.white)
    mon.setCursorPos(x0, y0)
    mon.write(fit(topL))
    mon.setCursorPos(x0, y0 + midRow)
    mon.setTextColor(colors.lightGray)
    mon.write(fit(midL))
    mon.setCursorPos(x0, y0 + plotH - 1)
    mon.setTextColor(colors.white)
    mon.write(fit(botL))
end

return graph
end

-- module: cfg_pipe (shared/cfg_pipe.lua)
package.preload["cfg_pipe"] = function(...)
-- Shared pipe-delimited cfg helpers (key | value [| ...]).

local util = require("util")

local cfg_pipe = {}

cfg_pipe.trim = util.trim
cfg_pipe.split = util.split
cfg_pipe.resolvePath = util.resolvePath

function cfg_pipe.parseScale(raw)
    raw = util.trim(tostring(raw or "")):lower()
    if raw == "" or raw == "auto" then
        return "auto"
    end
    local n = tonumber(raw)
    if not n then
        return "auto"
    end
    n = math.floor(n * 2 + 0.5) / 2
    return util.clamp(n, 0.5, 5)
end

--- Split a cfg line into key, value, parts (or nil, errHint).
function cfg_pipe.splitLine(line)
    line = util.trim(line or "")
    if line == "" or line:sub(1, 1) == "#" then
        return nil
    end
    local parts = util.split(line, "|")
    for i = 1, #parts do
        parts[i] = util.trim(parts[i])
    end
    local key = (parts[1] or ""):lower()
    if key == "" then
        return nil, "empty key"
    end
    if parts[2] == nil or parts[2] == "" then
        return nil, key .. " | value"
    end
    return key, parts[2], parts
end

local function linesFromText(text)
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        lines[#lines + 1] = line
    end
    return lines
end

--- Load all lines from a cfg file.
-- @return lines, path, ok
function cfg_pipe.loadLines(path, defaultName)
    path = util.resolvePath(path, defaultName)
    if not fs.exists(path) then
        return nil, path, false
    end
    local text = util.readAll(path)
    if not text then
        error("Cannot open " .. path, 2)
    end
    return linesFromText(text), path, true
end

return cfg_pipe
end

-- module: config_common (ae_stats/config_common.lua)
package.preload["config_common"] = function(...)
-- Shared key|value cfg helpers for ae_stats (thin wrap over shared/cfg_pipe).

local util = require("util")
local cfg_pipe = require("cfg_pipe")

local config_common = {}

config_common.parseScale = cfg_pipe.parseScale
config_common.splitLine = cfg_pipe.splitLine
config_common.loadLines = cfg_pipe.loadLines

--- Track id: "item|<name>" or "fluid|<name>"
function config_common.trackId(kind, name)
    kind = (kind == "fluid") and "fluid" or "item"
    return kind .. "|" .. tostring(name)
end

function config_common.parseTrackId(id)
    id = tostring(id or "")
    local kind, name = id:match("^(%w+)|(.+)$")
    if kind == "item" or kind == "fluid" then
        return kind, name
    end
    return "item", id
end

function config_common.writeWatchlist(path, items)
    path = util.resolvePath(path)
    local file = fs.open(path, "w")
    if not file then
        return false
    end
    file.writeLine("# auto-saved watchlist (track | item|fluid | name)")
    for i = 1, #items do
        local kind, name = config_common.parseTrackId(items[i])
        file.writeLine("track | " .. kind .. " | " .. name)
    end
    file.close()
    return true
end

function config_common.readWatchlist(path)
    path = util.resolvePath(path)
    if not fs.exists(path) then
        return {}
    end
    local file = fs.open(path, "r")
    if not file then
        return {}
    end
    local items = {}
    local seen = {}
    while true do
        local line = file.readLine()
        if not line then
            break
        end
        local key, val, parts = config_common.splitLine(line)
        if key == "track" and val then
            local kind, name
            if parts[3] and parts[3] ~= "" then
                kind = val:lower()
                name = parts[3]
                if kind ~= "fluid" then
                    kind = "item"
                end
            else
                kind, name = "item", val
            end
            local id = config_common.trackId(kind, name)
            if not seen[id] then
                seen[id] = true
                items[#items + 1] = id
            end
        end
    end
    file.close()
    return items
end

return config_common
end

-- module: labels (ae_stats/labels.lua)
package.preload["labels"] = function(...)
-- Optional display-name translations from labels.cfg.

local util = require("util")
local config_common = require("config_common")

local labels = {
    byKey = {}, -- lowercased registry or english name -> shown label
}

local function add(key, shown)
    key = util.trim(tostring(key or "")):lower()
    shown = util.trim(tostring(shown or ""))
    if key ~= "" and shown ~= "" then
        labels.byKey[key] = shown
    end
end

function labels.load(path)
    labels.byKey = {}
    path = util.resolvePath(path, "labels.cfg")
    local lines, _, ok = config_common.loadLines(path, "labels.cfg")
    if not ok or not lines then
        return false, path
    end
    for n = 1, #lines do
        local key, val, parts = config_common.splitLine(lines[n])
        if key == "label" and val then
            local shown = parts[3]
            if shown and shown ~= "" then
                add(val, shown)
            end
        end
    end
    return true, path
end

local function lookup(key)
    key = util.trim(tostring(key or "")):lower()
    if key == "" then
        return nil
    end
    local hit = labels.byKey[key]
    if hit then
        return hit
    end
    -- last path segment: gtceu:foo_dust / material.tfg.foo
    local seg = key:match("([^:/]+)$")
    if seg and seg ~= key then
        hit = labels.byKey[seg]
        if hit then
            return hit
        end
    end
    return nil
end

--- Prefer registry name, then English displayName, else short fallback.
function labels.resolve(name, displayName)
    name = tostring(name or "")
    displayName = tostring(displayName or "")
    local hit = lookup(name)
    if hit then
        return hit
    end
    hit = lookup(displayName)
    if hit then
        return hit
    end
    -- avoid showing raw translation keys like material.tfg.*
    if displayName:find("^material%.", 1) then
        return util.short(name ~= "" and name or displayName)
    end
    return util.short(displayName ~= "" and displayName or name)
end

return labels
end

-- entry: ae_stats/display.lua
-- AE stats display: resource list on power computer (right monitor).
-- Sends focus_set to graphview PC; does not draw local charts.
--
-- Bundle:  python tools/bundle_project.py ae_stats display
-- Deploy:  dist/display.lua + display.cfg + labels.cfg
-- Tip: keep this tab focused in multishell so monitor_touch is delivered.

local util = require("util")
local protocol = require("protocol")
local graph = require("graph")
local config_common = require("config_common")
local labels = require("labels")

local function defaults()
    return {
        monitor = "right",
        modem = "top",
        text_scale = "auto",
        host_id = nil,
        graph_id = nil,
        refresh_interval = 5,
    }
end

local function loadConfig()
    local cfg = defaults()
    local lines, path, ok = config_common.loadLines(nil, "display.cfg")
    if not ok then
        return cfg, path, false
    end
    for n = 1, #lines do
        local key, val = config_common.splitLine(lines[n])
        if key == "monitor" then
            cfg.monitor = val
        elseif key == "modem" then
            cfg.modem = val
        elseif key == "text_scale" or key == "monitor_scale" then
            cfg.text_scale = config_common.parseScale(val)
        elseif key == "host_id" then
            cfg.host_id = tonumber(val)
        elseif key == "graph_id" then
            cfg.graph_id = tonumber(val)
        elseif key == "refresh_interval" or key == "auto_refresh" then
            cfg.refresh_interval = tonumber(val) or cfg.refresh_interval
        elseif key == "window" or key == "step" or key == "interp" then
            -- ignored on list PC (graphview owns chart settings)
        elseif key then
            error(("display.cfg line %s: unknown key %q"):format(tostring(n), key))
        end
    end
    return cfg, path, true
end

local cfg = loadConfig()
labels.load()

local monName = cfg.monitor
local mon = assert(peripheral.wrap(monName), "No monitor on " .. monName)
if peripheral.getName then
    local ok, n = pcall(peripheral.getName, mon)
    if ok and n then
        monName = n
    end
end

local NEED_W, NEED_H = 36, 14

local function applyScale()
    local chosen = 0.5
    if cfg.text_scale == "auto" then
        for scale = 5, 0.5, -0.5 do
            mon.setTextScale(scale)
            local w, h = mon.getSize()
            if w >= NEED_W and h >= NEED_H then
                chosen = scale
                break
            end
        end
    else
        chosen = cfg.text_scale
    end
    mon.setTextScale(chosen)
    return chosen, mon.getSize()
end

local textScale, W, H = applyScale()

local state = {
    host = cfg.host_id,
    graph = cfg.graph_id,
    status = "Looking up sampler...",
    filter = "",
    filterEdit = false,
    items = {},
    total = 0,
    scroll = 0,
    selected = nil,
}

local buttons = {}
local pendingTouches = {}

local function fill(x, y, w, h, color)
    mon.setBackgroundColor(color)
    for row = y, y + h - 1 do
        mon.setCursorPos(x, row)
        mon.write((" "):rep(w))
    end
end

local function writeAt(x, y, text, fg, bg)
    mon.setCursorPos(x, y)
    if bg then
        mon.setBackgroundColor(bg)
    end
    if fg then
        mon.setTextColor(fg)
    end
    mon.write(tostring(text))
end

local function addButton(id, x, y, w, h, label, fg, bg)
    buttons[#buttons + 1] = {
        id = id,
        x = x,
        y = y,
        w = w,
        h = h,
        label = label,
        fg = fg or colors.white,
        bg = bg or colors.gray,
    }
end

local function hitButton(x, y)
    for i = #buttons, 1, -1 do
        local b = buttons[i]
        if x >= b.x and x < b.x + b.w and y >= b.y and y < b.y + b.h then
            return b
        end
    end
    return nil
end

local function isOurMonitor(name)
    if not name then
        return false
    end
    if name == cfg.monitor or name == monName then
        return true
    end
    local p = peripheral.wrap(name)
    return p ~= nil and p == mon
end

local function openModem()
    if not peripheral.isPresent(cfg.modem) then
        error("No modem on " .. tostring(cfg.modem))
    end
    rednet.open(cfg.modem)
end

local function resolveHost()
    if state.host then
        return state.host
    end
    local id = rednet.lookup(protocol.NAME, protocol.HOST)
    if id then
        state.host = id
    end
    return state.host
end

local function resolveGraph()
    if state.graph then
        return state.graph
    end
    local id = rednet.lookup(protocol.NAME, protocol.GRAPH_HOST)
    if id then
        state.graph = id
    end
    return state.graph
end

local function req(msg, wantKind, timeout)
    local host = resolveHost()
    if not host then
        state.status = "No sampler (lookup)"
        return nil
    end
    protocol.send(host, msg)
    local deadline = os.clock() + (timeout or 3)
    while os.clock() < deadline do
        local left = math.max(0.05, deadline - os.clock())
        local timer = os.startTimer(left)
        local ev, a, b, c = os.pullEvent()
        if ev == "timer" and a == timer then
            -- continue
        elseif ev == "rednet_message" and c == protocol.NAME then
            local m = protocol.decode(b)
            if m then
                if a == host and m.kind == wantKind then
                    return m
                elseif m.kind == "hello" and m.role == "sampler" then
                    state.host = a
                end
            end
        elseif ev == "monitor_touch" and isOurMonitor(a) then
            pendingTouches[#pendingTouches + 1] = { x = b, y = c }
        elseif ev == "monitor_resize" and isOurMonitor(a) then
            textScale, W, H = applyScale()
        end
    end
    state.status = "Timeout: " .. tostring(wantKind)
    return nil
end

local function refreshList()
    local res = req({
        kind = "list_req",
        q = state.filter,
        offset = state.scroll,
        limit = math.max(5, H - 6),
    }, "list_res", 5)
    if res then
        state.items = res.items or {}
        state.total = res.total or 0
        state.status = ("AE %d/%d sc:%.1f"):format(#state.items, state.total, textScale)
    end
end

local function findSelectedItem()
    for i = 1, #state.items do
        local it = state.items[i]
        local id = it.id or config_common.trackId(it.kind or "item", it.name)
        if id == state.selected then
            return it
        end
    end
    return nil
end

local function sendFocus()
    if not state.selected then
        return
    end
    local gid = resolveGraph()
    if not gid then
        state.status = "No graph PC (lookup)"
        return
    end
    local it = findSelectedItem()
    local msg = {
        kind = "focus_set",
        item = state.selected,
        displayName = it and it.displayName or nil,
    }
    protocol.send(gid, msg)
    local kind, name = config_common.parseTrackId(state.selected)
    local shown = labels.resolve(name, it and it.displayName or name)
    state.status = "graph ← " .. shown
end

local function drawChrome()
    fill(1, 1, W, 1, colors.gray)
    writeAt(1, 1, " AE STATS ", colors.white, colors.gray)
    local right = state.status or ""
    if #right > W - 12 then
        right = right:sub(1, W - 12)
    end
    writeAt(math.max(12, W - #right + 1), 1, right, colors.lightGray, colors.gray)
end

local function drawButtons()
    for i = 1, #buttons do
        local b = buttons[i]
        if b.label and b.label ~= "" then
            fill(b.x, b.y, b.w, b.h, b.bg)
            local label = b.label
            if #label > b.w then
                label = label:sub(1, b.w)
            end
            local lx = b.x + math.floor((b.w - #label) / 2)
            local ly = b.y + math.floor((b.h - 1) / 2)
            writeAt(lx, ly, label, b.fg, b.bg)
        end
    end
end

local AMT_COL = 11

local function padLeft(s, width)
    s = tostring(s or "")
    if #s > width then
        return s:sub(1, width)
    end
    return string.rep(" ", width - #s) .. s
end

local function padRight(s, width)
    s = tostring(s or "")
    if #s > width then
        return s:sub(1, width)
    end
    return s .. string.rep(" ", width - #s)
end

local function formatListRow(it)
    local tag = (it.kind == "fluid") and "F" or "I"
    local name = labels.resolve(it.name, it.displayName)
    local amt = padLeft(graph.fmtAmount(it.amount, it.kind == "fluid"), AMT_COL)
    local line = (" %s %s %s"):format(tag, amt, name)
    if #line > W then
        line = line:sub(1, W)
    else
        line = padRight(line, W)
    end
    return line
end

local function draw()
    buttons = {}
    textScale, W, H = applyScale()
    mon.setBackgroundColor(colors.black)
    mon.clear()
    drawChrome()

    local filterLine = state.filterEdit
        and ("> " .. state.filter .. "_")
        or ("Filter: " .. (state.filter ~= "" and state.filter or "(tap to type)"))
    fill(1, 2, W, 1, state.filterEdit and colors.blue or colors.black)
    writeAt(1, 2, filterLine:sub(1, W), colors.yellow, state.filterEdit and colors.blue or colors.black)
    addButton("filter", 1, 2, W, 1, "", colors.yellow, colors.black)

    local listTop = 3
    local listBot = H - 3
    local rows = math.max(1, listBot - listTop + 1)
    for i = 1, rows do
        local it = state.items[i]
        local y = listTop + i - 1
        if it then
            local id = it.id or config_common.trackId(it.kind or "item", it.name)
            local sel = state.selected == id
            local bg = sel and colors.blue or colors.black
            local fg = sel and colors.white or colors.lightGray
            if it.kind == "fluid" and not sel then
                fg = colors.cyan
            end
            fill(1, y, W, 1, bg)
            writeAt(1, y, formatListRow(it), fg, bg)
            addButton("pick:" .. id, 1, y, W, 1, "", fg, bg)
        end
    end

    local by = H - 2
    addButton("up", 1, by, 5, 2, " ^ ", colors.white, colors.gray)
    addButton("dn", 7, by, 5, 2, " v ", colors.white, colors.gray)
    addButton("refresh", 13, by, 8, 2, "reload", colors.white, colors.gray)
    if state.selected then
        addButton("open", W - 10, by, 10, 2, " graph ", colors.black, colors.lime)
    end

    drawButtons()
    writeAt(1, H, ("scroll %d  total %d  tap rows"):format(state.scroll, state.total), colors.lightGray, colors.black)
end

local function pageSize()
    return math.max(3, H - 6)
end

local function onTouch(x, y)
    local b = hitButton(x, y)
    if not b then
        state.status = ("miss %d,%d"):format(x, y)
        draw()
        return
    end
    local id = b.id
    if id == "filter" then
        state.filterEdit = not state.filterEdit
        if state.filterEdit then
            state.status = "Type filter on PC, Enter=done"
        end
    elseif id == "up" then
        state.scroll = math.max(0, state.scroll - pageSize())
        refreshList()
    elseif id == "dn" then
        state.scroll = state.scroll + pageSize()
        if state.total > 0 then
            state.scroll = math.min(state.scroll, math.max(0, state.total - 1))
        end
        refreshList()
    elseif id == "refresh" or id == "reload" then
        refreshList()
    elseif id == "open" then
        sendFocus()
    elseif id:sub(1, 5) == "pick:" then
        local tid = id:sub(6)
        if state.selected == tid then
            sendFocus()
        else
            state.selected = tid
        end
    end
    draw()
end

local function drainPendingTouches()
    while #pendingTouches > 0 do
        local t = table.remove(pendingTouches, 1)
        onTouch(t.x, t.y)
    end
end

local function main()
    openModem()
    resolveHost()
    resolveGraph()
    if state.host then
        local hello = req({ kind = "hello", role = "display" }, "hello", 2)
        if hello then
            state.status = "sampler #" .. tostring(state.host)
        end
    end
    refreshList()
    drainPendingTouches()
    draw()
    print(("AE display on %s scale=%.1f size=%dx%d"):format(monName, textScale, W, H))
    print("Keep this tab focused for touch input.")

    local refreshSec = tonumber(cfg.refresh_interval) or 5
    if refreshSec < 0 then
        refreshSec = 0
    end
    local redrawTimer = os.startTimer(math.max(0.5, refreshSec > 0 and refreshSec or 2))
    while true do
        local ev, a, b, c = os.pullEvent()
        if ev == "monitor_touch" and isOurMonitor(a) then
            onTouch(b, c)
        elseif ev == "monitor_resize" and isOurMonitor(a) then
            textScale, W, H = applyScale()
            draw()
        elseif ev == "timer" and a == redrawTimer then
            if not state.host then
                resolveHost()
            end
            if not state.graph then
                resolveGraph()
            end
            if refreshSec > 0 and not state.filterEdit then
                refreshList()
                drainPendingTouches()
            end
            draw()
            redrawTimer = os.startTimer(math.max(0.5, refreshSec > 0 and refreshSec or 2))
        elseif ev == "rednet_message" and c == protocol.NAME then
            local msg = protocol.decode(b)
            if msg and msg.kind == "hello" and msg.role == "sampler" then
                state.host = a
                state.status = "sampler #" .. tostring(a)
            end
        elseif ev == "char" and state.filterEdit then
            state.filter = state.filter .. a
            draw()
        elseif ev == "key" and state.filterEdit then
            if a == keys.backspace then
                state.filter = state.filter:sub(1, math.max(0, #state.filter - 1))
                draw()
            elseif a == keys.enter then
                state.filterEdit = false
                state.scroll = 0
                refreshList()
                drainPendingTouches()
                draw()
            elseif a == keys.escape then
                state.filterEdit = false
                draw()
            end
        elseif ev == "key" and a == keys.q and not state.filterEdit then
            break
        end
    end
end

main()
